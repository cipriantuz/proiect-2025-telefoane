# Smartphone Ontology - Data Deduplication

## Overview of the Deduplication Process

This document explains how to handle duplicate smartphone entries that can occur when combining data from multiple sources (sample files, GitHub dataset, GSMArena, etc.).

## The Problem

When processing smartphone data from different sources, we can end up with multiple URIs representing the same smartphone model. This happens because:

1. Different data sources use different identifier generation methods
2. The same phone model (e.g., "iPhone 13") appears in multiple data sources
3. URIs are created with different patterns:
   - `Phone_XXX` (numeric ID from GitHub dataset)
   - `Phone_Manufacturer_ModelName` (from GSMArena)
   - `ModelName` (from sample files)

This causes issues when querying the knowledge graph, as you'll get multiple results for what should be a single entity.

## The Solution

The deduplication process works as follows:

1. **Identify Duplicate Entries**: Find all smartphones with the same manufacturer and model name
2. **Select Canonical URIs**: Choose one URI to represent each unique phone model
   - Prioritize URIs that include the model name (e.g., `iPhone_13` over `Phone_149`)
3. **Create Redirections**: Map all duplicate URIs to their canonical URI
4. **Generate a Clean Graph**: Create a new RDF graph with all duplicates replaced by their canonical URIs

## How to Use the Deduplication Tool

We've provided scripts to handle the deduplication process:

### Option 1: Use the Batch File (Recommended)

Simply run the batch file:

```
regenerate_deduplicated_data.bat
```

This will:
1. Process all data sources
2. Deduplicate the combined data
3. Save the clean dataset to `data/processed/smartphone-data-deduplicated.ttl`

### Option 2: Run Individual Scripts

If you want more control:

1. Process your data sources as usual
2. Run the deduplication script:
   ```
   python scripts/processing/deduplicate_phones.py
   ```
3. Load the deduplicated file into Fuseki

## Impact on SPARQL Queries

Your existing SPARQL queries should work with the deduplicated dataset without modification. The main differences you'll notice:

1. Fewer results when querying for phones (only unique models will be returned)
2. URIs will be more consistent (prioritizing the model name format)
3. All relationships will be properly consolidated

## Best Practices for Future Data Integration

To avoid duplication issues in the future:

1. **Use Consistent URI Generation**: When adding new data sources, try to follow the same URI pattern
2. **Run Deduplication After Updates**: Always run the deduplication process after adding new data
3. **Check Existing Entities**: Before creating a new entity, check if it already exists based on key properties (manufacturer + model)

## Debugging Deduplication Issues

If you encounter issues with the deduplication process:

1. Check the deduplication log for errors
2. Verify the original and deduplicated TTL files for consistency
3. Test simple SPARQL queries to confirm the duplicates are removed
4. If problems persist, you can manually edit the canonical URI mappings in the deduplication script

## Advanced Configuration

The deduplication script can be customized by editing `scripts/processing/deduplicate_phones.py`:

- Change the properties used for identifying duplicates (currently manufacturer + model name)
- Modify the criteria for selecting canonical URIs
- Adjust the handling of related entities (components, accessories, etc.)
