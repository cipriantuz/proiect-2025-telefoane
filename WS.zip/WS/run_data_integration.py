"""
Smartphone Ontology Data Integration Pipeline

This script runs the complete data integration pipeline:
1. Fetch and process data from DBpedia
2. Fetch and process data from Wikidata
3. Create an aligned ontology based on standard vocabularies
4. Integrate all smartphone data into a unified knowledge graph
"""

import os
import sys
import subprocess
import time

def run_command(description, command):
    """Run a command with error handling and output display"""
    print("\n" + "="*80)
    print(f"RUNNING: {description}")
    print("="*80)
    
    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            shell=True
        )
        
        # Display output in real-time
        for line in process.stdout:
            print(line.strip())
        
        process.wait()
        
        if process.returncode != 0:
            print(f"ERROR: {description} failed with return code {process.returncode}")
            return False
        
        print(f"SUCCESS: {description} completed")
        return True
    
    except Exception as e:
        print(f"EXCEPTION: {description} failed with error: {e}")
        return False

def main():
    """Run the complete data integration pipeline"""
    start_time = time.time()
    
    # Get scripts directory
    scripts_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'scripts')
    integration_dir = os.path.join(scripts_dir, 'data_integration')
    
    # Ensure pip dependencies are installed
    run_command(
        "Installing required dependencies", 
        "pip install rdflib SPARQLWrapper difflib"
    )
    
    # Step 1: Fetch and process data from DBpedia
    if not run_command(
        "Fetching smartphone data from DBpedia",
        f"python {os.path.join(integration_dir, 'dbpedia_phones.py')}"
    ):
        print("Warning: DBpedia data fetching failed, but continuing with other sources")
    
    # Step 2: Fetch and process data from Wikidata
    if not run_command(
        "Fetching smartphone data from Wikidata",
        f"python {os.path.join(integration_dir, 'wikidata_phones.py')}"
    ):
        print("Warning: Wikidata data fetching failed, but continuing with other sources")
    
    # Step 3: Create an aligned ontology
    if not run_command(
        "Creating aligned smartphone ontology",
        f"python {os.path.join(integration_dir, 'align_ontology.py')}"
    ):
        print("Error: Ontology alignment failed")
        return
    
    # Step 4: Process any existing sources (GSMArena, GitHub, sample files)
    run_command(
        "Processing existing smartphone data sources",
        f"python {os.path.join(scripts_dir, 'process_all_data.py')}"
    )
    
    # Step 5: Integrate all data sources
    if not run_command(
        "Integrating all smartphone data sources",
        f"python {os.path.join(integration_dir, 'integrate_datasets.py')}"
    ):
        print("Error: Data integration failed")
        return
    
    end_time = time.time()
    duration = end_time - start_time
    
    print("\n" + "="*80)
    print("DATA INTEGRATION PIPELINE COMPLETE")
    print("="*80)
    print(f"Total processing time: {duration:.2f} seconds ({duration/60:.2f} minutes)")
    print("\nOutputs:")
    print("  - Aligned ontology: onto/smartphone-ontology-aligned.owl")
    print("  - Integrated dataset: data/processed/smartphone-data-integrated.ttl")
    print("\nNext steps:")
    print("1. Load the ontology and dataset into Apache Jena Fuseki")
    print("2. Use SPARQL to query the integrated smartphone knowledge graph")
    print("3. Connect your front-end application to visualize the data")

if __name__ == "__main__":
    main()
