# Smartphone Dataset Cleaning Tool

This document explains the data cleaning process for the smartphone dataset used in the Ontology project.

## Overview

The GitHub smartphone dataset provides valuable real-world data, but it requires cleaning and normalization before it can be effectively used with our ontology. This cleaning tool addresses several key issues:

1. **Duplicate removal**: Many smartphone listings refer to the same device with minor variations
2. **Data standardization**: Inconsistent formats for RAM, storage, and other specifications
3. **Data extraction**: Convert text descriptions into structured data fields
4. **Missing data handling**: Intelligently fill missing values based on brand, series, and price point
5. **Normalization**: Standardize brand and series names for consistency

## Cleaning Process

The cleaning process consists of the following steps:

### 1. Standardize Brand Names

Brand names are standardized to canonical forms:
- "Samsung" -> "Samsung"
- "Xiaomi", "Mi" -> "Xiaomi"
- "Black Shark" -> "Xiaomi" (since it's a Xiaomi sub-brand)

### 2. Extract Series Information

Series information is extracted from model names using brand-specific patterns:
- Samsung: Galaxy S, Galaxy Note, Galaxy A, Galaxy M, Galaxy Z
- Apple: iPhone
- Xiaomi: Redmi, Redmi Note, Mi, etc.
- POCO: F-series, X-series, M-series, C-series
- And so on for other brands

### 3. Deduplicate Phones

Phones are deduplicated based on brand and model:
- Groups phones with the same brand and model
- Keeps the entry with the most complete information
- Removes unnecessary duplicates

### 4. Extract Structured Data

Structured data is extracted from text descriptions:
- **Display information**: Size (inches), type (AMOLED, IPS, etc.), resolution
- **Processor information**: Chipset model, core count, clock speed
- **Camera resolution**: Main camera megapixels
- **Battery capacity**: Capacity in mAh
- **RAM and Storage**: Memory configurations

### 5. Fill Missing Values

Missing values are filled with either:
- Extracted data from descriptions
- Reasonable defaults based on brand, series, and price point
- Industry standard values for the phone's category

### 6. Export Clean Data

The cleaned data is exported as:
- Individual JSON files per phone with standardized structure
- Ready to be processed into RDF format

## Usage

To clean the dataset, run the batch file:

```
clean_github_dataset.bat
```

This will:
1. Clean the raw dataset from GitHub
2. Process the cleaned data into RDF format
3. Save the results to `data\processed\smartphone-data-github.ttl`

## Benefits of Cleaning

The cleaning process delivers several key benefits:

1. **Improved data quality**: More accurate and consistent information
2. **Reduced redundancy**: Elimination of duplicate entries
3. **Better structure**: Standardized format for all specifications
4. **Enhanced completeness**: Intelligent handling of missing values
5. **Easier querying**: Standardized properties make SPARQL queries more effective

## Results

The cleaning process typically reduces the dataset from 300+ entries to 150-200 unique phones with enhanced data quality and completeness.

Common improvements include:
- Standardized camera specifications (e.g., "12 MP" instead of "12MP", "12mp", "12 Megapixels")
- Consistent battery capacity format (e.g., "5000 mAh" instead of various formats)
- Properly extracted processor information with chipset models and core counts
- Correctly identified device series for improved ontology structure

## Advanced Options

For advanced users, the cleaning script supports several customizations:

1. **Adjustment of deduplication logic**: Modify how duplicates are identified and merged
2. **Custom brand mappings**: Add or modify standardized brand names
3. **Series extraction patterns**: Customize how series names are extracted
4. **Default values**: Change the default values for missing specifications

These options can be modified in the `clean_github_dataset.py` script.
