import requests
import os
import pandas as pd
import sys
import time

def download_file(url, destination):
    """Download a file from URL to the specified destination path"""
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()  # Raise an exception for HTTP errors
        
        with open(destination, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
                
        return True
    except Exception as e:
        print(f"Error downloading {url}: {e}")
        return False

def main():
    # URLs for the datasets
    github_csv_url = "https://raw.githubusercontent.com/koyarqasm/SmartPhone-dataset/main/smartphones.csv"
    
    # Create output directories
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    raw_dir = os.path.join(base_dir, 'data', 'raw', 'github')
    
    os.makedirs(raw_dir, exist_ok=True)
    
    # File paths
    csv_path = os.path.join(raw_dir, 'smartphones.csv')
    json_dir = os.path.join(raw_dir, 'json')
    os.makedirs(json_dir, exist_ok=True)
    
    # Download the CSV file
    print(f"Downloading smartphone dataset from GitHub...")
    success = download_file(github_csv_url, csv_path)
    
    if not success:
        print("Failed to download the dataset. Please check your internet connection.")
        return
    
    print(f"Successfully downloaded to {csv_path}")
    
    # Load and examine the CSV
    try:
        df = pd.read_csv(csv_path)
        print(f"\nDataset loaded successfully!")
        print(f"Number of smartphones: {len(df)}")
        print(f"Columns: {', '.join(df.columns)}")
        
        # Convert each row to individual JSON files
        print(f"\nConverting data to individual JSON files...")
        
        for i, row in df.iterrows():
            # Extract brand and model
            full_name = row.get('Smartphone', '')
            brand = row.get('Brand', '')
            model = row.get('Model', '')
            
            # Extract RAM and storage
            ram = row.get('RAM', '')
            storage = row.get('Storage', '')
            
            # Create a phone object compatible with our ontology structure
            phone = {
                "id": i + 1,
                "manufacturer": brand,
                "series": "",  # We'll derive this from the model
                "model_name": model,
                "release_date": "2023",  # Default as the dataset doesn't have release dates
                "display_size": "6.0 inches",  # Default
                "display_type": "AMOLED",  # Default
                "display_resolution": "1080 x 2400 pixels",  # Default
                "processor_chipset": "Snapdragon 8 Gen 1",  # Default
                "processor_cpu": "Octa-core",  # Default
                "main_camera": "50 MP",  # Default
                "battery_capacity": "5000 mAh",  # Default
                "memory": f"{ram}GB RAM, {storage}GB storage"
            }
            
            # Extract series from model
            if "Galaxy" in model:
                series_parts = model.split()
                if len(series_parts) >= 2:
                    phone["series"] = f"{series_parts[0]} {series_parts[1]}"
            elif "iPhone" in model:
                phone["series"] = "iPhone"
            elif "Redmi" in model:
                if "Note" in model:
                    phone["series"] = "Redmi Note"
                else:
                    phone["series"] = "Redmi"
            else:
                # Try to extract the series from the model
                model_parts = model.split()
                if len(model_parts) > 0:
                    phone["series"] = model_parts[0]
            
            # Save as JSON
            safe_brand = brand.replace(" ", "_") if brand else "Unknown"
            safe_model = model.replace(" ", "_") if model else "Unknown"
            json_filename = f"{safe_brand}_{safe_model}_{i+1}.json"
            json_path = os.path.join(json_dir, json_filename)
            
            # Save to JSON
            pd.Series(phone).to_json(json_path, orient='index', indent=2)
            
            # Show progress for every 100 phones
            if (i + 1) % 100 == 0 or i == len(df) - 1:
                print(f"Processed {i + 1}/{len(df)} phones")
        
        print(f"\nSuccessfully converted all data to JSON files in {json_dir}")
        print("You can now run the RDF processing script to convert this data to the ontology format.")
        
    except Exception as e:
        print(f"Error processing the CSV file: {e}")
        return

if __name__ == "__main__":
    main()
