# Configuration for smartphone ontology data generation

# Number of synthetic phones to generate
# Adjust this value to control the scale of your dataset
# Each phone will produce approximately 20-30 RDF triples,
# so 100,000 phones will result in 2-3 million relations
NUM_PHONES = 100000

# Batch size for data processing
# Smaller batches use less memory but may take longer
BATCH_SIZE = 10000

# Output directory paths
SYNTHETIC_DATA_DIR = "../../data/raw/synthetic"
PROCESSED_DATA_DIR = "../../data/processed"

# RDF output formats
# Options: 'turtle', 'xml', 'json-ld', 'n3'
RDF_FORMAT = 'turtle'
RDF_FILE_EXTENSION = 'ttl'

# Save intermediate batch files (True/False)
SAVE_INTERMEDIATE = True

# Manufacturers and series to include
# Comment out any manufacturers you don't want to include
MANUFACTURERS = {
    "Samsung": ["Galaxy S", "Galaxy Note", "Galaxy A", "Galaxy M", "Galaxy F", "Galaxy Z"],
    "Apple": ["iPhone", "iPhone Pro", "iPhone Pro Max", "iPhone SE", "iPhone Mini"],
    "Xiaomi": ["Mi", "Redmi", "Redmi Note", "POCO", "Black Shark"],
    "Oppo": ["Find", "Reno", "A", "F", "K"],
    "Vivo": ["X", "V", "Y", "S", "iQOO"],
    "Huawei": ["P", "Mate", "Nova", "Y", "Honor"],
    "Motorola": ["Moto G", "Moto E", "Moto X", "Edge", "Razr"],
    "OnePlus": ["OnePlus", "Nord"],
    "Google": ["Pixel", "Pixel Pro", "Pixel A"],
    "Sony": ["Xperia", "Xperia Pro", "Xperia 1", "Xperia 5", "Xperia 10"],
    "LG": ["G", "V", "K", "Q", "Velvet"],
    "Nokia": ["Nokia", "G", "C", "X"],
    "Asus": ["ZenFone", "ROG Phone"],
    "Realme": ["GT", "X", "C", "Narzo"],
    "Lenovo": ["Legion", "K", "A", "Z"],
}
