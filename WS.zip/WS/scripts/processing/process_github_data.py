import json
import os
import glob
import re
from rdflib import Graph, Namespace, Literal, URIRef
from rdflib.namespace import RDF, RDFS, XSD
import time
import sys

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")
SCHEMA = Namespace("http://schema.org/")
QUDT = Namespace("http://qudt.org/schema/qudt/")
TIME = Namespace("http://www.w3.org/2006/time#")

def clean_text(text):
    if not text:
        return ""
    return str(text).strip().replace('\n', ' ').replace('\r', '')

def extract_numeric_value(text, pattern=r'(\d+\.?\d*)'):
    if not text:
        return None
    match = re.search(pattern, str(text))
    return float(match.group(1)) if match else None

def extract_series(manufacturer, model_name):
    """Extract the series name from the model name based on common patterns"""
    if not model_name:
        return "Unknown Series"
    
    # Samsung patterns
    if manufacturer.lower() == "samsung":
        if "galaxy s" in model_name.lower():
            return "Galaxy S"
        if "galaxy note" in model_name.lower():
            return "Galaxy Note"
        if "galaxy a" in model_name.lower():
            return "Galaxy A"
        if "galaxy m" in model_name.lower():
            return "Galaxy M"
        if "galaxy z" in model_name.lower():
            return "Galaxy Z"
    
    # Apple patterns
    if manufacturer.lower() == "apple":
        if "iphone" in model_name.lower():
            return "iPhone"
    
    # Xiaomi patterns
    if manufacturer.lower() == "xiaomi":
        if "redmi note" in model_name.lower():
            return "Redmi Note"
        if "redmi" in model_name.lower():
            return "Redmi"
        if "poco" in model_name.lower():
            return "POCO"
        if "mi" in model_name.lower():
            return "Mi"
    
    # OnePlus patterns
    if manufacturer.lower() == "oneplus":
        if "nord" in model_name.lower():
            return "Nord"
        return "OnePlus"
    
    # Google patterns
    if manufacturer.lower() == "google":
        if "pixel" in model_name.lower():
            return "Pixel"
    
    # Generic extraction - look for common series pattern
    model_parts = model_name.split()
    if len(model_parts) > 0:
        return model_parts[0]
    
    return "Unknown Series"

def process_github_dataset():
    print("Starting to process GitHub smartphone dataset...")
    start_time = time.time()
    
    g = Graph()
    
    # Bind namespaces
    g.bind("smartphone", SMARTPHONE)
    g.bind("schema", SCHEMA)
    g.bind("qudt", QUDT)
    g.bind("time", TIME)
    
    # Track manufacturers and series to avoid duplication
    manufacturers = {}
    series = {}
    
    # Find all JSON files
    github_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'raw', 'github', 'json')
    json_files = glob.glob(os.path.join(github_dir, '*.json'))
    
    if not json_files:
        print(f"No JSON files found in {github_dir}.")
        print("Please run download_github_dataset.py first.")
        return
    
    print(f"Found {len(json_files)} phone files to process.")
    
    # Create output directory
    processed_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'processed')
    os.makedirs(processed_dir, exist_ok=True)
    
    total_phones = 0
    
    # Process each JSON file
    for i, json_file in enumerate(json_files):
        if i % 100 == 0 or i == len(json_files) - 1:
            print(f"Processing phone {i+1}/{len(json_files)}: {os.path.basename(json_file)}")
        
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                # The files are in 'index' format from pandas.to_json
                data = json.load(f)
                phone = {k: data[k] for k in data}
            
            manufacturer_name = clean_text(phone.get('manufacturer', ''))
            model_name = clean_text(phone.get('model_name', ''))
            
            if not manufacturer_name or not model_name:
                continue
            
            # Extract series from model name if not provided
            if not phone.get('series') or phone.get('series') == "":
                series_name = extract_series(manufacturer_name, model_name)
            else:
                series_name = clean_text(phone.get('series', ''))
            
            # Create or reuse manufacturer URI
            if manufacturer_name not in manufacturers:
                manufacturer_uri = URIRef(SMARTPHONE + manufacturer_name.replace(' ', '_'))
                g.add((manufacturer_uri, RDF.type, SMARTPHONE.Manufacturer))
                g.add((manufacturer_uri, SMARTPHONE.hasBrandName, Literal(manufacturer_name)))
                manufacturers[manufacturer_name] = manufacturer_uri
            else:
                manufacturer_uri = manufacturers[manufacturer_name]
            
            # Create or reuse series URI
            series_key = f"{manufacturer_name}_{series_name}"
            if series_key not in series:
                series_uri = URIRef(SMARTPHONE + series_key.replace(' ', '_'))
                g.add((series_uri, RDF.type, SMARTPHONE.DeviceSeries))
                g.add((series_uri, RDFS.label, Literal(series_name)))
                g.add((series_uri, SMARTPHONE.manufacturedBy, manufacturer_uri))
                series[series_key] = series_uri
            else:
                series_uri = series[series_key]
            
            # Create smartphone instance
            phone_uri = URIRef(SMARTPHONE + f"Phone_{phone.get('id', hash(model_name))}")
            g.add((phone_uri, RDF.type, SMARTPHONE.Smartphone))
            g.add((phone_uri, SMARTPHONE.hasModelName, Literal(model_name)))
            g.add((phone_uri, SMARTPHONE.manufacturedBy, manufacturer_uri))
            g.add((phone_uri, SMARTPHONE.belongsToSeries, series_uri))
            
            # Add release date if available
            if 'release_date' in phone and phone['release_date']:
                release_date = clean_text(phone['release_date'])
                g.add((phone_uri, SMARTPHONE.hasReleaseDate, Literal(release_date)))
            
            # Create and link display component
            if ('display_size' in phone and phone['display_size']) or \
               ('display_type' in phone and phone['display_type']) or \
               ('display_resolution' in phone and phone['display_resolution']):
                display_uri = URIRef(SMARTPHONE + f"Display_{phone.get('id', hash(model_name))}")
                g.add((display_uri, RDF.type, SMARTPHONE.Display))
                g.add((phone_uri, SMARTPHONE.hasDisplay, display_uri))
                
                if 'display_size' in phone and phone['display_size']:
                    display_size = clean_text(phone['display_size'])
                    size_value = extract_numeric_value(display_size)
                    if size_value:
                        g.add((display_uri, SMARTPHONE.hasScreenSize, Literal(size_value, datatype=XSD.decimal)))
                
                if 'display_type' in phone and phone['display_type']:
                    display_type = clean_text(phone['display_type'])
                    g.add((display_uri, SMARTPHONE.hasDisplayType, Literal(display_type)))
                
                if 'display_resolution' in phone and phone['display_resolution']:
                    resolution = clean_text(phone['display_resolution'])
                    g.add((display_uri, SMARTPHONE.hasResolution, Literal(resolution)))
            
            # Create and link processor component
            if ('processor_chipset' in phone and phone['processor_chipset']) or \
               ('processor_cpu' in phone and phone['processor_cpu']):
                processor_uri = URIRef(SMARTPHONE + f"Processor_{phone.get('id', hash(model_name))}")
                g.add((processor_uri, RDF.type, SMARTPHONE.Processor))
                g.add((phone_uri, SMARTPHONE.hasProcessor, processor_uri))
                
                if 'processor_chipset' in phone and phone['processor_chipset']:
                    chipset = clean_text(phone['processor_chipset'])
                    g.add((processor_uri, SMARTPHONE.hasChipsetModel, Literal(chipset)))
                
                if 'processor_cpu' in phone and phone['processor_cpu']:
                    cpu = clean_text(phone['processor_cpu'])
                    g.add((processor_uri, SMARTPHONE.hasCPUDetails, Literal(cpu)))
                    
                    # Try to extract core count
                    core_pattern = r'(\d+).*core'
                    core_match = re.search(core_pattern, str(cpu), re.IGNORECASE)
                    if core_match:
                        core_count = int(core_match.group(1))
                        g.add((processor_uri, SMARTPHONE.hasCoreCount, Literal(core_count, datatype=XSD.integer)))
                    
                    # Try to extract clock speed
                    clock_pattern = r'(\d+\.?\d*)\s*GHz'
                    clock_match = re.search(clock_pattern, str(cpu), re.IGNORECASE)
                    if clock_match:
                        clock_speed = float(clock_match.group(1))
                        g.add((processor_uri, SMARTPHONE.hasClockSpeed, Literal(clock_speed, datatype=XSD.decimal)))
            
            # Create and link camera component
            if 'main_camera' in phone and phone['main_camera']:
                camera_uri = URIRef(SMARTPHONE + f"Camera_{phone.get('id', hash(model_name))}")
                g.add((camera_uri, RDF.type, SMARTPHONE.Camera))
                g.add((phone_uri, SMARTPHONE.hasMainCamera, camera_uri))
                
                main_camera = clean_text(phone['main_camera'])
                g.add((camera_uri, RDFS.comment, Literal(main_camera)))
                
                # Try to extract megapixels
                mp_pattern = r'(\d+\.?\d*)\s*MP'
                mp_matches = re.findall(mp_pattern, str(main_camera), re.IGNORECASE)
                if mp_matches:
                    primary_mp = float(mp_matches[0])
                    g.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(primary_mp, datatype=XSD.decimal)))
                else:
                    # Try just extracting the number if MP is not included
                    mp_value = extract_numeric_value(main_camera)
                    if mp_value:
                        g.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(mp_value, datatype=XSD.decimal)))
            
            # Create and link battery component
            if 'battery_capacity' in phone and phone['battery_capacity']:
                battery_uri = URIRef(SMARTPHONE + f"Battery_{phone.get('id', hash(model_name))}")
                g.add((battery_uri, RDF.type, SMARTPHONE.Battery))
                g.add((phone_uri, SMARTPHONE.hasBattery, battery_uri))
                
                battery_capacity = clean_text(phone['battery_capacity'])
                capacity_value = extract_numeric_value(battery_capacity)
                if capacity_value:
                    g.add((battery_uri, SMARTPHONE.hasBatteryCapacity, Literal(int(capacity_value), datatype=XSD.integer)))
            
            # Create and link memory component
            if 'memory' in phone and phone['memory']:
                memory_uri = URIRef(SMARTPHONE + f"Memory_{phone.get('id', hash(model_name))}")
                g.add((memory_uri, RDF.type, SMARTPHONE.Memory))
                g.add((phone_uri, SMARTPHONE.hasMemoryConfiguration, memory_uri))
                
                memory_text = clean_text(phone['memory'])
                
                # Try to extract RAM
                ram_pattern = r'(\d+).*GB.*RAM'
                ram_match = re.search(ram_pattern, str(memory_text), re.IGNORECASE)
                if ram_match:
                    ram_size = int(ram_match.group(1))
                    g.add((memory_uri, SMARTPHONE.hasRAMSize, Literal(ram_size, datatype=XSD.integer)))
                
                # Try to extract storage
                storage_pattern = r'(\d+).*GB.*storage'
                storage_match = re.search(storage_pattern, str(memory_text), re.IGNORECASE)
                if storage_match:
                    storage_size = int(storage_match.group(1))
                    g.add((memory_uri, SMARTPHONE.hasStorageSize, Literal(storage_size, datatype=XSD.integer)))
            
            # All went well, increment the count
            total_phones += 1
        
        except Exception as e:
            print(f"Error processing {json_file}: {e}")
            continue
    
    # Save the RDF graph
    final_output = os.path.join(processed_dir, "smartphone-data-github.ttl")
    print(f"Saving complete dataset to {final_output}")
    g.serialize(destination=final_output, format='turtle')
    
    end_time = time.time()
    total_time = end_time - start_time
    
    print(f"\nProcessing complete!")
    print(f"Total phones processed: {total_phones}")
    print(f"Total triples generated: {len(g)}")
    print(f"Processing time: {total_time:.2f} seconds ({total_time/60:.2f} minutes)")
    if total_phones > 0:
        print(f"Average {len(g)/total_phones:.1f} triples per phone")
    print(f"\nData saved to {final_output}")

if __name__ == "__main__":
    process_github_dataset()
