import os
import glob
from rdflib import Graph, Namespace, URIRef, Literal
from rdflib.namespace import RDF
import time

# Define the smartphone namespace
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")

def get_processed_files():
    """Get all processed TTL files from the data/processed directory"""
    processed_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'processed')
    return glob.glob(os.path.join(processed_dir, '*.ttl'))

def deduplicate_smartphones():
    """Combine and deduplicate smartphone data from all processed TTL files"""
    print("Starting smartphone deduplication process...")
    start_time = time.time()
    
    # Output file for deduplicated data
    processed_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'processed')
    output_file = os.path.join(processed_dir, 'smartphone-data-deduplicated.ttl')
    
    # Load all graphs
    ttl_files = get_processed_files()
    print(f"Found {len(ttl_files)} TTL files to process.")
    
    # Combined graph
    combined_graph = Graph()
    
    # Load all TTL files into a single graph
    total_triples = 0
    for ttl_file in ttl_files:
        print(f"Loading {os.path.basename(ttl_file)}...")
        graph = Graph()
        graph.parse(ttl_file, format='turtle')
        total_triples += len(graph)
        combined_graph += graph
    
    print(f"Loaded {total_triples} triples from {len(ttl_files)} files.")
    print(f"Combined graph has {len(combined_graph)} triples (after automatic duplicate removal).")
    
    # Find all smartphones and their model names
    smartphones = {}
    canonical_uris = {}
    
    print("Identifying duplicate smartphones...")
    for s, p, o in combined_graph.triples((None, RDF.type, SMARTPHONE.Smartphone)):
        # Get the model name
        for _, _, model_name in combined_graph.triples((s, SMARTPHONE.hasModelName, None)):
            # Get the manufacturer
            for _, _, manufacturer in combined_graph.triples((s, SMARTPHONE.manufacturedBy, None)):
                for _, _, brand_name in combined_graph.triples((manufacturer, SMARTPHONE.hasBrandName, None)):
                    # Create a key for this phone model
                    key = f"{brand_name}_{model_name}"
                    
                    # If we haven't seen this model yet, record it
                    if key not in smartphones:
                        smartphones[key] = []
                    
                    # Add this URI to the list for this model
                    smartphones[key].append(s)
    
    # Identify canonical URIs and duplicates
    duplicates_found = 0
    for key, uris in smartphones.items():
        if len(uris) > 1:
            duplicates_found += len(uris) - 1
            
            # Choose the canonical URI - prioritize ones with model name in the URI
            canonical_uri = None
            for uri in uris:
                uri_str = str(uri)
                # These are the clean URIs from manual examples (preferred)
                if uri_str.lower().endswith(key.replace(' ', '_').lower()) or '_'.join(key.split('_')[1:]).lower() in uri_str.lower():
                    canonical_uri = uri
                    break
            
            # If no nice URI found, use the first one
            if canonical_uri is None:
                canonical_uri = uris[0]
            
            # Record the canonical URI for this model
            canonical_uris[key] = canonical_uri
            
            # Map all duplicates to the canonical URI
            for uri in uris:
                if uri != canonical_uri:
                    # Add canonical mapping
                    canonical_uris[str(uri)] = canonical_uri
    
    print(f"Found {duplicates_found} duplicate smartphone entries for {len(smartphones)} unique models.")
    
    # Create a new graph with deduplicated smartphones
    print("Creating deduplicated graph...")
    deduplicated_graph = Graph()
    
    # Copy all namespaces
    for prefix, namespace in combined_graph.namespaces():
        deduplicated_graph.bind(prefix, namespace)
    
    # Copy all triples, replacing duplicate URIs with canonical ones
    for s, p, o in combined_graph:
        # If s is a duplicate smartphone URI, replace it with the canonical URI
        if str(s) in canonical_uris:
            s = canonical_uris[str(s)]
        
        # If o is a duplicate smartphone URI, replace it with the canonical URI
        if isinstance(o, URIRef) and str(o) in canonical_uris:
            o = canonical_uris[str(o)]
        
        # Add the triple to the deduplicated graph
        deduplicated_graph.add((s, p, o))
    
    # Save the deduplicated graph
    print(f"Saving deduplicated graph to {output_file}...")
    deduplicated_graph.serialize(destination=output_file, format='turtle')
    
    end_time = time.time()
    
    print(f"\nDeduplication complete!")
    print(f"Original graph size: {len(combined_graph)} triples")
    print(f"Deduplicated graph size: {len(deduplicated_graph)} triples")
    print(f"Processing time: {end_time - start_time:.2f} seconds")
    print(f"Output file: {output_file}")

if __name__ == "__main__":
    deduplicate_smartphones()
