import json
import os
import glob
import re
import uuid
from rdflib import Graph, Namespace, Literal, URIRef
from rdflib.namespace import RDF, RDFS, XSD
import time
import sys

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")
SCHEMA = Namespace("http://schema.org/")
QUDT = Namespace("http://qudt.org/schema/qudt/")
TIME = Namespace("http://www.w3.org/2006/time#")

def clean_text(text):
    if not text:
        return ""
    return str(text).strip().replace('\n', ' ').replace('\r', '')

def extract_numeric_value(text, pattern=r'(\d+\.?\d*)'):
    if not text:
        return None
    match = re.search(pattern, str(text))
    return float(match.group(1)) if match else None

def extract_series(manufacturer, model_name):
    """Extract the series name from the model name based on common patterns"""
    if not model_name:
        return "Unknown Series"
    
    # Samsung patterns
    if manufacturer.lower() == "samsung":
        if "galaxy s" in model_name.lower():
            return "Galaxy S"
        if "galaxy note" in model_name.lower():
            return "Galaxy Note"
        if "galaxy a" in model_name.lower():
            return "Galaxy A"
        if "galaxy m" in model_name.lower():
            return "Galaxy M"
        if "galaxy z" in model_name.lower():
            return "Galaxy Z"
    
    # Apple patterns
    if manufacturer.lower() == "apple":
        if "iphone" in model_name.lower():
            return "iPhone"
    
    # Xiaomi patterns
    if manufacturer.lower() == "xiaomi":
        if "redmi note" in model_name.lower():
            return "Redmi Note"
        if "redmi" in model_name.lower():
            return "Redmi"
        if "poco" in model_name.lower():
            return "POCO"
        if "mi" in model_name.lower():
            return "Mi"
    
    # OnePlus patterns
    if manufacturer.lower() == "oneplus":
        if "nord" in model_name.lower():
            return "Nord"
        return "OnePlus"
    
    # Google patterns
    if manufacturer.lower() == "google":
        if "pixel" in model_name.lower():
            return "Pixel"
    
    # Generic extraction - look for common series pattern
    model_parts = model_name.split()
    if len(model_parts) > 0:
        return model_parts[0]
    
    return "Unknown Series"

def generate_unique_id(phone, index):
    """Generate a truly unique ID for each phone based on multiple attributes"""
    # Combine multiple attributes to ensure uniqueness
    unique_str = f"{phone.get('manufacturer', '')}-{phone.get('model_name', '')}-{phone.get('series', '')}-{index}"
    # Generate a unique hash (UUID based on the name - will be consistent between runs for same values)
    unique_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, unique_str))
    # Extract just the first part of the UUID to keep URIs manageable
    short_id = unique_id.split('-')[0]
    return f"Phone_{short_id}_{index}"

def process_github_dataset():
    print("Starting to process GitHub smartphone dataset with fixed uniqueness...")
    start_time = time.time()
    
    g = Graph()
    
    # Bind namespaces
    g.bind("smartphone", SMARTPHONE)
    g.bind("schema", SCHEMA)
    g.bind("qudt", QUDT)
    g.bind("time", TIME)
    
    # Track manufacturers and series to avoid duplication
    manufacturers = {}
    series = {}
    # Track all generated URIs to ensure uniqueness
    used_uris = set()
    
    # Find all JSON files
    github_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'raw', 'github', 'json')
    json_files = glob.glob(os.path.join(github_dir, '*.json'))
    
    if not json_files:
        print(f"No JSON files found in {github_dir}.")
        print("Please run download_github_dataset.py first.")
        return
    
    print(f"Found {len(json_files)} phone files to process.")
    
    # Create output directory
    processed_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'processed')
    os.makedirs(processed_dir, exist_ok=True)
    
    total_phones = 0
    processed_files = []
    
    # First pass: Load all files and verify for duplicates
    print("First pass: Loading and verifying all files...")
    all_phones = []
    file_phone_map = {}
    
    for i, json_file in enumerate(json_files):
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                # Create a fingerprint for deduplication
                manufacturer = clean_text(data.get('manufacturer', ''))
                model_name = clean_text(data.get('model_name', ''))
                
                if not manufacturer or not model_name:
                    continue
                
                fingerprint = f"{manufacturer.lower()}|{model_name.lower()}"
                
                all_phones.append({
                    'file': json_file,
                    'data': data,
                    'fingerprint': fingerprint,
                    'index': i
                })
                file_phone_map[json_file] = fingerprint
        except Exception as e:
            print(f"Error reading {json_file}: {e}")
    
    # Check for duplicates
    fingerprints = {}
    for phone in all_phones:
        if phone['fingerprint'] in fingerprints:
            print(f"WARNING: Possible duplicate found: {phone['file']} matches {fingerprints[phone['fingerprint']]}")
        fingerprints[phone['fingerprint']] = phone['file']
    
    # Process each JSON file - second pass
    print("Second pass: Converting to RDF...")
    for i, phone_info in enumerate(all_phones):
        json_file = phone_info['file']
        phone = phone_info['data']
        
        if i % 20 == 0 or i == len(all_phones) - 1:
            print(f"Processing phone {i+1}/{len(all_phones)}: {os.path.basename(json_file)}")
        
        try:
            manufacturer_name = clean_text(phone.get('manufacturer', ''))
            model_name = clean_text(phone.get('model_name', ''))
            
            if not manufacturer_name or not model_name:
                continue
            
            # Extract series from model name if not provided
            if not phone.get('series') or phone.get('series') == "":
                series_name = extract_series(manufacturer_name, model_name)
            else:
                series_name = clean_text(phone.get('series', ''))
            
            # Create or reuse manufacturer URI
            if manufacturer_name not in manufacturers:
                manufacturer_uri = URIRef(SMARTPHONE + manufacturer_name.replace(' ', '_'))
                g.add((manufacturer_uri, RDF.type, SMARTPHONE.Manufacturer))
                g.add((manufacturer_uri, SMARTPHONE.hasBrandName, Literal(manufacturer_name)))
                manufacturers[manufacturer_name] = manufacturer_uri
            else:
                manufacturer_uri = manufacturers[manufacturer_name]
            
            # Create or reuse series URI
            series_key = f"{manufacturer_name}_{series_name}"
            if series_key not in series:
                series_uri = URIRef(SMARTPHONE + series_key.replace(' ', '_').replace('/', '_'))
                g.add((series_uri, RDF.type, SMARTPHONE.DeviceSeries))
                g.add((series_uri, RDFS.label, Literal(series_name)))
                g.add((series_uri, SMARTPHONE.manufacturedBy, manufacturer_uri))
                series[series_key] = series_uri
            else:
                series_uri = series[series_key]
            
            # Generate a truly unique ID for the phone
            unique_phone_id = generate_unique_id(phone, i)
            
            # Create smartphone instance with unique ID
            phone_uri = URIRef(SMARTPHONE + unique_phone_id)
            
            # Verify URI is unique
            if str(phone_uri) in used_uris:
                print(f"WARNING: Duplicate URI generated: {phone_uri} - Creating alternative")
                unique_phone_id = f"{unique_phone_id}_{uuid.uuid4().hex[:8]}"
                phone_uri = URIRef(SMARTPHONE + unique_phone_id)
            
            used_uris.add(str(phone_uri))
            
            g.add((phone_uri, RDF.type, SMARTPHONE.Smartphone))
            g.add((phone_uri, SMARTPHONE.hasModelName, Literal(model_name)))
            g.add((phone_uri, SMARTPHONE.manufacturedBy, manufacturer_uri))
            g.add((phone_uri, SMARTPHONE.belongsToSeries, series_uri))
            
            # Add price if available
            if 'price' in phone and phone['price']:
                try:
                    price_value = float(phone['price'])
                    g.add((phone_uri, SMARTPHONE.hasPrice, Literal(price_value, datatype=XSD.decimal)))
                except (ValueError, TypeError):
                    # If price is not a valid number, try to extract it
                    price_text = clean_text(str(phone['price']))
                    price_value = extract_numeric_value(price_text)
                    if price_value:
                        g.add((phone_uri, SMARTPHONE.hasPrice, Literal(price_value, datatype=XSD.decimal)))
            
            # Add release date if available
            if 'release_date' in phone and phone['release_date']:
                release_date = clean_text(phone['release_date'])
                g.add((phone_uri, SMARTPHONE.hasReleaseDate, Literal(release_date)))
            
            # Add color if available
            if 'color' in phone and phone['color']:
                color = clean_text(phone['color'])
                g.add((phone_uri, SMARTPHONE.hasColor, Literal(color)))
            
            # Create and link display component
            if ('display_size' in phone and phone['display_size']) or \
               ('display_type' in phone and phone['display_type']) or \
               ('display_resolution' in phone and phone['display_resolution']):
                
                display_id = f"Display_{unique_phone_id}"
                display_uri = URIRef(SMARTPHONE + display_id)
                
                if str(display_uri) in used_uris:
                    display_id = f"{display_id}_{uuid.uuid4().hex[:8]}"
                    display_uri = URIRef(SMARTPHONE + display_id)
                
                used_uris.add(str(display_uri))
                
                g.add((display_uri, RDF.type, SMARTPHONE.Display))
                g.add((phone_uri, SMARTPHONE.hasDisplay, display_uri))
                
                if 'display_size' in phone and phone['display_size']:
                    display_size = clean_text(phone['display_size'])
                    size_value = extract_numeric_value(display_size)
                    if size_value:
                        g.add((display_uri, SMARTPHONE.hasScreenSize, Literal(size_value, datatype=XSD.decimal)))
                
                if 'display_type' in phone and phone['display_type']:
                    display_type = clean_text(phone['display_type'])
                    g.add((display_uri, SMARTPHONE.hasDisplayType, Literal(display_type)))
                
                if 'display_resolution' in phone and phone['display_resolution']:
                    resolution = clean_text(phone['display_resolution'])
                    g.add((display_uri, SMARTPHONE.hasResolution, Literal(resolution)))
            
            # Create and link processor component
            if ('processor_chipset' in phone and phone['processor_chipset']) or \
               ('processor_cpu' in phone and phone['processor_cpu']):
                
                processor_id = f"Processor_{unique_phone_id}"
                processor_uri = URIRef(SMARTPHONE + processor_id)
                
                if str(processor_uri) in used_uris:
                    processor_id = f"{processor_id}_{uuid.uuid4().hex[:8]}"
                    processor_uri = URIRef(SMARTPHONE + processor_id)
                
                used_uris.add(str(processor_uri))
                
                g.add((processor_uri, RDF.type, SMARTPHONE.Processor))
                g.add((phone_uri, SMARTPHONE.hasProcessor, processor_uri))
                
                if 'processor_chipset' in phone and phone['processor_chipset']:
                    chipset = clean_text(phone['processor_chipset'])
                    g.add((processor_uri, SMARTPHONE.hasChipsetModel, Literal(chipset)))
                
                if 'processor_cpu' in phone and phone['processor_cpu']:
                    cpu = clean_text(phone['processor_cpu'])
                    g.add((processor_uri, SMARTPHONE.hasCPUDetails, Literal(cpu)))
                    
                    # Try to extract core count
                    core_pattern = r'(\d+)[\s-]*core'
                    core_match = re.search(core_pattern, str(cpu), re.IGNORECASE)
                    if core_match:
                        try:
                            core_count = int(core_match.group(1))
                            g.add((processor_uri, SMARTPHONE.hasCoreCount, Literal(core_count, datatype=XSD.integer)))
                        except ValueError:
                            pass
                    
                    # Try to extract clock speed
                    clock_pattern = r'(\d+\.?\d*)\s*GHz'
                    clock_match = re.search(clock_pattern, str(cpu), re.IGNORECASE)
                    if clock_match:
                        try:
                            clock_speed = float(clock_match.group(1))
                            g.add((processor_uri, SMARTPHONE.hasClockSpeed, Literal(clock_speed, datatype=XSD.decimal)))
                        except ValueError:
                            pass
            
            # Create and link camera component
            if 'main_camera' in phone and phone['main_camera']:
                camera_id = f"Camera_{unique_phone_id}"
                camera_uri = URIRef(SMARTPHONE + camera_id)
                
                if str(camera_uri) in used_uris:
                    camera_id = f"{camera_id}_{uuid.uuid4().hex[:8]}"
                    camera_uri = URIRef(SMARTPHONE + camera_id)
                
                used_uris.add(str(camera_uri))
                
                g.add((camera_uri, RDF.type, SMARTPHONE.Camera))
                g.add((phone_uri, SMARTPHONE.hasMainCamera, camera_uri))
                
                main_camera = clean_text(phone['main_camera'])
                g.add((camera_uri, RDFS.comment, Literal(main_camera)))
                
                # Try to extract megapixels
                mp_pattern = r'(\d+\.?\d*)\s*MP'
                mp_matches = re.findall(mp_pattern, str(main_camera), re.IGNORECASE)
                if mp_matches:
                    try:
                        primary_mp = float(mp_matches[0])
                        g.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(primary_mp, datatype=XSD.decimal)))
                    except ValueError:
                        # If conversion fails, try extracting a numeric value
                        mp_value = extract_numeric_value(main_camera)
                        if mp_value:
                            g.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(mp_value, datatype=XSD.decimal)))
                else:
                    # Try just extracting the number if MP is not included
                    mp_value = extract_numeric_value(main_camera)
                    if mp_value:
                        g.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(mp_value, datatype=XSD.decimal)))
            
            # Create and link battery component
            if 'battery_capacity' in phone and phone['battery_capacity']:
                battery_id = f"Battery_{unique_phone_id}"
                battery_uri = URIRef(SMARTPHONE + battery_id)
                
                if str(battery_uri) in used_uris:
                    battery_id = f"{battery_id}_{uuid.uuid4().hex[:8]}"
                    battery_uri = URIRef(SMARTPHONE + battery_id)
                
                used_uris.add(str(battery_uri))
                
                g.add((battery_uri, RDF.type, SMARTPHONE.Battery))
                g.add((phone_uri, SMARTPHONE.hasBattery, battery_uri))
                
                battery_capacity = clean_text(phone['battery_capacity'])
                capacity_value = extract_numeric_value(battery_capacity)
                if capacity_value:
                    try:
                        # Round to nearest integer for battery capacity
                        int_capacity = int(round(capacity_value))
                        g.add((battery_uri, SMARTPHONE.hasBatteryCapacity, Literal(int_capacity, datatype=XSD.integer)))
                    except (ValueError, TypeError):
                        # If conversion fails, store as string
                        g.add((battery_uri, RDFS.comment, Literal(battery_capacity)))
            
            # Create and link memory component
            if 'memory' in phone and phone['memory']:
                memory_id = f"Memory_{unique_phone_id}"
                memory_uri = URIRef(SMARTPHONE + memory_id)
                
                if str(memory_uri) in used_uris:
                    memory_id = f"{memory_id}_{uuid.uuid4().hex[:8]}"
                    memory_uri = URIRef(SMARTPHONE + memory_id)
                
                used_uris.add(str(memory_uri))
                
                g.add((memory_uri, RDF.type, SMARTPHONE.Memory))
                g.add((phone_uri, SMARTPHONE.hasMemoryConfiguration, memory_uri))
                
                memory_text = clean_text(phone['memory'])
                
                # Try to extract RAM
                ram_pattern = r'(\d+).*GB.*RAM'
                ram_match = re.search(ram_pattern, str(memory_text), re.IGNORECASE)
                if ram_match:
                    try:
                        ram_size = int(ram_match.group(1))
                        g.add((memory_uri, SMARTPHONE.hasRAMSize, Literal(ram_size, datatype=XSD.integer)))
                    except ValueError:
                        pass
                
                # Try to extract storage
                storage_pattern = r'(\d+).*GB.*storage'
                storage_match = re.search(storage_pattern, str(memory_text), re.IGNORECASE)
                if storage_match:
                    try:
                        storage_size = int(storage_match.group(1))
                        g.add((memory_uri, SMARTPHONE.hasStorageSize, Literal(storage_size, datatype=XSD.integer)))
                    except ValueError:
                        pass
            
            # All went well, increment the count
            total_phones += 1
            processed_files.append(json_file)
        
        except Exception as e:
            print(f"Error processing {json_file}: {e}")
            continue
    
    # Verify processing
    print(f"\nVerifying processing results:")
    print(f"Files found: {len(json_files)}")
    print(f"Unique phones loaded: {len(all_phones)}")
    print(f"Successfully processed: {total_phones}")
    print(f"Failed: {len(all_phones) - total_phones}")
    
    # Save the RDF graph
    final_output = os.path.join(processed_dir, "smartphone-data-github.ttl")
    print(f"Saving complete dataset to {final_output}")
    g.serialize(destination=final_output, format='turtle')
    
    end_time = time.time()
    total_time = end_time - start_time
    
    print(f"\nProcessing complete!")
    print(f"Total phones processed: {total_phones}")
    print(f"Total triples generated: {len(g)}")
    print(f"Processing time: {total_time:.2f} seconds ({total_time/60:.2f} minutes)")
    if total_phones > 0:
        print(f"Average {len(g)/total_phones:.1f} triples per phone")
    print(f"\nData saved to {final_output}")

if __name__ == "__main__":
    process_github_dataset()
