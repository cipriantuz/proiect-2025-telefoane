import json
import os
import glob
import re
from rdflib import Graph, Namespace, Literal, URIRef
from rdflib.namespace import RDF, RDFS, XSD
import time
import sys

# Import configuration
try:
    from config import BATCH_SIZE, SYNTHETIC_DATA_DIR, PROCESSED_DATA_DIR, RDF_FORMAT, RDF_FILE_EXTENSION, SAVE_INTERMEDIATE
except ImportError:
    print("Configuration file not found. Using default settings.")
    BATCH_SIZE = 10000
    SYNTHETIC_DATA_DIR = "../../data/raw/synthetic"
    PROCESSED_DATA_DIR = "../../data/processed"
    RDF_FORMAT = 'turtle'
    RDF_FILE_EXTENSION = 'ttl'
    SAVE_INTERMEDIATE = True

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")
SCHEMA = Namespace("http://schema.org/")
QUDT = Namespace("http://qudt.org/schema/qudt/")
TIME = Namespace("http://www.w3.org/2006/time#")

def clean_text(text):
    if not text:
        return ""
    return text.strip().replace('\n', ' ').replace('\r', '')

def extract_numeric_value(text, pattern=r'(\d+\.?\d*)'):
    if not text:
        return None
    match = re.search(pattern, text)
    return float(match.group(1)) if match else None

def process_synthetic_files():
    print("Starting to process synthetic smartphone data...")
    start_time = time.time()
    
    g = Graph()
    
    # Bind namespaces
    g.bind("smartphone", SMARTPHONE)
    g.bind("schema", SCHEMA)
    g.bind("qudt", QUDT)
    g.bind("time", TIME)
    
    # Track manufacturers and series to avoid duplication
    manufacturers = {}
    series = {}
    
    # Find all synthetic data batches
    synthetic_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), SYNTHETIC_DATA_DIR))
    json_files = glob.glob(os.path.join(synthetic_dir, '*.json'))
    
    if not json_files:
        print(f"No synthetic data files found in {synthetic_dir}.")
        print("Please run generate_synthetic_data.py first.")
        return
    
    print(f"Found {len(json_files)} batch files to process.")
    
    # Create output directory
    processed_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), PROCESSED_DATA_DIR))
    os.makedirs(processed_dir, exist_ok=True)
    
    total_phones = 0
    total_triples = 0
    
    # Process each batch file
    for batch_num, json_file in enumerate(json_files, 1):
        print(f"Processing batch {batch_num}/{len(json_files)}: {os.path.basename(json_file)}")
        
        with open(json_file, 'r') as f:
            phones = json.load(f)
        
        print(f"  - Batch contains {len(phones)} phones")
        batch_start_time = time.time()
        
        # Process each phone in the batch
        for phone in phones:
            manufacturer_name = clean_text(phone.get('manufacturer', ''))
            series_name = clean_text(phone.get('series', ''))
            model_name = clean_text(phone.get('model_name', ''))
            
            if not manufacturer_name or not model_name:
                continue
            
            # Create or reuse manufacturer URI
            if manufacturer_name not in manufacturers:
                manufacturer_uri = URIRef(SMARTPHONE + manufacturer_name.replace(' ', '_'))
                g.add((manufacturer_uri, RDF.type, SMARTPHONE.Manufacturer))
                g.add((manufacturer_uri, SMARTPHONE.hasBrandName, Literal(manufacturer_name)))
                manufacturers[manufacturer_name] = manufacturer_uri
            else:
                manufacturer_uri = manufacturers[manufacturer_name]
            
            # Create or reuse series URI
            series_key = f"{manufacturer_name}_{series_name}"
            if series_key not in series:
                series_uri = URIRef(SMARTPHONE + series_key.replace(' ', '_'))
                g.add((series_uri, RDF.type, SMARTPHONE.DeviceSeries))
                g.add((series_uri, RDFS.label, Literal(series_name)))
                g.add((series_uri, SMARTPHONE.manufacturedBy, manufacturer_uri))
                series[series_key] = series_uri
            else:
                series_uri = series[series_key]
            
            # Create smartphone instance
            phone_uri = URIRef(SMARTPHONE + f"Phone_{phone.get('id', hash(model_name))}")
            g.add((phone_uri, RDF.type, SMARTPHONE.Smartphone))
            g.add((phone_uri, SMARTPHONE.hasModelName, Literal(model_name)))
            g.add((phone_uri, SMARTPHONE.manufacturedBy, manufacturer_uri))
            g.add((phone_uri, SMARTPHONE.belongsToSeries, series_uri))
            
            # Add release date if available
            if 'release_date' in phone:
                release_date = clean_text(phone['release_date'])
                g.add((phone_uri, SMARTPHONE.hasReleaseDate, Literal(release_date)))
            
            # Create and link display component
            if 'display_size' in phone or 'display_type' in phone or 'display_resolution' in phone:
                display_uri = URIRef(SMARTPHONE + f"Display_{phone.get('id', hash(model_name))}")
                g.add((display_uri, RDF.type, SMARTPHONE.Display))
                g.add((phone_uri, SMARTPHONE.hasDisplay, display_uri))
                
                if 'display_size' in phone:
                    display_size = clean_text(phone['display_size'])
                    size_value = extract_numeric_value(display_size)
                    if size_value:
                        g.add((display_uri, SMARTPHONE.hasScreenSize, Literal(size_value, datatype=XSD.decimal)))
                
                if 'display_type' in phone:
                    display_type = clean_text(phone['display_type'])
                    g.add((display_uri, SMARTPHONE.hasDisplayType, Literal(display_type)))
                
                if 'display_resolution' in phone:
                    resolution = clean_text(phone['display_resolution'])
                    g.add((display_uri, SMARTPHONE.hasResolution, Literal(resolution)))
            
            # Create and link processor component
            if 'processor_chipset' in phone or 'processor_cpu' in phone:
                processor_uri = URIRef(SMARTPHONE + f"Processor_{phone.get('id', hash(model_name))}")
                g.add((processor_uri, RDF.type, SMARTPHONE.Processor))
                g.add((phone_uri, SMARTPHONE.hasProcessor, processor_uri))
                
                if 'processor_chipset' in phone:
                    chipset = clean_text(phone['processor_chipset'])
                    g.add((processor_uri, SMARTPHONE.hasChipsetModel, Literal(chipset)))
                
                if 'processor_cpu' in phone:
                    cpu = clean_text(phone['processor_cpu'])
                    g.add((processor_uri, SMARTPHONE.hasCPUDetails, Literal(cpu)))
                    
                    # Try to extract core count
                    core_pattern = r'(\d+)\s*core'
                    core_match = re.search(core_pattern, cpu, re.IGNORECASE)
                    if core_match:
                        core_count = int(core_match.group(1))
                        g.add((processor_uri, SMARTPHONE.hasCoreCount, Literal(core_count, datatype=XSD.integer)))
                    
                    # Try to extract clock speed
                    clock_pattern = r'(\d+\.?\d*)\s*GHz'
                    clock_match = re.search(clock_pattern, cpu, re.IGNORECASE)
                    if clock_match:
                        clock_speed = float(clock_match.group(1))
                        g.add((processor_uri, SMARTPHONE.hasClockSpeed, Literal(clock_speed, datatype=XSD.decimal)))
            
            # Create and link camera component
            if 'main_camera' in phone:
                camera_uri = URIRef(SMARTPHONE + f"Camera_{phone.get('id', hash(model_name))}")
                g.add((camera_uri, RDF.type, SMARTPHONE.Camera))
                g.add((phone_uri, SMARTPHONE.hasMainCamera, camera_uri))
                
                main_camera = clean_text(phone['main_camera'])
                g.add((camera_uri, RDFS.comment, Literal(main_camera)))
                
                # Try to extract megapixels
                mp_pattern = r'(\d+\.?\d*)\s*MP'
                mp_matches = re.findall(mp_pattern, main_camera, re.IGNORECASE)
                if mp_matches:
                    primary_mp = float(mp_matches[0])
                    g.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(primary_mp, datatype=XSD.decimal)))
                
                # Try to extract aperture
                aperture_pattern = r'f/(\d+\.?\d*)'
                aperture_match = re.search(aperture_pattern, main_camera, re.IGNORECASE)
                if aperture_match:
                    aperture = aperture_match.group(0)
                    g.add((camera_uri, SMARTPHONE.hasAperture, Literal(aperture)))
            
            # Create and link secondary camera if available
            if 'secondary_camera' in phone:
                secondary_camera_uri = URIRef(SMARTPHONE + f"SecondaryCamera_{phone.get('id', hash(model_name))}")
                g.add((secondary_camera_uri, RDF.type, SMARTPHONE.Camera))
                g.add((phone_uri, SMARTPHONE.hasSecondaryCamera, secondary_camera_uri))
                
                secondary_camera = clean_text(phone['secondary_camera'])
                g.add((secondary_camera_uri, RDFS.comment, Literal(secondary_camera)))
                
                # Try to extract megapixels
                mp_pattern = r'(\d+\.?\d*)\s*MP'
                mp_matches = re.findall(mp_pattern, secondary_camera, re.IGNORECASE)
                if mp_matches:
                    secondary_mp = float(mp_matches[0])
                    g.add((secondary_camera_uri, SMARTPHONE.hasResolutionMP, Literal(secondary_mp, datatype=XSD.decimal)))
            
            # Create and link battery component
            if 'battery_capacity' in phone:
                battery_uri = URIRef(SMARTPHONE + f"Battery_{phone.get('id', hash(model_name))}")
                g.add((battery_uri, RDF.type, SMARTPHONE.Battery))
                g.add((phone_uri, SMARTPHONE.hasBattery, battery_uri))
                
                battery_capacity = clean_text(phone['battery_capacity'])
                capacity_value = extract_numeric_value(battery_capacity)
                if capacity_value:
                    g.add((battery_uri, SMARTPHONE.hasBatteryCapacity, Literal(int(capacity_value), datatype=XSD.integer)))
                
                # Add fast charging information if available
                if 'fast_charging_wattage' in phone:
                    fast_charging = clean_text(phone['fast_charging_wattage'])
                    wattage_value = extract_numeric_value(fast_charging)
                    if wattage_value:
                        g.add((battery_uri, SMARTPHONE.hasFastChargingWattage, Literal(int(wattage_value), datatype=XSD.integer)))
            
            # Create and link memory component
            if 'memory' in phone:
                memory_uri = URIRef(SMARTPHONE + f"Memory_{phone.get('id', hash(model_name))}")
                g.add((memory_uri, RDF.type, SMARTPHONE.Memory))
                g.add((phone_uri, SMARTPHONE.hasMemoryConfiguration, memory_uri))
                
                memory_text = clean_text(phone['memory'])
                
                # Try to extract RAM
                ram_pattern = r'(\d+)\s*GB\s*RAM'
                ram_match = re.search(ram_pattern, memory_text, re.IGNORECASE)
                if ram_match:
                    ram_size = int(ram_match.group(1))
                    g.add((memory_uri, SMARTPHONE.hasRAMSize, Literal(ram_size, datatype=XSD.integer)))
                
                # Try to extract storage
                storage_pattern = r'(\d+)\s*GB\s*storage'
                storage_match = re.search(storage_pattern, memory_text, re.IGNORECASE)
                if storage_match:
                    storage_size = int(storage_match.group(1))
                    g.add((memory_uri, SMARTPHONE.hasStorageSize, Literal(storage_size, datatype=XSD.integer)))
            
            total_phones += 1
        
        batch_end_time = time.time()
        print(f"  - Batch processed in {batch_end_time - batch_start_time:.2f} seconds")
        
        # Output progress stats
        current_triples = len(g)
        print(f"  - Total phones processed so far: {total_phones}")
        print(f"  - Total triples generated so far: {current_triples}")
        print(f"  - Average triples per phone: {current_triples / total_phones:.1f}")
        
        # Save intermediate results to manage memory
        if SAVE_INTERMEDIATE and (batch_num % 5 == 0 or batch_num == len(json_files)):
            batch_output = os.path.join(processed_dir, f"smartphone-data-batch-{batch_num}.{RDF_FILE_EXTENSION}")
            print(f"Saving intermediate results to {batch_output}")
            g.serialize(destination=batch_output, format=RDF_FORMAT)
    
    # Save the final RDF graph
    final_output = os.path.join(processed_dir, f"smartphone-data-complete.{RDF_FILE_EXTENSION}")
    print(f"Saving final complete dataset to {final_output}")
    g.serialize(destination=final_output, format=RDF_FORMAT)
    
    end_time = time.time()
    total_time = end_time - start_time
    
    print(f"\nProcessing complete!")
    print(f"Total phones processed: {total_phones}")
    print(f"Total triples generated: {len(g)}")
    print(f"Processing time: {total_time:.2f} seconds ({total_time/60:.2f} minutes)")
    print(f"Average processing rate: {total_phones/total_time:.2f} phones per second")
    print(f"Average {len(g)/total_phones:.1f} triples per phone")
    print(f"\nData saved to {final_output}")

def main():
    process_synthetic_files()

if __name__ == "__main__":
    main()
