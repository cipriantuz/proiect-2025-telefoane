import json
import os
import random
from datetime import datetime, timedelta
import uuid
import time
import sys

# Import configuration
try:
    from config import NUM_PHONES, BATCH_SIZE, SYNTHETIC_DATA_DIR, MANUFACTURERS
except ImportError:
    print("Configuration file not found. Using default settings.")
    NUM_PHONES = 100000
    BATCH_SIZE = 10000
    SYNTHETIC_DATA_DIR = "../../data/raw/synthetic"
    # Default manufacturers list
    MANUFACTURERS = {
        "Samsung": ["Galaxy S", "Galaxy Note", "Galaxy A", "Galaxy M", "Galaxy F", "Galaxy Z"],
        "Apple": ["iPhone", "iPhone Pro", "iPhone Pro Max", "iPhone SE", "iPhone Mini"],
        "Xiaomi": ["Mi", "Redmi", "Redmi Note", "POCO", "Black Shark"],
        "Oppo": ["Find", "Reno", "A", "F", "K"],
        "Vivo": ["X", "V", "Y", "S", "iQOO"],
        "Huawei": ["P", "Mate", "Nova", "Y", "Honor"],
        "Motorola": ["Moto G", "Moto E", "Moto X", "Edge", "Razr"],
        "OnePlus": ["OnePlus", "Nord"],
        "Google": ["Pixel", "Pixel Pro", "Pixel A"],
        "Sony": ["Xperia", "Xperia Pro", "Xperia 1", "Xperia 5", "Xperia 10"],
        "LG": ["G", "V", "K", "Q", "Velvet"],
        "Nokia": ["Nokia", "G", "C", "X"],
        "Asus": ["ZenFone", "ROG Phone"],
        "Realme": ["GT", "X", "C", "Narzo"],
        "Lenovo": ["Legion", "K", "A", "Z"],
    }

# Ensure directory exists
output_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), SYNTHETIC_DATA_DIR))
os.makedirs(output_dir, exist_ok=True)

# Define component specifications
display_types = ["IPS LCD", "AMOLED", "Super AMOLED", "Dynamic AMOLED", "Dynamic AMOLED 2X", "OLED", 
                "Super Retina XDR OLED", "Fluid AMOLED", "P-OLED", "TFT LCD", "Super LCD"]

processor_brands = {
    "Qualcomm": ["Snapdragon 888", "Snapdragon 865", "Snapdragon 855", "Snapdragon 778G", 
                 "Snapdragon 765G", "Snapdragon 750G", "Snapdragon 732G", "Snapdragon 720G", 
                 "Snapdragon 695", "Snapdragon 680", "Snapdragon 665", "Snapdragon 662"],
    "MediaTek": ["Dimensity 9000", "Dimensity 8100", "Dimensity 1200", "Dimensity 1100", 
                "Dimensity 1000", "Dimensity 900", "Dimensity 800", "Dimensity 700", 
                "Helio G96", "Helio G95", "Helio G90T", "Helio G85", "Helio G80", "Helio P95"],
    "Samsung": ["Exynos 2200", "Exynos 2100", "Exynos 1080", "Exynos 990", "Exynos 980", 
               "Exynos 850", "Exynos 9825", "Exynos 9820", "Exynos 9810"],
    "Apple": ["A15 Bionic", "A14 Bionic", "A13 Bionic", "A12 Bionic", "A11 Bionic"],
    "HiSilicon": ["Kirin 9000", "Kirin 990", "Kirin 980", "Kirin 970", "Kirin 9000E", 
                 "Kirin 985", "Kirin 820", "Kirin 810", "Kirin 710"]
}

cpu_cores = ["Quad-core", "Hexa-core", "Octa-core"]
cpu_speeds = [1.8, 2.0, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0, 3.1, 3.2]

# Camera configurations
camera_mp = [8, 12, 13, 16, 20, 24, 32, 48, 50, 64, 108]
camera_apertures = ["f/1.5", "f/1.6", "f/1.7", "f/1.8", "f/1.9", "f/2.0", "f/2.2", "f/2.4"]

# Battery capacities
battery_capacities = [3000, 3300, 3500, 3700, 4000, 4200, 4300, 4500, 4800, 5000, 5500, 6000]

# Memory configurations
ram_sizes = [3, 4, 6, 8, 12, 16]
storage_sizes = [32, 64, 128, 256, 512, 1024]

# Fast charging wattages
charging_watts = [15, 18, 25, 30, 33, 45, 50, 65, 80, 100, 120, 150]

def generate_model_number(manufacturer, series, year):
    """Generate a realistic model number"""
    if manufacturer == "Samsung" and series == "Galaxy S":
        return f"{series}{year-2010}"
    elif manufacturer == "Apple" and series == "iPhone":
        return f"{series} {year-2007}"
    else:
        return f"{series} {random.choice(['Pro', 'Plus', 'Ultra', 'Max', ''])} {random.randint(1, 20)}"

def generate_synthetic_phone(id):
    """Generate a synthetic smartphone specification"""
    manufacturer = random.choice(list(MANUFACTURERS.keys()))
    series = random.choice(MANUFACTURERS[manufacturer])
    
    # Generate release date between 2018 and 2023
    year = random.randint(2018, 2023)
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    release_date = f"{year}, {month:02d}/{day:02d}"
    
    # Model name
    model_number = generate_model_number(manufacturer, series, year)
    model_name = f"{manufacturer} {model_number}"
    
    # Display
    display_size = round(random.uniform(5.5, 7.0), 1)
    display_type = random.choice(display_types)
    display_hz = random.choice([60, 90, 120, 144])
    width_res = random.choice([720, 1080, 1440, 2160, 2400])
    height_res = int(width_res * random.uniform(1.9, 2.2))
    display_resolution = f"{width_res} x {height_res} pixels"
    
    # Processor
    processor_brand = random.choice(list(processor_brands.keys()))
    processor_model = random.choice(processor_brands[processor_brand])
    processor_chipset = f"{processor_brand} {processor_model}"
    cpu_core = random.choice(cpu_cores)
    cpu_speed = random.choice(cpu_speeds)
    processor_cpu = f"{cpu_core} {cpu_speed} GHz"
    
    # Camera
    main_camera_mp = random.choice(camera_mp)
    main_camera_aperture = random.choice(camera_apertures)
    secondary_camera = random.choice([True, False])
    secondary_camera_mp = random.choice(camera_mp) if secondary_camera else None
    main_camera = f"{main_camera_mp} MP, {main_camera_aperture}"
    
    # Battery
    battery_capacity = random.choice(battery_capacities)
    fast_charging = random.choice([True, False])
    fast_charging_wattage = random.choice(charging_watts) if fast_charging else None
    
    # Memory
    ram_size = random.choice(ram_sizes)
    storage_size = random.choice(storage_sizes)
    memory = f"{ram_size}GB RAM, {storage_size}GB storage"
    
    # Create the phone specification
    phone = {
        "id": id,
        "manufacturer": manufacturer,
        "series": series,
        "model_name": model_name,
        "release_date": release_date,
        "display_size": f"{display_size} inches",
        "display_type": f"{display_type}, {display_hz}Hz",
        "display_resolution": display_resolution,
        "processor_chipset": processor_chipset,
        "processor_cpu": processor_cpu,
        "main_camera": main_camera,
        "battery_capacity": f"{battery_capacity} mAh",
        "memory": memory
    }
    
    if secondary_camera:
        phone["secondary_camera"] = f"{secondary_camera_mp} MP"
    
    if fast_charging:
        phone["fast_charging_wattage"] = f"{fast_charging_wattage}W"
    
    return phone

def generate_phones(num_phones):
    """Generate a specified number of synthetic phones"""
    print(f"Generating {num_phones} synthetic smartphone specifications...")
    print(f"Output directory: {output_dir}")
    
    phones = []
    total_generated = 0
    start_time = time.time()
    batch_size = BATCH_SIZE
    
    for i in range(1, num_phones + 1):
        phone = generate_synthetic_phone(i)
        phones.append(phone)
        
        if i % batch_size == 0 or i == num_phones:
            # Save current batch
            batch_num = (i - 1) // batch_size + 1
            filename = os.path.join(output_dir, f"synthetic_phones_batch_{batch_num}.json")
            
            with open(filename, 'w') as f:
                json.dump(phones, f, indent=2)
            
            total_generated += len(phones)
            phones = []  # Clear the list for the next batch
            
            # Show progress
            elapsed_time = time.time() - start_time
            phones_per_second = total_generated / elapsed_time if elapsed_time > 0 else 0
            estimated_total_time = (num_phones / phones_per_second) if phones_per_second > 0 else 0
            remaining_time = estimated_total_time - elapsed_time
            
            print(f"Batch {batch_num}: Generated {total_generated}/{num_phones} phones " +
                  f"({(total_generated/num_phones*100):.1f}% complete)")
            print(f"Speed: {phones_per_second:.1f} phones/second | " +
                  f"Elapsed: {elapsed_time:.1f}s | " +
                  f"Remaining: {remaining_time:.1f}s")
    
    elapsed_time = time.time() - start_time
    print(f"Synthetic data generation complete!")
    print(f"Generated {total_generated} phones in {elapsed_time:.1f} seconds")
    print(f"Files saved to {output_dir}")

def main():
    # Check if number of phones is provided as command line argument
    if len(sys.argv) > 1:
        try:
            num_phones = int(sys.argv[1])
            print(f"Using command line argument: {num_phones} phones")
        except ValueError:
            print(f"Invalid argument. Using configured value: {NUM_PHONES} phones")
            num_phones = NUM_PHONES
    else:
        print(f"Using configured value: {NUM_PHONES} phones")
        num_phones = NUM_PHONES
    
    generate_phones(num_phones)

if __name__ == "__main__":
    main()
