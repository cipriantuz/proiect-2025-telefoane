"""
Strict Smartphone Deduplication

This script implements a more aggressive deduplication process specifically for 
smartphone data, focusing on model names and processors to eliminate duplicates.
"""

import os
import re
import time
from rdflib import Graph, Namespace, Literal, URIRef, BNode
from rdflib.namespace import RDF, RDFS, XSD, OWL

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")

def load_all_data():
    """Load all processed TTL files into a combined graph"""
    print("Loading all processed smartphone data...")
    
    # Find processed directory
    processed_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'processed')
    
    # Combined graph
    g = Graph()
    
    # Find all TTL files
    ttl_files = []
    for file in os.listdir(processed_dir):
        if file.endswith(".ttl"):
            ttl_files.append(os.path.join(processed_dir, file))
    
    # Load each file
    for ttl_file in ttl_files:
        print(f"Loading {os.path.basename(ttl_file)}...")
        g.parse(ttl_file, format='turtle')
    
    print(f"Loaded {len(g)} triples from {len(ttl_files)} files.")
    return g

def get_model_info(g, phone_uri):
    """Extract model name, manufacturer and processor info for a phone"""
    info = {'uri': phone_uri}
    
    # Get model name
    for _, _, model_name in g.triples((phone_uri, SMARTPHONE.hasModelName, None)):
        info['model_name'] = str(model_name)
    
    # Get manufacturer
    for _, _, manufacturer in g.triples((phone_uri, SMARTPHONE.manufacturedBy, None)):
        for _, _, brand_name in g.triples((manufacturer, SMARTPHONE.hasBrandName, None)):
            info['manufacturer'] = str(brand_name)
    
    # Get processor info
    for _, _, processor in g.triples((phone_uri, SMARTPHONE.hasProcessor, None)):
        for _, _, chipset in g.triples((processor, SMARTPHONE.hasChipsetModel, None)):
            info['processor'] = str(chipset)
    
    return info

def normalize_model_name(name):
    """Normalize a model name for better comparison"""
    if not name:
        return ""
    
    # Convert to lowercase
    normalized = name.lower()
    
    # Remove special characters
    normalized = re.sub(r'[^\w\s]', '', normalized)
    
    # Remove extra whitespace
    normalized = re.sub(r'\s+', ' ', normalized).strip()
    
    return normalized

def get_unique_key(phone_info):
    """Create a unique key for a phone based on its important attributes"""
    if 'model_name' not in phone_info:
        return None
    
    model = normalize_model_name(phone_info.get('model_name', ''))
    manufacturer = normalize_model_name(phone_info.get('manufacturer', ''))
    processor = normalize_model_name(phone_info.get('processor', ''))
    
    # Use both model name and processor to distinguish between variants
    key = f"{manufacturer}_{model}"
    if processor:
        key += f"_{processor}"
    
    return key

def deduplicate_smartphones():
    """Perform strict deduplication of smartphone data"""
    print("Starting strict smartphone deduplication...")
    start_time = time.time()
    
    # Load all data
    combined_graph = load_all_data()
    
    # Find all smartphones
    smartphones = []
    for phone_uri, _, _ in combined_graph.triples((None, RDF.type, SMARTPHONE.Smartphone)):
        info = get_model_info(combined_graph, phone_uri)
        if 'model_name' in info:
            key = get_unique_key(info)
            if key:
                smartphones.append((key, info))
    
    print(f"Found {len(smartphones)} smartphone entries")
    
    # Group phones by unique key
    phones_by_key = {}
    for key, info in smartphones:
        if key not in phones_by_key:
            phones_by_key[key] = []
        phones_by_key[key].append(info)
    
    print(f"Identified {len(phones_by_key)} unique smartphone models")
    
    # Select canonical URI for each unique phone
    canonical_uris = {}
    for key, phones in phones_by_key.items():
        # Prioritize URIs that don't have numeric IDs (they're often cleaner)
        preferred_uri = None
        for phone in phones:
            uri = phone['uri']
            uri_str = str(uri)
            # Look for clean URIs (not containing "Phone_" followed by numbers)
            if not re.search(r'Phone_\d+', uri_str):
                preferred_uri = uri
                break
        
        # If no preferred URI found, use the first one
        if not preferred_uri and phones:
            preferred_uri = phones[0]['uri']
        
        # Map all phone URIs to the canonical one
        for phone in phones:
            canonical_uris[phone['uri']] = preferred_uri
    
    print(f"Created mappings for {len(canonical_uris)} URIs to {len(phones_by_key)} canonical URIs")
    
    # Create a new graph with deduplicated data
    deduplicated_graph = Graph()
    
    # Bind namespaces
    for prefix, namespace in combined_graph.namespaces():
        deduplicated_graph.bind(prefix, namespace)
    
    # Copy all triples, replacing duplicate URIs with canonical ones
    for s, p, o in combined_graph:
        new_s = s
        new_o = o
        
        # Replace subject if it's a duplicate smartphone
        if s in canonical_uris:
            new_s = canonical_uris[s]
            
            # Skip component links for non-canonical URIs
            if s != new_s and p in [SMARTPHONE.hasDisplay, SMARTPHONE.hasProcessor,
                                    SMARTPHONE.hasBattery, SMARTPHONE.hasMainCamera,
                                    SMARTPHONE.hasMemoryConfiguration]:
                continue
        
        # Replace object if it's a duplicate smartphone
        if isinstance(o, URIRef) and o in canonical_uris:
            new_o = canonical_uris[o]
        
        # Add to deduplicated graph
        deduplicated_graph.add((new_s, p, new_o))
    
    # Add owl:sameAs links for duplicate phones
    for original_uri, canonical_uri in canonical_uris.items():
        if original_uri != canonical_uri:
            deduplicated_graph.add((canonical_uri, OWL.sameAs, original_uri))
    
    # Save the deduplicated graph
    processed_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'processed')
    output_file = os.path.join(processed_dir, "smartphone-data-strictly-deduplicated.ttl")
    
    print(f"Saving deduplicated graph to {output_file}")
    deduplicated_graph.serialize(destination=output_file, format='turtle')
    
    end_time = time.time()
    
    print(f"Deduplication complete!")
    print(f"Original graph: {len(combined_graph)} triples")
    print(f"Deduplicated graph: {len(deduplicated_graph)} triples")
    print(f"Processing time: {end_time - start_time:.2f} seconds")
    print(f"Output saved to: {output_file}")
    
    return output_file

if __name__ == "__main__":
    output_file = deduplicate_smartphones()
    print(f"Successfully created deduplicated dataset: {output_file}")
