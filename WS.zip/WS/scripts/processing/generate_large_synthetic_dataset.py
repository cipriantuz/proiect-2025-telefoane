"""
Smartphone Synthetic Dataset Generator

This script generates a large synthetic smartphone dataset with realistic
specifications and consistent data for use in the ontology project.
"""

import os
import json
import random
import time
from datetime import datetime, timedelta
from rdflib import Graph, Namespace, Literal, URIRef
from rdflib.namespace import RDF, RDFS, XSD, OWL

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")

# Define manufacturer data
MANUFACTURERS = [
    {"name": "Samsung", "series": ["Galaxy S", "Galaxy Note", "Galaxy A", "Galaxy M", "Galaxy Z"]},
    {"name": "Apple", "series": ["iPhone"]},
    {"name": "Xiaomi", "series": ["Mi", "Redmi", "POCO"]},
    {"name": "Huawei", "series": ["P", "Mate", "Nova"]},
    {"name": "Google", "series": ["Pixel"]},
    {"name": "OnePlus", "series": ["OnePlus"]},
    {"name": "Oppo", "series": ["Find", "Reno", "A"]},
    {"name": "Vivo", "series": ["X", "Y", "V"]},
    {"name": "Sony", "series": ["Xperia"]},
    {"name": "Motorola", "series": ["Moto G", "Moto E", "Edge"]},
    {"name": "Nokia", "series": ["Nokia"]},
    {"name": "LG", "series": ["G", "V", "K"]}
]

# Processor options
PROCESSORS = {
    "Qualcomm": [
        "Snapdragon 888", "Snapdragon 870", "Snapdragon 865", "Snapdragon 860",
        "Snapdragon 855", "Snapdragon 845", "Snapdragon 778G", "Snapdragon 765G",
        "Snapdragon 750G", "Snapdragon 732G", "Snapdragon 695", "Snapdragon 680"
    ],
    "MediaTek": [
        "Dimensity 9000", "Dimensity 8100", "Dimensity 1300", "Dimensity 1200",
        "Dimensity 1100", "Dimensity 900", "Dimensity 800", "Dimensity 700",
        "Helio G96", "Helio G95", "Helio G90T", "Helio G85"
    ],
    "Apple": [
        "A16 Bionic", "A15 Bionic", "A14 Bionic", "A13 Bionic", "A12 Bionic",
        "A11 Bionic", "A10 Fusion", "A9"
    ],
    "Samsung": [
        "Exynos 2200", "Exynos 2100", "Exynos 1280", "Exynos 1080",
        "Exynos 990", "Exynos 980", "Exynos 9825", "Exynos 9820"
    ],
    "Google": [
        "Tensor G2", "Tensor", "Snapdragon 765G", "Snapdragon 855"
    ]
}

# Display types
DISPLAY_TYPES = [
    "AMOLED", "Super AMOLED", "Dynamic AMOLED", "OLED", "Super AMOLED Plus",
    "IPS LCD", "TFT LCD", "Retina", "Super Retina XDR", "Liquid Retina"
]

# Operating Systems
OPERATING_SYSTEMS = {
    "Android": ["Android 13", "Android 12", "Android 11", "Android 10", "Android 9"],
    "iOS": ["iOS 16", "iOS 15", "iOS 14", "iOS 13", "iOS 12"]
}

# Year range for release dates
YEARS = range(2018, 2024)

def generate_model_number(manufacturer, series, year):
    """Generate a realistic model number based on manufacturer and series"""
    if manufacturer == "Samsung":
        if series == "Galaxy S":
            return f"Samsung Galaxy S{random.randint(10, 23)}"
        elif series == "Galaxy Note":
            return f"Samsung Galaxy Note {random.randint(10, 20)}"
        elif series == "Galaxy A":
            return f"Samsung Galaxy A{random.randint(10, 73)}"
        elif series == "Galaxy M":
            return f"Samsung Galaxy M{random.randint(10, 53)}"
        elif series == "Galaxy Z":
            fold_or_flip = random.choice(["Fold", "Flip"])
            return f"Samsung Galaxy Z {fold_or_flip} {random.randint(1, 4)}"
    
    elif manufacturer == "Apple":
        model_num = random.randint(8, 14)
        suffixes = ["", " Pro", " Pro Max", " Mini", " Plus"]
        suffix = random.choice(suffixes) if model_num >= 11 else ""
        return f"iPhone {model_num}{suffix}"
    
    elif manufacturer == "Xiaomi":
        if series == "Mi":
            return f"Xiaomi Mi {random.randint(8, 12)}"
        elif series == "Redmi":
            return f"Xiaomi Redmi Note {random.randint(7, 12)} Pro"
        elif series == "POCO":
            letter = random.choice(["F", "X", "M"])
            return f"Xiaomi POCO {letter}{random.randint(1, 4)}"
    
    elif manufacturer == "Google":
        model_num = random.randint(4, 7)
        suffixes = ["", " Pro", " XL", " Pro XL", " a"]
        suffix = random.choice(suffixes)
        return f"Google Pixel {model_num}{suffix}"
    
    elif manufacturer == "OnePlus":
        model_num = random.randint(7, 11)
        suffixes = ["", " Pro", " T", " R"]
        suffix = random.choice(suffixes)
        return f"OnePlus {model_num}{suffix}"
    
    # Generic format for other manufacturers
    return f"{manufacturer} {series} {random.randint(1, 50)}"

def generate_release_date(year):
    """Generate a random release date in the given year"""
    start_date = datetime(year, 1, 1)
    end_date = datetime(year, 12, 31)
    days_between = (end_date - start_date).days
    random_days = random.randint(0, days_between)
    release_date = start_date + timedelta(days=random_days)
    return release_date.strftime("%Y-%m-%d")

def generate_specs(manufacturer, year):
    """Generate realistic specs based on manufacturer and year"""
    # More recent phones have better specs
    year_factor = (year - 2017) / 6  # Normalize to 0-1 range for 2018-2023
    
    # RAM increases with year
    ram_sizes = [4, 6, 8, 12, 16]
    ram_weights = [
        max(0.5 - year_factor, 0),            # 4GB (decreases with year)
        max(0.7 - year_factor, 0.1),          # 6GB
        min(0.5 + year_factor, 0.9),          # 8GB (increases with year)
        min(0.2 + year_factor, 0.5),          # 12GB
        min(0.1 + year_factor * 2, 0.3)       # 16GB (rare, increases slowly)
    ]
    ram_size = random.choices(ram_sizes, weights=ram_weights)[0]
    
    # Storage increases with year
    storage_sizes = [64, 128, 256, 512, 1024]
    storage_weights = [
        max(0.6 - year_factor * 1.5, 0),      # 64GB (decreases rapidly with year)
        max(0.8 - year_factor * 0.5, 0.3),    # 128GB
        min(0.3 + year_factor, 0.8),          # 256GB (increases with year)
        min(0.1 + year_factor, 0.4),          # 512GB
        min(0.05 + year_factor * 0.5, 0.2)    # 1TB (increases slowly)
    ]
    storage_size = random.choices(storage_sizes, weights=storage_weights)[0]
    
    # Screen size tends to increase with year
    min_screen = 5.5 + year_factor * 0.5
    max_screen = 6.2 + year_factor * 0.7
    screen_size = round(random.uniform(min_screen, max_screen), 1)
    
    # Resolution depends on screen size
    resolutions = [
        "720 x 1280", "750 x 1334", "1080 x 1920", "1080 x 2340", 
        "1080 x 2400", "1440 x 2560", "1440 x 3120", "1440 x 3200"
    ]
    resolution_index = min(int((screen_size - 5) * 2) + year_factor * 3, len(resolutions) - 1)
    resolution = resolutions[int(resolution_index)]
    
    # Camera improves with year
    if manufacturer == "Apple":
        # Apple tends to have fewer MP but good quality
        main_camera_mp = random.randint(12, 12 + int(year_factor * 16))
    else:
        # Other manufacturers often have higher MP counts
        base_mp = 12 + int(year_factor * 36)
        variation = int(base_mp * 0.2)
        main_camera_mp = random.randint(base_mp - variation, base_mp + variation)
    
    # Battery increases with year and screen size
    min_battery = 3000 + year_factor * 1000 + (screen_size - 5.5) * 200
    max_battery = 4000 + year_factor * 1000 + (screen_size - 5.5) * 300
    battery_capacity = int(random.uniform(min_battery, max_battery) / 100) * 100  # Round to nearest 100
    
    # Processor selection
    if manufacturer == "Apple":
        processor_brand = "Apple"
    elif manufacturer == "Samsung":
        # Samsung uses both Exynos and Qualcomm
        processor_brand = random.choices(["Samsung", "Qualcomm"], weights=[0.4, 0.6])[0]
    elif manufacturer == "Google" and year >= 2021:
        # Google started using Tensor in 2021
        processor_brand = "Google"
    else:
        # Most other manufacturers use Qualcomm or MediaTek
        processor_brand = random.choices(["Qualcomm", "MediaTek"], weights=[0.7, 0.3])[0]
    
    # Select processor model based on year
    processor_index = min(int(year_factor * len(PROCESSORS[processor_brand])), len(PROCESSORS[processor_brand]) - 1)
    processor_model = PROCESSORS[processor_brand][processor_index]
    
    # Display type
    if manufacturer == "Apple":
        if year >= 2020:
            display_type = "Super Retina XDR"
        else:
            display_type = "Retina"
    elif manufacturer == "Samsung":
        display_type = random.choice(["AMOLED", "Super AMOLED", "Dynamic AMOLED"])
    else:
        if year >= 2020:
            # More AMOLED in recent years
            display_type = random.choices(DISPLAY_TYPES, weights=[0.3, 0.2, 0.1, 0.2, 0.1, 0.05, 0.05, 0, 0, 0])[0]
        else:
            # More LCD in earlier years
            display_type = random.choices(DISPLAY_TYPES, weights=[0.1, 0.1, 0.05, 0.05, 0.05, 0.3, 0.2, 0, 0, 0])[0]
    
    # Operating system
    if manufacturer == "Apple":
        os_type = "iOS"
    else:
        os_type = "Android"
    
    # OS version based on year
    os_index = min(int(year_factor * len(OPERATING_SYSTEMS[os_type])), len(OPERATING_SYSTEMS[os_type]) - 1)
    os_version = OPERATING_SYSTEMS[os_type][os_index]
    
    # Weight depends on screen size and year (phones getting lighter with time)
    base_weight = 150 + (screen_size - 5.5) * 30
    year_discount = (year - 2017) * 3  # Newer phones are slightly lighter
    weight = max(int(base_weight - year_discount), 135)
    
    return {
        "display_size": f"{screen_size} inches",
        "display_type": display_type,
        "display_resolution": resolution,
        "processor_chipset": processor_model,
        "processor_cpu": f"{random.choice([6, 8])} cores",
        "main_camera": f"{main_camera_mp} MP",
        "battery_capacity": f"{battery_capacity} mAh",
        "memory": f"{ram_size}GB RAM, {storage_size}GB storage",
        "weight": f"{weight} g",
        "operating_system": os_version
    }

def generate_synthetic_smartphones(count=500):
    """Generate a specified number of synthetic smartphone records"""
    print(f"Generating {count} synthetic smartphone records...")
    
    smartphones = []
    
    for i in range(count):
        if i % 50 == 0:
            print(f"Generated {i} smartphones...")
        
        # Select manufacturer and series
        manufacturer_data = random.choice(MANUFACTURERS)
        manufacturer = manufacturer_data["name"]
        series = random.choice(manufacturer_data["series"])
        
        # Select year considering distribution (more recent phones)
        year_weights = [0.05, 0.10, 0.15, 0.2, 0.25, 0.25]  # Weights for 2018-2023
        year = random.choices(list(YEARS), weights=year_weights)[0]
        
        # Generate model name
        model_name = generate_model_number(manufacturer, series, year)
        
        # Generate release date
        release_date = generate_release_date(year)
        
        # Generate specifications
        specs = generate_specs(manufacturer, year)
        
        # Create smartphone record
        smartphone = {
            "id": i + 1000,  # Start IDs from 1000
            "manufacturer": manufacturer,
            "model_name": model_name,
            "series": series,
            "release_date": release_date,
            **specs
        }
        
        smartphones.append(smartphone)
    
    print(f"Generated {len(smartphones)} synthetic smartphones.")
    return smartphones

def save_synthetic_data_as_json(smartphones, output_dir):
    """Save synthetic data as individual JSON files"""
    json_dir = os.path.join(output_dir, 'synthetic', 'json')
    os.makedirs(json_dir, exist_ok=True)
    
    print(f"Saving smartphone data to {json_dir}...")
    
    for smartphone in smartphones:
        filename = f"{smartphone['manufacturer']}_{smartphone['model_name'].replace(' ', '_')}_{smartphone['id']}.json"
        filepath = os.path.join(json_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(smartphone, f, indent=2)
    
    print(f"Saved {len(smartphones)} smartphone records to {json_dir}")

def convert_to_rdf(smartphones):
    """Convert synthetic smartphones to RDF format"""
    print("Converting synthetic data to RDF...")
    
    g = Graph()
    
    # Bind namespaces
    g.bind("smartphone", SMARTPHONE)
    
    # Track manufacturers and series to avoid duplication
    manufacturers = {}
    series = {}
    
    # Process all smartphones
    for smartphone in smartphones:
        try:
            manufacturer_name = smartphone.get('manufacturer')
            model_name = smartphone.get('model_name')
            series_name = smartphone.get('series')
            
            if not manufacturer_name or not model_name:
                continue
            
            # Create or reuse manufacturer URI
            if manufacturer_name not in manufacturers:
                manufacturer_uri = URIRef(SMARTPHONE + manufacturer_name.replace(' ', '_'))
                g.add((manufacturer_uri, RDF.type, SMARTPHONE.Manufacturer))
                g.add((manufacturer_uri, SMARTPHONE.hasBrandName, Literal(manufacturer_name)))
                manufacturers[manufacturer_name] = manufacturer_uri
            else:
                manufacturer_uri = manufacturers[manufacturer_name]
            
            # Create or reuse series URI
            series_key = f"{manufacturer_name}_{series_name}"
            if series_key not in series:
                series_uri = URIRef(SMARTPHONE + series_key.replace(' ', '_'))
                g.add((series_uri, RDF.type, SMARTPHONE.DeviceSeries))
                g.add((series_uri, RDFS.label, Literal(series_name)))
                g.add((series_uri, SMARTPHONE.manufacturedBy, manufacturer_uri))
                series[series_key] = series_uri
            else:
                series_uri = series[series_key]
            
            # Create smartphone instance with a unique ID
            phone_id = f"Synthetic_{manufacturer_name}_{model_name}".replace(' ', '_')
            smartphone_uri = URIRef(SMARTPHONE + phone_id)
            
            # Add basic properties
            g.add((smartphone_uri, RDF.type, SMARTPHONE.Smartphone))
            g.add((smartphone_uri, SMARTPHONE.hasModelName, Literal(model_name)))
            g.add((smartphone_uri, SMARTPHONE.manufacturedBy, manufacturer_uri))
            g.add((smartphone_uri, SMARTPHONE.belongsToSeries, series_uri))
            
            # Add release date
            if 'release_date' in smartphone:
                g.add((smartphone_uri, SMARTPHONE.hasReleaseDate, Literal(smartphone['release_date'])))
            
            # Add display information
            if 'display_size' in smartphone or 'display_type' in smartphone or 'display_resolution' in smartphone:
                display_uri = URIRef(SMARTPHONE + f"Display_{phone_id}")
                g.add((display_uri, RDF.type, SMARTPHONE.Display))
                g.add((smartphone_uri, SMARTPHONE.hasDisplay, display_uri))
                
                if 'display_size' in smartphone:
                    screen_size = float(smartphone['display_size'].split()[0])
                    g.add((display_uri, SMARTPHONE.hasScreenSize, Literal(screen_size, datatype=XSD.decimal)))
                
                if 'display_type' in smartphone:
                    g.add((display_uri, SMARTPHONE.hasDisplayType, Literal(smartphone['display_type'])))
                
                if 'display_resolution' in smartphone:
                    g.add((display_uri, SMARTPHONE.hasResolution, Literal(smartphone['display_resolution'])))
            
            # Add processor information
            if 'processor_chipset' in smartphone or 'processor_cpu' in smartphone:
                processor_uri = URIRef(SMARTPHONE + f"Processor_{phone_id}")
                g.add((processor_uri, RDF.type, SMARTPHONE.Processor))
                g.add((smartphone_uri, SMARTPHONE.hasProcessor, processor_uri))
                
                if 'processor_chipset' in smartphone:
                    g.add((processor_uri, SMARTPHONE.hasChipsetModel, Literal(smartphone['processor_chipset'])))
                
                if 'processor_cpu' in smartphone:
                    g.add((processor_uri, SMARTPHONE.hasCPUDetails, Literal(smartphone['processor_cpu'])))
                    
                    # Extract core count
                    if 'cores' in smartphone['processor_cpu']:
                        core_count = int(smartphone['processor_cpu'].split()[0])
                        g.add((processor_uri, SMARTPHONE.hasCoreCount, Literal(core_count, datatype=XSD.integer)))
            
            # Add camera information
            if 'main_camera' in smartphone:
                camera_uri = URIRef(SMARTPHONE + f"Camera_{phone_id}")
                g.add((camera_uri, RDF.type, SMARTPHONE.Camera))
                g.add((smartphone_uri, SMARTPHONE.hasMainCamera, camera_uri))
                
                # Extract megapixels
                if 'MP' in smartphone['main_camera']:
                    megapixels = float(smartphone['main_camera'].split()[0])
                    g.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(megapixels, datatype=XSD.decimal)))
            
            # Add battery information
            if 'battery_capacity' in smartphone:
                battery_uri = URIRef(SMARTPHONE + f"Battery_{phone_id}")
                g.add((battery_uri, RDF.type, SMARTPHONE.Battery))
                g.add((smartphone_uri, SMARTPHONE.hasBattery, battery_uri))
                
                # Extract capacity
                if 'mAh' in smartphone['battery_capacity']:
                    capacity = int(smartphone['battery_capacity'].split()[0])
                    g.add((battery_uri, SMARTPHONE.hasBatteryCapacity, Literal(capacity, datatype=XSD.integer)))
            
            # Add memory information
            if 'memory' in smartphone:
                memory_uri = URIRef(SMARTPHONE + f"Memory_{phone_id}")
                g.add((memory_uri, RDF.type, SMARTPHONE.Memory))
                g.add((smartphone_uri, SMARTPHONE.hasMemoryConfiguration, memory_uri))
                
                memory_text = smartphone['memory']
                
                # Extract RAM
                if 'RAM' in memory_text:
                    ram_size = int(memory_text.split('GB')[0])
                    g.add((memory_uri, SMARTPHONE.hasRAMSize, Literal(ram_size, datatype=XSD.integer)))
                
                # Extract storage
                if 'storage' in memory_text:
                    storage_size = int(memory_text.split('GB')[1].split('storage')[0].strip())
                    g.add((memory_uri, SMARTPHONE.hasStorageSize, Literal(storage_size, datatype=XSD.integer)))
            
            # Add operating system
            if 'operating_system' in smartphone:
                g.add((smartphone_uri, SMARTPHONE.hasOperatingSystem, Literal(smartphone['operating_system'])))
            
            # Add weight
            if 'weight' in smartphone:
                weight_text = smartphone['weight']
                weight = int(weight_text.split()[0])
                g.add((smartphone_uri, SMARTPHONE.hasWeight, Literal(weight, datatype=XSD.integer)))
                
        except Exception as e:
            print(f"Error processing smartphone {smartphone.get('model_name')}: {e}")
            continue
    
    return g

def main(count=1000):
    """Main function to generate synthetic data"""
    start_time = time.time()
    
    # Generate synthetic smartphone data
    smartphones = generate_synthetic_smartphones(count)
    
    # Set up output directory
    data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '..', 'data')
    
    # Save as JSON files
    save_synthetic_data_as_json(smartphones, data_dir)
    
    # Convert to RDF
    rdf_graph = convert_to_rdf(smartphones)
    
    # Create output directory
    processed_dir = os.path.join(data_dir, 'processed')
    os.makedirs(processed_dir, exist_ok=True)
    
    # Save the RDF graph
    output_file = os.path.join(processed_dir, "smartphone-data-synthetic.ttl")
    print(f"Saving synthetic smartphone data to {output_file}")
    rdf_graph.serialize(destination=output_file, format='turtle')
    
    print(f"Conversion complete. Generated {len(rdf_graph)} triples for {len(smartphones)} smartphones.")
    
    end_time = time.time()
    print(f"Total processing time: {end_time - start_time:.2f} seconds")
    
    return output_file

if __name__ == "__main__":
    import sys
    count = 1000
    if len(sys.argv) > 1:
        count = int(sys.argv[1])
    main(count)
