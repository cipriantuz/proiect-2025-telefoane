import json
import os
import glob
import re
from rdflib import Graph, Namespace, Literal, URIRef
from rdflib.namespace import RDF, RDFS, XSD

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")
SCHEMA = Namespace("http://schema.org/")
QUDT = Namespace("http://qudt.org/schema/qudt/")
TIME = Namespace("http://www.w3.org/2006/time#")

def clean_text(text):
    if not text:
        return ""
    return text.strip().replace('\n', ' ').replace('\r', '')

def extract_numeric_value(text, pattern=r'(\d+\.?\d*)'):
    if not text:
        return None
    match = re.search(pattern, text)
    return float(match.group(1)) if match else None

def process_files():
    g = Graph()
    
    # Bind namespaces
    g.bind("smartphone", SMARTPHONE)
    g.bind("schema", SCHEMA)
    g.bind("qudt", QUDT)
    g.bind("time", TIME)
    
    # Track manufacturers and series to avoid duplication
    manufacturers = {}
    series = {}
    
    # Process each JSON file
    json_files = glob.glob('../../data/raw/*.json')
    for json_file in json_files:
        with open(json_file, 'r') as f:
            data = json.load(f)
        
        manufacturer_name = clean_text(data.get('manufacturer'))
        model_name = clean_text(data.get('model_name'))
        
        if not manufacturer_name or not model_name:
            continue
        
        # Create or reuse manufacturer URI
        if manufacturer_name not in manufacturers:
            manufacturer_uri = URIRef(SMARTPHONE + manufacturer_name.replace(' ', '_'))
            g.add((manufacturer_uri, RDF.type, SMARTPHONE.Manufacturer))
            g.add((manufacturer_uri, SMARTPHONE.hasBrandName, Literal(manufacturer_name)))
            manufacturers[manufacturer_name] = manufacturer_uri
        else:
            manufacturer_uri = manufacturers[manufacturer_name]
        
        # Extract series name from model (e.g., "Galaxy S" from "Samsung Galaxy S21")
        series_pattern = r'(?:{})?\s*([\w\s]+?)\s*\d'.format(re.escape(manufacturer_name))
        series_match = re.search(series_pattern, model_name)
        series_name = series_match.group(1).strip() if series_match else "Unknown Series"
        
        # Create or reuse series URI
        series_key = f"{manufacturer_name}_{series_name}"
        if series_key not in series:
            series_uri = URIRef(SMARTPHONE + series_key.replace(' ', '_'))
            g.add((series_uri, RDF.type, SMARTPHONE.DeviceSeries))
            g.add((series_uri, RDFS.label, Literal(series_name)))
            g.add((series_uri, SMARTPHONE.manufacturedBy, manufacturer_uri))
            series[series_key] = series_uri
        else:
            series_uri = series[series_key]
        
        # Create smartphone instance
        phone_uri = URIRef(SMARTPHONE + model_name.replace(' ', '_'))
        g.add((phone_uri, RDF.type, SMARTPHONE.Smartphone))
        g.add((phone_uri, SMARTPHONE.hasModelName, Literal(model_name)))
        g.add((phone_uri, SMARTPHONE.manufacturedBy, manufacturer_uri))
        g.add((phone_uri, SMARTPHONE.belongsToSeries, series_uri))
        
        # Add release date if available
        if 'release_date' in data:
            release_date = clean_text(data['release_date'])
            g.add((phone_uri, SMARTPHONE.hasReleaseDate, Literal(release_date)))
        
        # Create and link display component
        if 'display_size' in data or 'display_type' in data or 'display_resolution' in data:
            display_uri = URIRef(SMARTPHONE + f"Display_{model_name.replace(' ', '_')}")
            g.add((display_uri, RDF.type, SMARTPHONE.Display))
            g.add((phone_uri, SMARTPHONE.hasDisplay, display_uri))
            
            if 'display_size' in data:
                display_size = clean_text(data['display_size'])
                size_value = extract_numeric_value(display_size)
                if size_value:
                    g.add((display_uri, SMARTPHONE.hasScreenSize, Literal(size_value, datatype=XSD.decimal)))
            
            if 'display_type' in data:
                display_type = clean_text(data['display_type'])
                g.add((display_uri, SMARTPHONE.hasDisplayType, Literal(display_type)))
            
            if 'display_resolution' in data:
                resolution = clean_text(data['display_resolution'])
                g.add((display_uri, SMARTPHONE.hasResolution, Literal(resolution)))
        
        # Create and link processor component
        if 'processor_chipset' in data or 'processor_cpu' in data:
            processor_uri = URIRef(SMARTPHONE + f"Processor_{model_name.replace(' ', '_')}")
            g.add((processor_uri, RDF.type, SMARTPHONE.Processor))
            g.add((phone_uri, SMARTPHONE.hasProcessor, processor_uri))
            
            if 'processor_chipset' in data:
                chipset = clean_text(data['processor_chipset'])
                g.add((processor_uri, SMARTPHONE.hasChipsetModel, Literal(chipset)))
            
            if 'processor_cpu' in data:
                cpu = clean_text(data['processor_cpu'])
                g.add((processor_uri, SMARTPHONE.hasCPUDetails, Literal(cpu)))
                
                # Try to extract core count
                core_pattern = r'(\d+)\s*core'
                core_match = re.search(core_pattern, cpu, re.IGNORECASE)
                if core_match:
                    core_count = int(core_match.group(1))
                    g.add((processor_uri, SMARTPHONE.hasCoreCount, Literal(core_count, datatype=XSD.integer)))
                
                # Try to extract clock speed
                clock_pattern = r'(\d+\.?\d*)\s*GHz'
                clock_match = re.search(clock_pattern, cpu, re.IGNORECASE)
                if clock_match:
                    clock_speed = float(clock_match.group(1))
                    g.add((processor_uri, SMARTPHONE.hasClockSpeed, Literal(clock_speed, datatype=XSD.decimal)))
        
        # Create and link camera component
        if 'main_camera' in data:
            camera_uri = URIRef(SMARTPHONE + f"Camera_{model_name.replace(' ', '_')}")
            g.add((camera_uri, RDF.type, SMARTPHONE.Camera))
            g.add((phone_uri, SMARTPHONE.hasMainCamera, camera_uri))
            
            main_camera = clean_text(data['main_camera'])
            g.add((camera_uri, RDFS.comment, Literal(main_camera)))
            
            # Try to extract megapixels
            mp_pattern = r'(\d+\.?\d*)\s*MP'
            mp_matches = re.findall(mp_pattern, main_camera, re.IGNORECASE)
            if mp_matches:
                primary_mp = float(mp_matches[0])
                g.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(primary_mp, datatype=XSD.decimal)))
            
            # Try to extract aperture
            aperture_pattern = r'f/(\d+\.?\d*)'
            aperture_match = re.search(aperture_pattern, main_camera, re.IGNORECASE)
            if aperture_match:
                aperture = aperture_match.group(0)
                g.add((camera_uri, SMARTPHONE.hasAperture, Literal(aperture)))
        
        # Create and link battery component
        if 'battery_capacity' in data:
            battery_uri = URIRef(SMARTPHONE + f"Battery_{model_name.replace(' ', '_')}")
            g.add((battery_uri, RDF.type, SMARTPHONE.Battery))
            g.add((phone_uri, SMARTPHONE.hasBattery, battery_uri))
            
            battery_capacity = clean_text(data['battery_capacity'])
            capacity_value = extract_numeric_value(battery_capacity)
            if capacity_value:
                g.add((battery_uri, SMARTPHONE.hasBatteryCapacity, Literal(int(capacity_value), datatype=XSD.integer)))
        
        # Create and link memory component
        if 'memory' in data:
            memory_uri = URIRef(SMARTPHONE + f"Memory_{model_name.replace(' ', '_')}")
            g.add((memory_uri, RDF.type, SMARTPHONE.Memory))
            g.add((phone_uri, SMARTPHONE.hasMemoryConfiguration, memory_uri))
            
            memory_text = clean_text(data['memory'])
            
            # Try to extract RAM
            ram_pattern = r'(\d+)\s*GB\s*RAM'
            ram_match = re.search(ram_pattern, memory_text, re.IGNORECASE)
            if ram_match:
                ram_size = int(ram_match.group(1))
                g.add((memory_uri, SMARTPHONE.hasRAMSize, Literal(ram_size, datatype=XSD.integer)))
            
            # Try to extract storage
            storage_pattern = r'(\d+)\s*GB\s*storage'
            storage_match = re.search(storage_pattern, memory_text, re.IGNORECASE)
            if storage_match:
                storage_size = int(storage_match.group(1))
                g.add((memory_uri, SMARTPHONE.hasStorageSize, Literal(storage_size, datatype=XSD.integer)))
    
    # Create output directory if it doesn't exist
    os.makedirs('../../data/processed', exist_ok=True)
    
    # Save the RDF graph in multiple formats
    g.serialize(destination='../../data/processed/smartphone-data.ttl', format='turtle')
    g.serialize(destination='../../data/processed/smartphone-data.rdf', format='xml')
    g.serialize(destination='../../data/processed/smartphone-data.json-ld', format='json-ld')
    
    print(f"Processed {len(json_files)} smartphone files.")
    print(f"Created RDF graph with {len(g)} triples.")
    print(f"Data saved to data/processed/ directory.")

if __name__ == "__main__":
    process_files()
