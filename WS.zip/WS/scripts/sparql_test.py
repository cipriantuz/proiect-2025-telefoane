from SPARQLWrapper import SPARQLWrapper, JSON
import os
import glob

def run_queries():
    sparql = SPARQLWrapper("http://localhost:3030/smartphones/sparql")
    sparql.setReturnFormat(JSON)
    
    query_files = glob.glob("../sparql/*.sparql")
    
    for query_file in query_files:
        query_name = os.path.basename(query_file).replace('.sparql', '')
        
        with open(query_file, 'r') as f:
            query = f.read()
        
        print(f"\nExecuting query: {query_name}")
        print("=" * 50)
        print(query)
        print("-" * 50)
        print("To execute this query:")
        print("1. Ensure Apache Jena Fuseki is running")
        print("2. Create a dataset named 'smartphones'")
        print("3. Upload the RDF data to the dataset")
        print("4. Use the Fuseki query interface to execute the query")
        print("\n")

if __name__ == "__main__":
    run_queries()
