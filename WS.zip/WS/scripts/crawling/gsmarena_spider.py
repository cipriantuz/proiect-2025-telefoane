import scrapy
import json
import os
import time
import random
from scrapy.spidermiddlewares.httperror import HttpError

class GSMArenaSpider(scrapy.Spider):
    name = "gsmarena"
    allowed_domains = ["gsmarena.com"]
    start_urls = ["https://www.gsmarena.com/makers.php3"]
    
    # Add custom settings to be more respectful to the website
    custom_settings = {
        'DOWNLOAD_DELAY': 5,  # Add a 5 second delay between requests
        'RANDOMIZE_DOWNLOAD_DELAY': True,  # Randomize the delay
        'CONCURRENT_REQUESTS': 1,  # Only make one request at a time
        'CONCURRENT_REQUESTS_PER_DOMAIN': 1,
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'ROBOTSTXT_OBEY': True,
        'RETRY_HTTP_CODES': [500, 502, 503, 504, 408, 429],  # Include 429 in retry codes
        'RETRY_TIMES': 5,  # Increase retry times
        'RETRY_DELAY': 10,  # Wait 10 seconds before retrying
        'HTTPERROR_ALLOWED_CODES': [429],  # Allow 429 responses to be processed
        # Limiting scope for test purposes
        'CLOSESPIDER_ITEMCOUNT': 5,  # Stop after collecting 5 items
    }
    
    def start_requests(self):
        """Start with just a few manufacturers for testing"""
        # We'll only crawl Apple and Samsung to avoid hitting rate limits
        manufacturers = [
            ('Apple', 'https://www.gsmarena.com/apple-phones-48.php'),
            ('Samsung', 'https://www.gsmarena.com/samsung-phones-9.php')
        ]
        
        for manufacturer_name, url in manufacturers:
            yield scrapy.Request(
                url,
                callback=self.parse_manufacturer,
                meta={'manufacturer': manufacturer_name},
                errback=self.handle_error
            )
    
    def parse(self, response):
        """Original parse method (not used in our limited version)"""
        # Extract all manufacturer links
        manufacturers = response.css('table a')
        for manufacturer in manufacturers:
            manufacturer_name = manufacturer.css('::text').get().strip()
            manufacturer_url = response.urljoin(manufacturer.attrib['href'])
            self.logger.info(f"Found manufacturer: {manufacturer_name}")
            
            # Add random delay before sending the request
            time.sleep(random.uniform(2, 5))
            
            yield scrapy.Request(
                manufacturer_url,
                callback=self.parse_manufacturer,
                meta={'manufacturer': manufacturer_name},
                errback=self.handle_error
            )
    
    def parse_manufacturer(self, response):
        manufacturer = response.meta['manufacturer']
        self.logger.info(f"Processing manufacturer: {manufacturer}")
        
        # Extract phone links for this manufacturer
        phones = response.css('div.makers ul li a')
        
        # Limit to just a few phones for testing
        for phone in phones[:2]:  # Only process 2 phones per manufacturer
            phone_name = phone.css('span::text').get().strip()
            phone_url = response.urljoin(phone.attrib['href'])
            self.logger.info(f"Found phone: {phone_name}")
            
            # Add random delay before sending the request
            time.sleep(random.uniform(2, 5))
            
            yield scrapy.Request(
                phone_url,
                callback=self.parse_phone,
                meta={
                    'manufacturer': manufacturer,
                    'phone_name': phone_name
                },
                errback=self.handle_error
            )
        
        # We'll skip pagination for now to limit requests
        # next_page = response.css('a.pages-next::attr(href)').get()
        # if next_page:
        #     yield scrapy.Request(
        #         response.urljoin(next_page),
        #         callback=self.parse_manufacturer,
        #         meta={'manufacturer': manufacturer}
        #     )
    
    def parse_phone(self, response):
        manufacturer = response.meta['manufacturer']
        phone_name = response.meta['phone_name']
        
        self.logger.info(f"Extracting data for: {manufacturer} {phone_name}")
        
        # Extract all specifications
        specs = {}
        specs['manufacturer'] = manufacturer
        specs['model_name'] = phone_name
        
        # General information
        release_date = response.css('span[data-spec="released-hl"]::text').get()
        if release_date:
            specs['release_date'] = release_date.strip()
        
        # Display information
        display_size = response.css('span[data-spec="displaysize-hl"]::text').get()
        if display_size:
            specs['display_size'] = display_size.strip()
        
        display_type = response.css('td.nfo:contains("Type") + td::text').get()
        if display_type:
            specs['display_type'] = display_type.strip()
        
        resolution = response.css('span[data-spec="displayres-hl"]::text').get()
        if resolution:
            specs['display_resolution'] = resolution.strip()
        
        # Processor
        chipset = response.css('td.nfo:contains("Chipset") + td::text').get()
        if chipset:
            specs['processor_chipset'] = chipset.strip()
        
        cpu = response.css('td.nfo:contains("CPU") + td::text').get()
        if cpu:
            specs['processor_cpu'] = cpu.strip()
        
        # Camera
        main_camera = response.css('td.nfo:contains("Main Camera") + td::text').get()
        if main_camera:
            specs['main_camera'] = main_camera.strip()
        
        # Battery
        battery = response.css('span[data-spec="batsize-hl"]::text').get()
        if battery:
            specs['battery_capacity'] = battery.strip()
        
        # Memory
        memory = response.css('td.nfo:contains("Internal") + td::text').get()
        if memory:
            specs['memory'] = memory.strip()
        
        # Save extracted data
        phone_id = response.url.split('.')[-2].split('_')[-1]
        # Ensure directory exists
        raw_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data', 'raw')
        os.makedirs(raw_dir, exist_ok=True)
        
        file_path = os.path.join(raw_dir, f"{manufacturer}_{phone_id}.json")
        with open(file_path, 'w') as f:
            json.dump(specs, f, indent=4)
            
        self.logger.info(f"Saved data to {file_path}")
        
        return specs
    
    def handle_error(self, failure):
        if failure.check(HttpError):
            response = failure.value.response
            self.logger.error(f"HttpError on {response.url}: {response.status}")
        else:
            self.logger.error(f"Error: {failure}")

# To run this spider:
# scrapy runspider gsmarena_spider.py
