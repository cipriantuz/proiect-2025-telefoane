import scrapy
import json
import os
import time
import random
from scrapy.spidermiddlewares.httperror import HttpError
from twisted.internet.error import DNSLookupError, TCPTimedOutError

class GSMArenaImprovedSpider(scrapy.Spider):
    name = "gsmarena_improved"
    allowed_domains = ["gsmarena.com"]
    
    # Very important settings for respecting the website
    custom_settings = {
        'DOWNLOAD_DELAY': 10,  # 10 second delay between requests - VERY important
        'RANDOMIZE_DOWNLOAD_DELAY': True,  # Randomize the delay
        'CONCURRENT_REQUESTS': 1,  # Only make one request at a time
        'CONCURRENT_REQUESTS_PER_DOMAIN': 1,
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'ROBOTSTXT_OBEY': True,
        'RETRY_HTTP_CODES': [500, 502, 503, 504, 408, 429],  # Include 429 in retry codes
        'RETRY_TIMES': 5,  # Increase retry times
        'RETRY_DELAY': 60,  # Wait 60 seconds before retrying
        'AUTOTHROTTLE_ENABLED': True,
        'AUTOTHROTTLE_START_DELAY': 5,
        'AUTOTHROTTLE_MAX_DELAY': 60,
        'AUTOTHROTTLE_TARGET_CONCURRENCY': 1.0,
        'HTTPERROR_ALLOWED_CODES': [404]  # Allow 404 for non-existent phones
    }
    
    # List of specific phones we want to crawl - focus on popular ones
    target_phones = [
        {'brand': 'Samsung', 'model': 'Galaxy S23 Ultra', 'url': 'https://www.gsmarena.com/samsung_galaxy_s23_ultra-12024.php'},
        {'brand': 'Apple', 'model': 'iPhone 14 Pro Max', 'url': 'https://www.gsmarena.com/apple_iphone_14_pro_max-11860.php'},
        {'brand': 'Google', 'model': 'Pixel 7 Pro', 'url': 'https://www.gsmarena.com/google_pixel_7_pro-11908.php'},
        {'brand': 'Xiaomi', 'model': 'Redmi Note 12 Pro', 'url': 'https://www.gsmarena.com/xiaomi_redmi_note_12_pro-12046.php'},
        {'brand': 'OnePlus', 'model': '10 Pro', 'url': 'https://www.gsmarena.com/oneplus_10_pro-11234.php'},
        {'brand': 'Sony', 'model': 'Xperia 1 V', 'url': 'https://www.gsmarena.com/sony_xperia_1_v-12263.php'},
        {'brand': 'Motorola', 'model': 'Edge 30 Ultra', 'url': 'https://www.gsmarena.com/motorola_edge_30_ultra-11206.php'},
        {'brand': 'Nothing', 'model': 'Phone 1', 'url': 'https://www.gsmarena.com/nothing_phone_1-11636.php'},
        {'brand': 'ASUS', 'model': 'ROG Phone 6', 'url': 'https://www.gsmarena.com/asus_rog_phone_6-11704.php'},
        {'brand': 'Oppo', 'model': 'Find X5 Pro', 'url': 'https://www.gsmarena.com/oppo_find_x5_pro-11283.php'},
        # Add more phones as needed
    ]
    
    def start_requests(self):
        """Start with specific phones to avoid overloading the site"""
        self.logger.info(f"Starting to crawl {len(self.target_phones)} specific phones")
        
        for phone in self.target_phones:
            yield scrapy.Request(
                phone['url'],
                callback=self.parse_phone,
                meta={
                    'manufacturer': phone['brand'],
                    'phone_name': phone['model'],
                    'dont_retry': False,  # Allow retries for these important phones
                },
                errback=self.handle_error
            )
    
    def parse_phone(self, response):
        manufacturer = response.meta['manufacturer']
        phone_name = response.meta['phone_name']
        
        self.logger.info(f"Successfully crawled: {manufacturer} {phone_name}")
        
        # Extract all specifications
        specs = {}
        specs['manufacturer'] = manufacturer
        specs['model_name'] = phone_name
        
        # General information
        release_date = response.css('span[data-spec="released-hl"]::text').get()
        if release_date:
            specs['release_date'] = release_date.strip()
        
        # Display information
        display_size = response.css('span[data-spec="displaysize-hl"]::text').get()
        if display_size:
            specs['display_size'] = display_size.strip()
        
        display_type = response.css('td.nfo:contains("Type") + td::text').get()
        if display_type:
            specs['display_type'] = display_type.strip()
        
        resolution = response.css('span[data-spec="displayres-hl"]::text').get()
        if resolution:
            specs['display_resolution'] = resolution.strip()
        
        # Processor
        chipset = response.css('td.nfo:contains("Chipset") + td::text').get()
        if chipset:
            specs['processor_chipset'] = chipset.strip()
        
        cpu = response.css('td.nfo:contains("CPU") + td::text').get()
        if cpu:
            specs['processor_cpu'] = cpu.strip()
        
        # Camera
        main_camera = response.css('td.nfo:contains("Main Camera") + td::text').get()
        if main_camera:
            specs['main_camera'] = main_camera.strip()
        
        selfie_camera = response.css('td.nfo:contains("Selfie Camera") + td::text').get()
        if selfie_camera:
            specs['secondary_camera'] = selfie_camera.strip()
        
        # Battery
        battery = response.css('span[data-spec="batsize-hl"]::text').get()
        if battery:
            specs['battery_capacity'] = battery.strip()
        
        # Memory
        memory_variants = []
        memory_elements = response.css('td.nfo:contains("Internal") + td').xpath('.//text()').getall()
        if memory_elements:
            memory_text = ''.join(memory_elements).strip()
            specs['memory'] = memory_text
            
            # Try to extract RAM and storage combinations
            import re
            ram_storage_patterns = re.findall(r'(\d+)\s*GB\s*RAM[,\s]+(\d+)\s*GB', memory_text)
            for ram, storage in ram_storage_patterns:
                memory_variants.append({"ram_gb": int(ram), "storage_gb": int(storage)})
            
            if memory_variants:
                specs['memory_variants'] = memory_variants
        
        # Save extracted data
        phone_id = response.url.split('.')[-2].split('_')[-1]
        
        # Ensure directory exists
        raw_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data', 'raw', 'gsmarena')
        os.makedirs(raw_dir, exist_ok=True)
        
        file_path = os.path.join(raw_dir, f"{manufacturer}_{phone_name.replace(' ', '_')}_{phone_id}.json")
        with open(file_path, 'w') as f:
            json.dump(specs, f, indent=4)
            
        self.logger.info(f"Saved detailed data for {manufacturer} {phone_name} to {file_path}")
        
        # Wait a bit before the next request to be extra careful
        self.logger.info(f"Waiting for 10-20 seconds before the next request...")
        time.sleep(random.uniform(10, 20))
        
        return specs
    
    def handle_error(self, failure):
        """Handle different errors during crawling"""
        if failure.check(HttpError):
            response = failure.value.response
            self.logger.error(f"HttpError on {response.url}: {response.status}")
            
            if response.status == 429:
                self.logger.error("Rate limited! Waiting for 2 minutes before retrying...")
                time.sleep(120)  # Wait 2 minutes if rate limited
                
        elif failure.check(DNSLookupError):
            request = failure.request
            self.logger.error(f"DNSLookupError on {request.url}")
        elif failure.check(TimeoutError, TCPTimedOutError):
            request = failure.request
            self.logger.error(f"TimeoutError on {request.url}")
        else:
            self.logger.error(f"Unhandled Error: {failure}")

# To run this spider:
# scrapy runspider gsmarena_improved_spider.py
