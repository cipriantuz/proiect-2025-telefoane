"""
Wikidata Smartphone Data Extractor

This script fetches smartphone data from Wikidata's SPARQL endpoint and 
converts it into a standardized RDF format aligned with our smartphone ontology.
"""

import os
import time
from SPARQLWrapper import SPARQLWrapper, JSON
from rdflib import Graph, Namespace, Literal, URIRef, BNode
from rdflib.namespace import RDF, RDFS, XSD, OWL, FOAF

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")
WD = Namespace("http://www.wikidata.org/entity/")
WDT = Namespace("http://www.wikidata.org/prop/direct/")
WDP = Namespace("http://www.wikidata.org/prop/")
SCHEMA = Namespace("http://schema.org/")
GR = Namespace("http://purl.org/goodrelations/v1#")

def fetch_smartphones_from_wikidata(limit=1000):
    """Fetch smartphone data from Wikidata's SPARQL endpoint"""
    print("Fetching smartphone data from Wikidata...")
    
    # Initialize SPARQLWrapper
    sparql = SPARQLWrapper("https://query.wikidata.org/sparql")
    sparql.setReturnFormat(JSON)
    
    # Construct SPARQL query
    query = """
    SELECT ?phone ?phoneLabel ?manufactureDate ?manufacturerLabel ?cpu ?cpuLabel ?weight ?memory ?screenSize ?cameraResolution ?operatingSystemLabel
    WHERE {
      # Get items that are instance of smartphone (Q22645)
      ?phone wdt:P31 wd:Q22645.
      
      # Get labels
      SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
      
      # Optional properties
      OPTIONAL { ?phone wdt:P571 ?manufactureDate. }
      OPTIONAL { ?phone wdt:P176 ?manufacturer. }
      OPTIONAL { ?phone wdt:P880 ?cpu. }
      OPTIONAL { ?phone wdt:P2910 ?weight. }
      OPTIONAL { ?phone wdt:P2928 ?memory. }
      OPTIONAL { ?phone wdt:P2910 ?screenSize. }
      OPTIONAL { ?phone wdt:P2670 ?cameraResolution. }
      OPTIONAL { ?phone wdt:P306 ?operatingSystem. }
    }
    LIMIT """ + str(limit)
    
    # Execute query
    sparql.setQuery(query)
    try:
        results = sparql.query().convert()
        return results["results"]["bindings"]
    except Exception as e:
        print(f"Error fetching data from Wikidata: {e}")
        return []

def clean_model_name(name):
    """Clean up model names to a standard format"""
    if not name:
        return "Unknown Model"
    
    # Remove common prefixes
    prefixes = [
        "Smartphone", "Mobile Phone", "Cellphone", "Phone", 
        "smartphone", "mobile phone", "cellphone", "phone"
    ]
    
    cleaned_name = name
    for prefix in prefixes:
        if cleaned_name.endswith(prefix):
            cleaned_name = cleaned_name[:-len(prefix)].strip()
        if cleaned_name.startswith(prefix):
            cleaned_name = cleaned_name[len(prefix):].strip()
    
    # Remove trailing whitespace and extra characters
    return cleaned_name.strip()

def wikidata_to_rdf():
    """Convert Wikidata smartphone data to our ontology format"""
    print("Starting Wikidata smartphone data conversion...")
    
    # Fetch data from Wikidata
    results = fetch_smartphones_from_wikidata()
    
    if not results:
        print("No results from Wikidata. Exiting.")
        return
    
    print(f"Retrieved {len(results)} smartphones from Wikidata.")
    
    # Create RDF graph
    g = Graph()
    
    # Bind namespaces
    g.bind("smartphone", SMARTPHONE)
    g.bind("wd", WD)
    g.bind("wdt", WDT)
    g.bind("schema", SCHEMA)
    g.bind("gr", GR)
    g.bind("owl", OWL)
    
    # Track manufacturers and series to avoid duplication
    manufacturers = {}
    series = {}
    
    # Process results
    for result in results:
        try:
            # Extract basic information
            phone_uri = result.get('phone', {}).get('value')
            if not phone_uri:
                continue
            
            phone_label = result.get('phoneLabel', {}).get('value') if 'phoneLabel' in result else None
            manufacturer_label = result.get('manufacturerLabel', {}).get('value') if 'manufacturerLabel' in result else None
            
            if not phone_label:
                continue
            
            # Clean up model name
            model_name = clean_model_name(phone_label)
            manufacturer_name = manufacturer_label if manufacturer_label else "Unknown Manufacturer"
            
            # Create or reuse manufacturer URI
            if manufacturer_name not in manufacturers:
                manf_uri = URIRef(SMARTPHONE + manufacturer_name.replace(' ', '_'))
                g.add((manf_uri, RDF.type, SMARTPHONE.Manufacturer))
                g.add((manf_uri, SMARTPHONE.hasBrandName, Literal(manufacturer_name)))
                manufacturers[manufacturer_name] = manf_uri
            else:
                manf_uri = manufacturers[manufacturer_name]
            
            # Determine series name (with basic heuristics)
            series_name = "Unknown Series"
            if "iPhone" in model_name:
                series_name = "iPhone"
            elif "Galaxy" in model_name:
                if "S" in model_name.split("Galaxy")[1][:2]:
                    series_name = "Galaxy S"
                elif "Note" in model_name.split("Galaxy")[1][:5]:
                    series_name = "Galaxy Note"
                elif "A" in model_name.split("Galaxy")[1][:2]:
                    series_name = "Galaxy A"
                else:
                    series_name = "Galaxy"
            elif "Pixel" in model_name:
                series_name = "Pixel"
            elif "OnePlus" in model_name:
                series_name = "OnePlus"
            
            # Create or reuse series URI
            series_key = f"{manufacturer_name}_{series_name}"
            if series_key not in series:
                series_uri = URIRef(SMARTPHONE + series_key.replace(' ', '_'))
                g.add((series_uri, RDF.type, SMARTPHONE.DeviceSeries))
                g.add((series_uri, RDFS.label, Literal(series_name)))
                g.add((series_uri, SMARTPHONE.manufacturedBy, manf_uri))
                series[series_key] = series_uri
            else:
                series_uri = series[series_key]
            
            # Create smartphone instance (generate a clean ID)
            phone_id = f"{manufacturer_name}_{model_name}".replace(' ', '_')
            smartphone_uri = URIRef(SMARTPHONE + phone_id)
            
            # Type information and basic properties
            g.add((smartphone_uri, RDF.type, SMARTPHONE.Smartphone))
            g.add((smartphone_uri, SMARTPHONE.hasModelName, Literal(model_name)))
            g.add((smartphone_uri, SMARTPHONE.manufacturedBy, manf_uri))
            g.add((smartphone_uri, SMARTPHONE.belongsToSeries, series_uri))
            g.add((smartphone_uri, OWL.sameAs, URIRef(phone_uri)))
            
            # Add release date if available
            if 'manufactureDate' in result:
                release_date = result['manufactureDate']['value']
                g.add((smartphone_uri, SMARTPHONE.hasReleaseDate, Literal(release_date)))
            
            # Process processor information
            if 'cpuLabel' in result and result['cpuLabel'].get('value'):
                processor_uri = URIRef(SMARTPHONE + f"Processor_{phone_id}")
                g.add((processor_uri, RDF.type, SMARTPHONE.Processor))
                g.add((smartphone_uri, SMARTPHONE.hasProcessor, processor_uri))
                g.add((processor_uri, SMARTPHONE.hasChipsetModel, Literal(result['cpuLabel']['value'])))
            
            # Process weight information
            if 'weight' in result and result['weight'].get('value'):
                try:
                    weight_value = float(result['weight']['value'])
                    g.add((smartphone_uri, SMARTPHONE.hasWeight, Literal(weight_value, datatype=XSD.decimal)))
                except (ValueError, TypeError):
                    pass
            
            # Process memory information
            if 'memory' in result and result['memory'].get('value'):
                memory_uri = URIRef(SMARTPHONE + f"Memory_{phone_id}")
                g.add((memory_uri, RDF.type, SMARTPHONE.Memory))
                g.add((smartphone_uri, SMARTPHONE.hasMemoryConfiguration, memory_uri))
                
                try:
                    # Wikidata often stores memory in bytes, convert to GB
                    memory_bytes = float(result['memory']['value'])
                    memory_gb = memory_bytes / (1024 * 1024 * 1024)
                    g.add((memory_uri, SMARTPHONE.hasRAMSize, Literal(int(memory_gb), datatype=XSD.integer)))
                except (ValueError, TypeError):
                    pass
            
            # Process screen size information (if available)
            if 'screenSize' in result and result['screenSize'].get('value'):
                display_uri = URIRef(SMARTPHONE + f"Display_{phone_id}")
                g.add((display_uri, RDF.type, SMARTPHONE.Display))
                g.add((smartphone_uri, SMARTPHONE.hasDisplay, display_uri))
                
                try:
                    screen_size = float(result['screenSize']['value'])
                    g.add((display_uri, SMARTPHONE.hasScreenSize, Literal(screen_size, datatype=XSD.decimal)))
                except (ValueError, TypeError):
                    pass
            
            # Process camera resolution
            if 'cameraResolution' in result and result['cameraResolution'].get('value'):
                camera_uri = URIRef(SMARTPHONE + f"Camera_{phone_id}")
                g.add((camera_uri, RDF.type, SMARTPHONE.Camera))
                g.add((smartphone_uri, SMARTPHONE.hasMainCamera, camera_uri))
                
                try:
                    # Wikidata often stores camera resolution in megapixels
                    camera_mp = float(result['cameraResolution']['value'])
                    g.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(camera_mp, datatype=XSD.decimal)))
                except (ValueError, TypeError):
                    pass
            
            # Process OS information
            if 'operatingSystemLabel' in result and result['operatingSystemLabel'].get('value'):
                os_value = result['operatingSystemLabel']['value']
                g.add((smartphone_uri, SMARTPHONE.hasOperatingSystem, Literal(os_value)))
        
        except Exception as e:
            print(f"Error processing result: {e}")
            continue
    
    # Create output directory
    processed_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'processed')
    os.makedirs(processed_dir, exist_ok=True)
    
    # Save the RDF graph
    output_file = os.path.join(processed_dir, "smartphone-data-wikidata.ttl")
    print(f"Saving Wikidata smartphone data to {output_file}")
    g.serialize(destination=output_file, format='turtle')
    
    print(f"Conversion complete. Generated {len(g)} triples for {len(results)} smartphones.")
    return output_file

if __name__ == "__main__":
    start_time = time.time()
    output_file = wikidata_to_rdf()
    end_time = time.time()
    print(f"Total processing time: {end_time - start_time:.2f} seconds")
