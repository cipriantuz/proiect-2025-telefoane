"""
PhoneArena Direct Web Scraper

This script scrapes smartphone data directly from PhoneArena.com,
which has comprehensive and structured information about hundreds of smartphones.
The script extracts data without depending on their API and converts it to RDF format.
"""

import os
import time
import json
import random
import re
from datetime import datetime
import requests
from bs4 import BeautifulSoup
from rdflib import Graph, Namespace, Literal, URIRef
from rdflib.namespace import RDF, RDFS, XSD, OWL

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")
SCHEMA = Namespace("http://schema.org/")

# Constants
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0'
]

def get_random_user_agent():
    """Return a random user agent"""
    return random.choice(USER_AGENTS)

def fetch_with_retry(url, max_retries=3, initial_delay=2):
    """Fetch a URL with retry logic and random user agents"""
    headers = {
        'User-Agent': get_random_user_agent(),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'https://www.google.com/',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'cross-site',
        'Sec-Fetch-User': '?1',
        'Cache-Control': 'max-age=0'
    }
    
    for attempt in range(max_retries):
        try:
            # Add random delay to avoid rate limiting
            time.sleep(random.uniform(1, 3))
            
            response = requests.get(url, headers=headers, timeout=30)
            
            if response.status_code == 200:
                return response
            
            # Handle rate limiting with exponential backoff
            if response.status_code == 429 or response.status_code >= 500:
                delay = initial_delay * (2 ** attempt) + random.uniform(0, 1)
                print(f"Rate limited or server error (HTTP {response.status_code}). Retrying in {delay:.2f} seconds...")
                time.sleep(delay)
                continue
            
            # Other error
            print(f"Error: HTTP {response.status_code}")
            return None
            
        except Exception as e:
            print(f"Request failed: {e}")
            delay = initial_delay * (2 ** attempt) + random.uniform(0, 1)
            print(f"Retrying in {delay:.2f} seconds...")
            time.sleep(delay)
    
    print(f"Failed after {max_retries} attempts")
    return None

def scrape_manufacturer_list():
    """Scrape the list of smartphone manufacturers from PhoneArena"""
    print("Scraping smartphone manufacturers from PhoneArena...")
    
    url = "https://www.phonearena.com/phones/manufacturers"
    response = fetch_with_retry(url)
    
    if not response:
        print("Failed to fetch manufacturer list")
        return []
    
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find manufacturer links
    manufacturer_links = soup.select('div.manufacturers-list a')
    
    manufacturers = []
    for link in manufacturer_links:
        name = link.text.strip()
        url = link['href']
        manufacturers.append((name, url))
    
    print(f"Found {len(manufacturers)} smartphone manufacturers")
    return manufacturers

def scrape_phones_for_manufacturer(manufacturer_url):
    """Scrape phones for a specific manufacturer"""
    print(f"Scraping phones from: {manufacturer_url}")
    
    response = fetch_with_retry(manufacturer_url)
    
    if not response:
        print(f"Failed to fetch phones for {manufacturer_url}")
        return []
    
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find phone links
    phone_links = soup.select('div.stream-item a.stream-item__title')
    
    phones = []
    for link in phone_links:
        name = link.text.strip()
        url = link['href']
        phones.append((name, url))
    
    print(f"Found {len(phones)} phones for {manufacturer_url}")
    return phones

def scrape_phone_details(phone_url):
    """Scrape detailed specifications for a specific phone"""
    print(f"Scraping details from: {phone_url}")
    
    response = fetch_with_retry(phone_url)
    
    if not response:
        print(f"Failed to fetch details for {phone_url}")
        return {}
    
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Extract basic information
    phone_details = {}
    
    # Model name
    title_elem = soup.select_one('h1.page-title')
    if title_elem:
        phone_details['model_name'] = title_elem.text.strip()
    
    # Extract specifications from the specs table
    specs_sections = soup.select('section.specs-list')
    
    for section in specs_sections:
        # Get section title
        section_title = section.select_one('h3')
        if section_title:
            section_name = section_title.text.strip().lower()
            
            # Process each specification in this section
            specs = section.select('div.specs-detail')
            for spec in specs:
                label_elem = spec.select_one('div.specs-detail__name')
                value_elem = spec.select_one('div.specs-detail__value')
                
                if label_elem and value_elem:
                    label = label_elem.text.strip().lower().replace(' ', '_')
                    value = value_elem.text.strip()
                    
                    # Store with section prefix
                    phone_details[f"{section_name}_{label}"] = value
    
    # Extract release date
    if 'info_release_date' in phone_details:
        release_date = phone_details['info_release_date']
        # Try to parse the date
        try:
            # Various date formats
            date_formats = ['%B %d, %Y', '%B %Y', '%Y']
            for fmt in date_formats:
                try:
                    parsed_date = datetime.strptime(release_date, fmt)
                    phone_details['release_date'] = parsed_date.strftime('%Y-%m-%d')
                    break
                except ValueError:
                    continue
        except Exception as e:
            print(f"Error parsing date '{release_date}': {e}")
    
    # Map common fields to our ontology properties
    field_mapping = {
        'display_size': 'display_display_size',
        'display_type': 'display_technology',
        'display_resolution': 'display_resolution',
        'processor_chipset': 'hardware_processor',
        'processor_cpu': 'hardware_system_chip',
        'main_camera': 'camera_camera',
        'battery_capacity': 'battery_capacity',
        'memory': 'hardware_ram',
        'storage': 'hardware_built-in_storage',
        'operating_system': 'software_operating_system',
        'weight': 'design_weight',
    }
    
    # Normalize fields using mapping
    normalized_details = {}
    normalized_details['model_name'] = phone_details.get('model_name', '')
    normalized_details['manufacturer'] = phone_details.get('info_manufacturer', '')
    normalized_details['release_date'] = phone_details.get('release_date', '')
    
    for our_field, pa_field in field_mapping.items():
        if pa_field in phone_details:
            normalized_details[our_field] = phone_details[pa_field]
    
    # Extract numeric values
    if 'display_size' in normalized_details:
        match = re.search(r'(\d+\.?\d*)"', normalized_details['display_size'])
        if match:
            normalized_details['display_size'] = match.group(1)
    
    if 'battery_capacity' in normalized_details:
        match = re.search(r'(\d+)\s*mAh', normalized_details['battery_capacity'])
        if match:
            normalized_details['battery_capacity'] = match.group(1)
    
    if 'main_camera' in normalized_details:
        match = re.search(r'(\d+)\s*MP', normalized_details['main_camera'])
        if match:
            normalized_details['main_camera'] = match.group(1) + " MP"
    
    if 'memory' in normalized_details:
        match = re.search(r'(\d+)\s*GB', normalized_details['memory'])
        if match:
            normalized_details['memory'] = match.group(1) + "GB RAM"
    
    if 'storage' in normalized_details:
        match = re.search(r'(\d+)\s*GB', normalized_details['storage'])
        if match:
            storage_gb = match.group(1)
            if 'memory' in normalized_details:
                normalized_details['memory'] += f", {storage_gb}GB storage"
            else:
                normalized_details['memory'] = f"{storage_gb}GB storage"
    
    if 'weight' in normalized_details:
        match = re.search(r'(\d+\.?\d*)\s*oz', normalized_details['weight'])
        if match:
            # Convert oz to g
            weight_oz = float(match.group(1))
            weight_g = int(weight_oz * 28.35)
            normalized_details['weight'] = f"{weight_g} g"
    
    return normalized_details

def extract_series_name(manufacturer, model_name):
    """Extract series name from model name"""
    # Apple
    if manufacturer.lower() == "apple":
        if "iphone" in model_name.lower():
            return "iPhone"
    
    # Samsung
    elif manufacturer.lower() == "samsung":
        if "galaxy s" in model_name.lower():
            return "Galaxy S"
        elif "galaxy note" in model_name.lower():
            return "Galaxy Note"
        elif "galaxy a" in model_name.lower():
            return "Galaxy A"
        elif "galaxy z" in model_name.lower():
            return "Galaxy Z"
    
    # Google
    elif manufacturer.lower() == "google":
        if "pixel" in model_name.lower():
            return "Pixel"
    
    # OnePlus
    elif manufacturer.lower() == "oneplus":
        return "OnePlus"
    
    # Xiaomi
    elif manufacturer.lower() == "xiaomi":
        if "redmi note" in model_name.lower():
            return "Redmi Note"
        elif "redmi" in model_name.lower():
            return "Redmi"
        elif "poco" in model_name.lower():
            return "POCO"
        elif "mi" in model_name.lower():
            return "Mi"
    
    # Generic case
    parts = model_name.split()
    if len(parts) > 1:
        return parts[0]
    
    return "Unknown Series"

def phone_to_rdf(phone_details, graph, manufacturer_map, series_map):
    """Convert phone details to RDF triples"""
    if not phone_details or 'model_name' not in phone_details or 'manufacturer' not in phone_details:
        return None
    
    manufacturer_name = phone_details['manufacturer']
    model_name = phone_details['model_name']
    
    # Create or reuse manufacturer URI
    if manufacturer_name not in manufacturer_map:
        manf_uri = URIRef(SMARTPHONE + manufacturer_name.replace(' ', '_'))
        graph.add((manf_uri, RDF.type, SMARTPHONE.Manufacturer))
        graph.add((manf_uri, SMARTPHONE.hasBrandName, Literal(manufacturer_name)))
        manufacturer_map[manufacturer_name] = manf_uri
    else:
        manf_uri = manufacturer_map[manufacturer_name]
    
    # Determine series name
    series_name = extract_series_name(manufacturer_name, model_name)
    
    # Create or reuse series URI
    series_key = f"{manufacturer_name}_{series_name}"
    if series_key not in series_map:
        series_uri = URIRef(SMARTPHONE + series_key.replace(' ', '_'))
        graph.add((series_uri, RDF.type, SMARTPHONE.DeviceSeries))
        graph.add((series_uri, RDFS.label, Literal(series_name)))
        graph.add((series_uri, SMARTPHONE.manufacturedBy, manf_uri))
        series_map[series_key] = series_uri
    else:
        series_uri = series_map[series_key]
    
    # Create smartphone URI
    phone_id = f"PhoneArena_{manufacturer_name}_{model_name}".replace(' ', '_')
    smartphone_uri = URIRef(SMARTPHONE + phone_id)
    
    # Basic properties
    graph.add((smartphone_uri, RDF.type, SMARTPHONE.Smartphone))
    graph.add((smartphone_uri, SMARTPHONE.hasModelName, Literal(model_name)))
    graph.add((smartphone_uri, SMARTPHONE.manufacturedBy, manf_uri))
    graph.add((smartphone_uri, SMARTPHONE.belongsToSeries, series_uri))
    
    # Add release date
    if 'release_date' in phone_details and phone_details['release_date']:
        graph.add((smartphone_uri, SMARTPHONE.hasReleaseDate, Literal(phone_details['release_date'])))
    
    # Add display information
    if 'display_size' in phone_details or 'display_type' in phone_details or 'display_resolution' in phone_details:
        display_uri = URIRef(SMARTPHONE + f"Display_{phone_id}")
        graph.add((display_uri, RDF.type, SMARTPHONE.Display))
        graph.add((smartphone_uri, SMARTPHONE.hasDisplay, display_uri))
        
        if 'display_size' in phone_details:
            try:
                screen_size = float(phone_details['display_size'])
                graph.add((display_uri, SMARTPHONE.hasScreenSize, Literal(screen_size, datatype=XSD.decimal)))
            except (ValueError, TypeError):
                pass
        
        if 'display_type' in phone_details:
            graph.add((display_uri, SMARTPHONE.hasDisplayType, Literal(phone_details['display_type'])))
        
        if 'display_resolution' in phone_details:
            graph.add((display_uri, SMARTPHONE.hasResolution, Literal(phone_details['display_resolution'])))
    
    # Add processor information
    if 'processor_chipset' in phone_details or 'processor_cpu' in phone_details:
        processor_uri = URIRef(SMARTPHONE + f"Processor_{phone_id}")
        graph.add((processor_uri, RDF.type, SMARTPHONE.Processor))
        graph.add((smartphone_uri, SMARTPHONE.hasProcessor, processor_uri))
        
        if 'processor_chipset' in phone_details:
            graph.add((processor_uri, SMARTPHONE.hasChipsetModel, Literal(phone_details['processor_chipset'])))
        
        if 'processor_cpu' in phone_details:
            graph.add((processor_uri, SMARTPHONE.hasCPUDetails, Literal(phone_details['processor_cpu'])))
    
    # Add camera information
    if 'main_camera' in phone_details:
        camera_uri = URIRef(SMARTPHONE + f"Camera_{phone_id}")
        graph.add((camera_uri, RDF.type, SMARTPHONE.Camera))
        graph.add((smartphone_uri, SMARTPHONE.hasMainCamera, camera_uri))
        
        # Extract megapixels
        mp_match = re.search(r'(\d+)', phone_details['main_camera'])
        if mp_match:
            mp_value = float(mp_match.group(1))
            graph.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(mp_value, datatype=XSD.decimal)))
    
    # Add battery information
    if 'battery_capacity' in phone_details:
        battery_uri = URIRef(SMARTPHONE + f"Battery_{phone_id}")
        graph.add((battery_uri, RDF.type, SMARTPHONE.Battery))
        graph.add((smartphone_uri, SMARTPHONE.hasBattery, battery_uri))
        
        # Extract capacity
        try:
            capacity_value = int(phone_details['battery_capacity'])
            graph.add((battery_uri, SMARTPHONE.hasBatteryCapacity, Literal(capacity_value, datatype=XSD.integer)))
        except (ValueError, TypeError):
            pass
    
    # Add memory information
    if 'memory' in phone_details:
        memory_uri = URIRef(SMARTPHONE + f"Memory_{phone_id}")
        graph.add((memory_uri, RDF.type, SMARTPHONE.Memory))
        graph.add((smartphone_uri, SMARTPHONE.hasMemoryConfiguration, memory_uri))
        
        # Extract RAM size
        ram_match = re.search(r'(\d+)GB RAM', phone_details['memory'])
        if ram_match:
            ram_size = int(ram_match.group(1))
            graph.add((memory_uri, SMARTPHONE.hasRAMSize, Literal(ram_size, datatype=XSD.integer)))
        
        # Extract storage size
        storage_match = re.search(r'(\d+)GB storage', phone_details['memory'])
        if storage_match:
            storage_size = int(storage_match.group(1))
            graph.add((memory_uri, SMARTPHONE.hasStorageSize, Literal(storage_size, datatype=XSD.integer)))
    
    # Add operating system
    if 'operating_system' in phone_details:
        graph.add((smartphone_uri, SMARTPHONE.hasOperatingSystem, Literal(phone_details['operating_system'])))
    
    # Add weight
    if 'weight' in phone_details:
        weight_match = re.search(r'(\d+)', phone_details['weight'])
        if weight_match:
            weight_value = int(weight_match.group(1))
            graph.add((smartphone_uri, SMARTPHONE.hasWeight, Literal(weight_value, datatype=XSD.integer)))
    
    return smartphone_uri

def scrape_phonearena():
    """Main function to scrape PhoneArena and convert to RDF"""
    print("Starting PhoneArena smartphone data collection...")
    
    # Create RDF graph
    g = Graph()
    
    # Bind namespaces
    g.bind("smartphone", SMARTPHONE)
    g.bind("schema", SCHEMA)
    
    # Track manufacturers and series to avoid duplication
    manufacturer_map = {}
    series_map = {}
    
    # Limit number of phones per manufacturer
    max_phones_per_manufacturer = 20  # Adjust as needed
    
    # Get top manufacturers - limiting to a few to avoid too much scraping
    top_manufacturers = [
        ("Apple", "https://www.phonearena.com/phones/manufacturers/Apple"),
        ("Samsung", "https://www.phonearena.com/phones/manufacturers/Samsung"),
        ("Google", "https://www.phonearena.com/phones/manufacturers/Google"),
        ("Xiaomi", "https://www.phonearena.com/phones/manufacturers/Xiaomi"),
        ("OnePlus", "https://www.phonearena.com/phones/manufacturers/OnePlus")
    ]
    
    # Alternative: uncomment to scrape all manufacturers (will take longer)
    # top_manufacturers = scrape_manufacturer_list()
    
    phone_count = 0
    
    for manufacturer_name, manufacturer_url in top_manufacturers:
        print(f"\nProcessing manufacturer: {manufacturer_name}")
        
        # Get phones for this manufacturer
        phones = scrape_phones_for_manufacturer(manufacturer_url)
        
        # Limit number of phones
        phones = phones[:max_phones_per_manufacturer]
        
        # Process each phone
        for i, (phone_name, phone_url) in enumerate(phones):
            try:
                print(f"Processing phone {i+1}/{len(phones)}: {phone_name}")
                
                # Get phone details
                phone_details = scrape_phone_details(phone_url)
                
                # Ensure manufacturer name is set
                if 'manufacturer' not in phone_details or not phone_details['manufacturer']:
                    phone_details['manufacturer'] = manufacturer_name
                
                # Convert to RDF
                smartphone_uri = phone_to_rdf(phone_details, g, manufacturer_map, series_map)
                
                if smartphone_uri:
                    phone_count += 1
                
                # Add delay to avoid rate limiting
                time.sleep(random.uniform(2, 4))
                
            except Exception as e:
                print(f"Error processing phone {phone_name}: {e}")
                continue
    
    # Create output directory
    processed_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'processed')
    os.makedirs(processed_dir, exist_ok=True)
    
    # Save the RDF graph
    output_file = os.path.join(processed_dir, "smartphone-data-phonearena.ttl")
    print(f"Saving PhoneArena smartphone data to {output_file}")
    g.serialize(destination=output_file, format='turtle')
    
    print(f"Scraping complete. Generated {len(g)} triples for {phone_count} smartphones.")
    return output_file

if __name__ == "__main__":
    start_time = time.time()
    output_file = scrape_phonearena()
    end_time = time.time()
    print(f"Total processing time: {end_time - start_time:.2f} seconds")
