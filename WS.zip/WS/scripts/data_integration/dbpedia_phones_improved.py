"""
Improved DBpedia Smartphone Data Extractor

This script uses a more robust approach to fetch smartphone data from DBpedia:
1. Uses multiple focused queries instead of one large query
2. Implements retry mechanism with exponential backoff
3. Handles pagination to retrieve more results
4. Better progress reporting and error handling
"""

import os
import time
import json
import random
from rdflib import Graph, Namespace, Literal, URIRef, BNode
from rdflib.namespace import RDF, RDFS, XSD, OWL, FOAF
import requests

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")
DBO = Namespace("http://dbpedia.org/ontology/")
DBR = Namespace("http://dbpedia.org/resource/")
DBP = Namespace("http://dbpedia.org/property/")
SCHEMA = Namespace("http://schema.org/")
GR = Namespace("http://purl.org/goodrelations/v1#")

def fetch_with_retry(endpoint, query, max_retries=3, initial_delay=2):
    """Execute a SPARQL query with retry logic"""
    headers = {
        'Accept': 'application/sparql-results+json',
        'User-Agent': 'WS-Project-Smartphone-Ontology/1.0'
    }
    
    params = {
        'query': query,
        'format': 'json'
    }
    
    for attempt in range(max_retries):
        try:
            response = requests.get(endpoint, headers=headers, params=params, timeout=30)
            
            if response.status_code == 200:
                return response.json()
            
            # Handle rate limiting with exponential backoff
            if response.status_code == 429 or response.status_code >= 500:
                delay = initial_delay * (2 ** attempt) + random.uniform(0, 1)
                print(f"Rate limited or server error (HTTP {response.status_code}). Retrying in {delay:.2f} seconds...")
                time.sleep(delay)
                continue
            
            # Other error
            print(f"Error: HTTP {response.status_code}: {response.text[:200]}...")
            return None
        
        except Exception as e:
            print(f"Request failed: {e}")
            delay = initial_delay * (2 ** attempt) + random.uniform(0, 1)
            print(f"Retrying in {delay:.2f} seconds...")
            time.sleep(delay)
    
    print(f"Failed after {max_retries} attempts")
    return None

def fetch_smartphone_brands():
    """Fetch major smartphone manufacturers from DBpedia"""
    print("Fetching smartphone manufacturers...")
    
    endpoint = "https://dbpedia.org/sparql"
    
    query = """
    PREFIX dbo: <http://dbpedia.org/ontology/>
    PREFIX dbp: <http://dbpedia.org/property/>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT DISTINCT ?manufacturer ?label
    WHERE {
      {
        ?phone a dbo:MobilePhone .
        ?phone dbo:manufacturer ?manufacturer .
      } UNION {
        ?phone a dbo:Smartphone .
        ?phone dbo:manufacturer ?manufacturer .
      }
      
      OPTIONAL { 
        ?manufacturer rdfs:label ?label .
        FILTER(LANG(?label) = 'en')
      }
    }
    """
    
    results = fetch_with_retry(endpoint, query)
    
    if not results or 'results' not in results:
        return []
    
    manufacturers = []
    for result in results['results']['bindings']:
        if 'manufacturer' in result:
            manufacturer_uri = result['manufacturer']['value']
            label = result.get('label', {}).get('value', None)
            manufacturers.append((manufacturer_uri, label))
    
    print(f"Found {len(manufacturers)} smartphone manufacturers")
    return manufacturers

def fetch_phones_by_manufacturer(manufacturer_uri, limit=50, offset=0):
    """Fetch smartphones for a specific manufacturer"""
    print(f"Fetching phones for manufacturer: {manufacturer_uri} (limit={limit}, offset={offset})...")
    
    endpoint = "https://dbpedia.org/sparql"
    
    query = f"""
    PREFIX dbo: <http://dbpedia.org/ontology/>
    PREFIX dbp: <http://dbpedia.org/property/>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT DISTINCT ?phone ?label
    WHERE {{
      {{
        ?phone a dbo:MobilePhone .
        ?phone dbo:manufacturer <{manufacturer_uri}> .
      }} UNION {{
        ?phone a dbo:Smartphone .
        ?phone dbo:manufacturer <{manufacturer_uri}> .
      }}
      
      OPTIONAL {{ 
        ?phone rdfs:label ?label .
        FILTER(LANG(?label) = 'en')
      }}
    }}
    LIMIT {limit}
    OFFSET {offset}
    """
    
    results = fetch_with_retry(endpoint, query)
    
    if not results or 'results' not in results:
        return []
    
    phones = []
    for result in results['results']['bindings']:
        if 'phone' in result:
            phone_uri = result['phone']['value']
            label = result.get('label', {}).get('value', None)
            phones.append((phone_uri, label))
    
    print(f"Found {len(phones)} phones for manufacturer at offset {offset}")
    return phones

def fetch_phone_details(phone_uri):
    """Fetch detailed specifications for a specific phone"""
    print(f"Fetching details for: {phone_uri}...")
    
    endpoint = "https://dbpedia.org/sparql"
    
    query = f"""
    PREFIX dbo: <http://dbpedia.org/ontology/>
    PREFIX dbp: <http://dbpedia.org/property/>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT ?property ?value
    WHERE {{
      <{phone_uri}> ?property ?value .
      
      # Filter to include only useful properties
      FILTER(
        ?property = dbo:abstract ||
        ?property = dbp:releaseDate ||
        ?property = dbp:cpu ||
        ?property = dbp:memory ||
        ?property = dbp:operatingSystem ||
        ?property = dbo:weight ||
        ?property = dbp:display ||
        ?property = dbp:camera ||
        ?property = dbp:storage ||
        ?property = dbp:battery ||
        ?property = dbo:successor ||
        ?property = dbo:predecessor ||
        ?property = dbp:price
      )
      
      # Filter to include only English text
      FILTER (!isLiteral(?value) || LANG(?value) = "" || LANG(?value) = "en")
    }}
    """
    
    results = fetch_with_retry(endpoint, query)
    
    if not results or 'results' not in results:
        return {}
    
    details = {}
    for result in results['results']['bindings']:
        if 'property' in result and 'value' in result:
            prop = result['property']['value']
            value = result['value']['value']
            
            # Extract property name from URI
            prop_name = prop.split('/')[-1]
            
            details[prop_name] = value
    
    return details

def extract_manufacturer_name(uri, label=None):
    """Extract a clean manufacturer name from URI or label"""
    if label:
        return label
    
    # Extract name from URI
    name = uri.split('/')[-1].replace('_', ' ')
    
    # Handle common cases
    mapping = {
        "Samsung": "Samsung",
        "Samsung Electronics": "Samsung",
        "Samsung Group": "Samsung",
        "Apple Inc": "Apple",
        "Apple": "Apple",
        "Nokia": "Nokia",
        "Nokia Corporation": "Nokia",
        "Sony": "Sony",
        "Sony Mobile": "Sony",
        "Sony Corporation": "Sony",
        "LG Electronics": "LG",
        "Xiaomi": "Xiaomi",
        "Huawei": "Huawei",
        "Motorola": "Motorola",
        "Google": "Google",
    }
    
    return mapping.get(name, name)

def extract_model_name(uri, label=None):
    """Extract a clean model name from URI or label"""
    if label:
        # Clean up label if provided
        return label.split('(')[0].strip()
    
    # Extract from URI
    name = uri.split('/')[-1].replace('_', ' ')
    
    # Handle common suffixes
    for suffix in ["(smartphone)", "(phone)", "(mobile phone)"]:
        if suffix in name.lower():
            name = name.lower().replace(suffix, "").strip()
    
    return name

def extract_numeric_value(text, unit=None):
    """Extract numeric values from string representations"""
    if not text:
        return None
    
    import re
    
    # Unit-specific patterns
    if unit == "GB":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:GB|gigabytes?|G)'
    elif unit == "MP":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:MP|megapixels?)'
    elif unit == "mAh":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:mAh)'
    elif unit == "inch":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:inches?|"|in)'
    elif unit == "g":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:g|grams?)'
    else:
        pattern = r'(\d+(?:\.\d+)?)'
    
    match = re.search(pattern, str(text), re.IGNORECASE)
    if match:
        return float(match.group(1))
    return None

def dbpedia_to_rdf():
    """Fetch and convert DBpedia smartphone data to our ontology format"""
    print("Starting improved DBpedia smartphone data collection...")
    
    # Create RDF graph
    g = Graph()
    
    # Bind namespaces
    g.bind("smartphone", SMARTPHONE)
    g.bind("dbo", DBO)
    g.bind("dbr", DBR)
    g.bind("dbp", DBP)
    g.bind("schema", SCHEMA)
    g.bind("gr", GR)
    g.bind("owl", OWL)
    
    # Step 1: Fetch major smartphone manufacturers
    manufacturers = fetch_smartphone_brands()
    
    if not manufacturers:
        print("No manufacturers found. Exiting.")
        return
    
    # Track manufacturers and series to avoid duplication
    manufacturer_map = {}  # URI -> internal URI
    series_map = {}        # key -> internal URI
    
    # Process each manufacturer
    phone_count = 0
    
    for manufacturer_idx, (manufacturer_uri, manufacturer_label) in enumerate(manufacturers):
        print(f"\nProcessing manufacturer {manufacturer_idx+1}/{len(manufacturers)}: {manufacturer_uri}")
        
        # Extract manufacturer name
        manufacturer_name = extract_manufacturer_name(manufacturer_uri, manufacturer_label)
        
        # Create or reuse manufacturer entity
        manf_uri = URIRef(SMARTPHONE + manufacturer_name.replace(' ', '_'))
        g.add((manf_uri, RDF.type, SMARTPHONE.Manufacturer))
        g.add((manf_uri, SMARTPHONE.hasBrandName, Literal(manufacturer_name)))
        g.add((manf_uri, OWL.sameAs, URIRef(manufacturer_uri)))
        manufacturer_map[manufacturer_uri] = manf_uri
        
        # Fetch phones for this manufacturer with pagination
        offset = 0
        limit = 50
        max_pages = 3  # Limit to 150 phones per manufacturer to avoid timeouts
        
        for page in range(max_pages):
            phones = fetch_phones_by_manufacturer(manufacturer_uri, limit, offset)
            
            if not phones:
                break
            
            # Process each phone
            for phone_idx, (phone_uri, phone_label) in enumerate(phones):
                try:
                    print(f"Processing phone {phone_idx+1}/{len(phones)}: {phone_uri}")
                    
                    # Get details for this phone
                    details = fetch_phone_details(phone_uri)
                    
                    # Extract model name
                    model_name = extract_model_name(phone_uri, phone_label)
                    
                    # Skip if model name is empty or too generic
                    if not model_name or model_name.lower() in ["smartphone", "mobile phone", "phone"]:
                        print(f"Skipping generic model: {model_name}")
                        continue
                    
                    # Determine series name (with basic heuristics)
                    series_name = "Unknown Series"
                    
                    if "iPhone" in model_name:
                        series_name = "iPhone"
                    elif "Galaxy" in model_name:
                        if "S" in model_name.split("Galaxy")[1][:2]:
                            series_name = "Galaxy S"
                        elif "Note" in model_name.split("Galaxy")[1][:5]:
                            series_name = "Galaxy Note"
                        elif "A" in model_name.split("Galaxy")[1][:2]:
                            series_name = "Galaxy A"
                        else:
                            series_name = "Galaxy"
                    elif "Pixel" in model_name:
                        series_name = "Pixel"
                    elif "Xperia" in model_name:
                        series_name = "Xperia"
                    
                    # Create or reuse series
                    series_key = f"{manufacturer_name}_{series_name}"
                    if series_key not in series_map:
                        series_uri = URIRef(SMARTPHONE + series_key.replace(' ', '_'))
                        g.add((series_uri, RDF.type, SMARTPHONE.DeviceSeries))
                        g.add((series_uri, RDFS.label, Literal(series_name)))
                        g.add((series_uri, SMARTPHONE.manufacturedBy, manf_uri))
                        series_map[series_key] = series_uri
                    else:
                        series_uri = series_map[series_key]
                    
                    # Create smartphone entity
                    phone_id = f"DBpedia_{manufacturer_name}_{model_name}".replace(' ', '_')
                    smartphone_uri = URIRef(SMARTPHONE + phone_id)
                    
                    # Basic properties
                    g.add((smartphone_uri, RDF.type, SMARTPHONE.Smartphone))
                    g.add((smartphone_uri, SMARTPHONE.hasModelName, Literal(model_name)))
                    g.add((smartphone_uri, SMARTPHONE.manufacturedBy, manf_uri))
                    g.add((smartphone_uri, SMARTPHONE.belongsToSeries, series_uri))
                    g.add((smartphone_uri, OWL.sameAs, URIRef(phone_uri)))
                    
                    # Add release date
                    if 'releaseDate' in details:
                        g.add((smartphone_uri, SMARTPHONE.hasReleaseDate, Literal(details['releaseDate'])))
                    
                    # Add abstract
                    if 'abstract' in details:
                        g.add((smartphone_uri, RDFS.comment, Literal(details['abstract'])))
                    
                    # Add display information
                    if 'display' in details:
                        display_uri = URIRef(SMARTPHONE + f"Display_{phone_id}")
                        g.add((display_uri, RDF.type, SMARTPHONE.Display))
                        g.add((smartphone_uri, SMARTPHONE.hasDisplay, display_uri))
                        
                        # Try to extract screen size
                        screen_size = extract_numeric_value(details['display'], "inch")
                        if screen_size:
                            g.add((display_uri, SMARTPHONE.hasScreenSize, Literal(screen_size, datatype=XSD.decimal)))
                        
                        # Add full display info
                        g.add((display_uri, RDFS.comment, Literal(details['display'])))
                    
                    # Add processor information
                    if 'cpu' in details:
                        processor_uri = URIRef(SMARTPHONE + f"Processor_{phone_id}")
                        g.add((processor_uri, RDF.type, SMARTPHONE.Processor))
                        g.add((smartphone_uri, SMARTPHONE.hasProcessor, processor_uri))
                        g.add((processor_uri, SMARTPHONE.hasChipsetModel, Literal(details['cpu'])))
                    
                    # Add camera information
                    if 'camera' in details:
                        camera_uri = URIRef(SMARTPHONE + f"Camera_{phone_id}")
                        g.add((camera_uri, RDF.type, SMARTPHONE.Camera))
                        g.add((smartphone_uri, SMARTPHONE.hasMainCamera, camera_uri))
                        
                        # Try to extract megapixels
                        mp_value = extract_numeric_value(details['camera'], "MP")
                        if mp_value:
                            g.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(mp_value, datatype=XSD.decimal)))
                        
                        # Add full camera info
                        g.add((camera_uri, RDFS.comment, Literal(details['camera'])))
                    
                    # Add memory/storage information
                    memory_info = details.get('memory')
                    storage_info = details.get('storage')
                    
                    if memory_info or storage_info:
                        memory_uri = URIRef(SMARTPHONE + f"Memory_{phone_id}")
                        g.add((memory_uri, RDF.type, SMARTPHONE.Memory))
                        g.add((smartphone_uri, SMARTPHONE.hasMemoryConfiguration, memory_uri))
                        
                        # Try to extract RAM
                        if memory_info:
                            ram_value = extract_numeric_value(memory_info, "GB")
                            if ram_value:
                                g.add((memory_uri, SMARTPHONE.hasRAMSize, Literal(int(ram_value), datatype=XSD.integer)))
                        
                        # Try to extract storage
                        if storage_info:
                            storage_value = extract_numeric_value(storage_info, "GB")
                            if storage_value:
                                g.add((memory_uri, SMARTPHONE.hasStorageSize, Literal(int(storage_value), datatype=XSD.integer)))
                    
                    # Add battery information
                    if 'battery' in details:
                        battery_uri = URIRef(SMARTPHONE + f"Battery_{phone_id}")
                        g.add((battery_uri, RDF.type, SMARTPHONE.Battery))
                        g.add((smartphone_uri, SMARTPHONE.hasBattery, battery_uri))
                        
                        # Try to extract capacity
                        capacity_value = extract_numeric_value(details['battery'], "mAh")
                        if capacity_value:
                            g.add((battery_uri, SMARTPHONE.hasBatteryCapacity, Literal(int(capacity_value), datatype=XSD.integer)))
                    
                    # Add operating system
                    if 'operatingSystem' in details:
                        g.add((smartphone_uri, SMARTPHONE.hasOperatingSystem, Literal(details['operatingSystem'])))
                    
                    # Add weight
                    if 'weight' in details:
                        weight_value = extract_numeric_value(details['weight'], "g")
                        if weight_value:
                            g.add((smartphone_uri, SMARTPHONE.hasWeight, Literal(weight_value, datatype=XSD.decimal)))
                    
                    phone_count += 1
                    
                except Exception as e:
                    print(f"Error processing phone {phone_uri}: {e}")
                    continue
            
            # Move to next page
            offset += limit
    
    # Create output directory
    processed_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'processed')
    os.makedirs(processed_dir, exist_ok=True)
    
    # Save the RDF graph
    output_file = os.path.join(processed_dir, "smartphone-data-dbpedia.ttl")
    print(f"Saving DBpedia smartphone data to {output_file}")
    g.serialize(destination=output_file, format='turtle')
    
    print(f"Conversion complete. Generated {len(g)} triples for {phone_count} smartphones.")
    return output_file

if __name__ == "__main__":
    start_time = time.time()
    output_file = dbpedia_to_rdf()
    end_time = time.time()
    print(f"Total processing time: {end_time - start_time:.2f} seconds")
