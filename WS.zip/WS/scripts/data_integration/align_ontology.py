"""
Smartphone Ontology Alignment

This script aligns our smartphone ontology with established vocabularies:
- DBpedia Ontology (dbo:MobilePhone)
- Schema.org (schema:Product)
- GoodRelations (gr:ProductOrService)

It creates OWL equivalence and subclass relationships to enable 
interoperability with these standard vocabularies.
"""

import os
from rdflib import Graph, Namespace, Literal, URIRef
from rdflib.namespace import RDF, RDFS, OWL, XSD

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")
DBO = Namespace("http://dbpedia.org/ontology/")
SCHEMA = Namespace("http://schema.org/")
GR = Namespace("http://purl.org/goodrelations/v1#")
QUDT = Namespace("http://qudt.org/schema/qudt/")
DC = Namespace("http://purl.org/dc/elements/1.1/")
DCTERMS = Namespace("http://purl.org/dc/terms/")
FOAF = Namespace("http://xmlns.com/foaf/0.1/")

def create_aligned_ontology():
    """Create an aligned version of our smartphone ontology"""
    print("Creating aligned smartphone ontology...")
    
    # Create a new graph for the ontology
    g = Graph()
    
    # Bind all namespaces
    g.bind("smartphone", SMARTPHONE)
    g.bind("dbo", DBO)
    g.bind("schema", SCHEMA)
    g.bind("gr", GR)
    g.bind("qudt", QUDT)
    g.bind("dc", DC)
    g.bind("dcterms", DCTERMS)
    g.bind("foaf", FOAF)
    g.bind("owl", OWL)
    
    # Define ontology metadata
    ontology_uri = URIRef(SMARTPHONE)
    g.add((ontology_uri, RDF.type, OWL.Ontology))
    g.add((ontology_uri, DC.title, Literal("Smartphone Ontology")))
    g.add((ontology_uri, DC.description, Literal("An ontology for modeling smartphones, their components, and specifications")))
    g.add((ontology_uri, DC.creator, Literal("Claude")))
    g.add((ontology_uri, OWL.imports, URIRef("http://schema.org/")))
    
    # 1. Class Alignments
    
    # Define main Smartphone class
    g.add((SMARTPHONE.Smartphone, RDF.type, OWL.Class))
    g.add((SMARTPHONE.Smartphone, RDFS.label, Literal("Smartphone")))
    g.add((SMARTPHONE.Smartphone, RDFS.comment, Literal("A mobile phone with advanced features and capabilities")))
    
    # Align with standard vocabularies using subClassOf and equivalentClass
    g.add((SMARTPHONE.Smartphone, RDFS.subClassOf, DBO.MobilePhone))
    g.add((SMARTPHONE.Smartphone, RDFS.subClassOf, SCHEMA.Product))
    g.add((SMARTPHONE.Smartphone, RDFS.subClassOf, GR.ProductOrService))
    
    # Define Manufacturer class
    g.add((SMARTPHONE.Manufacturer, RDF.type, OWL.Class))
    g.add((SMARTPHONE.Manufacturer, RDFS.label, Literal("Manufacturer")))
    g.add((SMARTPHONE.Manufacturer, RDFS.comment, Literal("A company that produces smartphones")))
    g.add((SMARTPHONE.Manufacturer, RDFS.subClassOf, SCHEMA.Organization))
    g.add((SMARTPHONE.Manufacturer, RDFS.subClassOf, GR.BusinessEntity))
    g.add((SMARTPHONE.Manufacturer, OWL.equivalentClass, DBO.Company))
    
    # Define DeviceSeries class
    g.add((SMARTPHONE.DeviceSeries, RDF.type, OWL.Class))
    g.add((SMARTPHONE.DeviceSeries, RDFS.label, Literal("Device Series")))
    g.add((SMARTPHONE.DeviceSeries, RDFS.comment, Literal("A product line or series of smartphones")))
    g.add((SMARTPHONE.DeviceSeries, RDFS.subClassOf, SCHEMA.ProductModel))
    
    # Component classes
    component_classes = [
        (SMARTPHONE.Component, "Component", "A physical part of a smartphone"),
        (SMARTPHONE.Display, "Display", "The screen of a smartphone"),
        (SMARTPHONE.Processor, "Processor", "The CPU or chipset of a smartphone"),
        (SMARTPHONE.Battery, "Battery", "The power source of a smartphone"),
        (SMARTPHONE.Camera, "Camera", "A camera module of a smartphone"),
        (SMARTPHONE.Memory, "Memory", "RAM and storage of a smartphone")
    ]
    
    # Add component class definitions and alignments
    for uri, label, comment in component_classes:
        g.add((uri, RDF.type, OWL.Class))
        g.add((uri, RDFS.label, Literal(label)))
        g.add((uri, RDFS.comment, Literal(comment)))
    
    # Add component hierarchy
    for uri, _, _ in component_classes[1:]:  # Skip the base Component class
        g.add((uri, RDFS.subClassOf, SMARTPHONE.Component))
    
    # Align components with Schema.org
    g.add((SMARTPHONE.Component, RDFS.subClassOf, SCHEMA.Product))
    g.add((SMARTPHONE.Display, OWL.equivalentClass, URIRef("http://schema.org/ScreenSizeSpecification")))
    
    # 2. Property Alignments
    
    # Object Properties
    object_properties = [
        (SMARTPHONE.manufacturedBy, "manufactured by", "The manufacturer of the smartphone", SCHEMA.manufacturer),
        (SMARTPHONE.belongsToSeries, "belongs to series", "The product series the smartphone belongs to", SCHEMA.isModelOf),
        (SMARTPHONE.hasDisplay, "has display", "The display component of the smartphone", None),
        (SMARTPHONE.hasProcessor, "has processor", "The processor component of the smartphone", None),
        (SMARTPHONE.hasBattery, "has battery", "The battery component of the smartphone", None),
        (SMARTPHONE.hasMainCamera, "has main camera", "The main camera component of the smartphone", None),
        (SMARTPHONE.hasMemoryConfiguration, "has memory configuration", "The memory configuration of the smartphone", None)
    ]
    
    # Add object property definitions and alignments
    for uri, label, comment, alignment in object_properties:
        g.add((uri, RDF.type, OWL.ObjectProperty))
        g.add((uri, RDFS.label, Literal(label)))
        g.add((uri, RDFS.comment, Literal(comment)))
        
        if alignment:
            g.add((uri, OWL.equivalentProperty, alignment))
    
    # Data Properties
    data_properties = [
        (SMARTPHONE.hasBrandName, "has brand name", "The brand name of the manufacturer", SCHEMA.name),
        (SMARTPHONE.hasModelName, "has model name", "The model name of the smartphone", SCHEMA.model),
        (SMARTPHONE.hasReleaseDate, "has release date", "The release date of the smartphone", SCHEMA.releaseDate),
        (SMARTPHONE.hasScreenSize, "has screen size", "The screen size of the display in inches", SCHEMA.screenSize),
        (SMARTPHONE.hasResolution, "has resolution", "The resolution of the display", SCHEMA.displayResolution),
        (SMARTPHONE.hasDisplayType, "has display type", "The type of display technology", None),
        (SMARTPHONE.hasChipsetModel, "has chipset model", "The model of the processor chipset", None),
        (SMARTPHONE.hasCoreCount, "has core count", "The number of CPU cores", None),
        (SMARTPHONE.hasClockSpeed, "has clock speed", "The clock speed of the processor in GHz", None),
        (SMARTPHONE.hasBatteryCapacity, "has battery capacity", "The capacity of the battery in mAh", None),
        (SMARTPHONE.hasResolutionMP, "has resolution in megapixels", "The resolution of the camera in megapixels", None),
        (SMARTPHONE.hasAperture, "has aperture", "The aperture of the camera lens", None),
        (SMARTPHONE.hasRAMSize, "has RAM size", "The size of RAM in GB", None),
        (SMARTPHONE.hasStorageSize, "has storage size", "The size of internal storage in GB", None),
        (SMARTPHONE.hasWeight, "has weight", "The weight of the smartphone in grams", SCHEMA.weight),
        (SMARTPHONE.hasOperatingSystem, "has operating system", "The operating system of the smartphone", SCHEMA.operatingSystem)
    ]
    
    # Add data property definitions and alignments
    for uri, label, comment, alignment in data_properties:
        g.add((uri, RDF.type, OWL.DatatypeProperty))
        g.add((uri, RDFS.label, Literal(label)))
        g.add((uri, RDFS.comment, Literal(comment)))
        
        if alignment:
            g.add((uri, OWL.equivalentProperty, alignment))
    
    # 3. Define domains and ranges for properties
    
    # Object property domains and ranges
    object_domains_ranges = [
        (SMARTPHONE.manufacturedBy, SMARTPHONE.Smartphone, SMARTPHONE.Manufacturer),
        (SMARTPHONE.belongsToSeries, SMARTPHONE.Smartphone, SMARTPHONE.DeviceSeries),
        (SMARTPHONE.hasDisplay, SMARTPHONE.Smartphone, SMARTPHONE.Display),
        (SMARTPHONE.hasProcessor, SMARTPHONE.Smartphone, SMARTPHONE.Processor),
        (SMARTPHONE.hasBattery, SMARTPHONE.Smartphone, SMARTPHONE.Battery),
        (SMARTPHONE.hasMainCamera, SMARTPHONE.Smartphone, SMARTPHONE.Camera),
        (SMARTPHONE.hasMemoryConfiguration, SMARTPHONE.Smartphone, SMARTPHONE.Memory)
    ]
    
    for prop, domain, range_class in object_domains_ranges:
        g.add((prop, RDFS.domain, domain))
        g.add((prop, RDFS.range, range_class))
    
    # Data property domains and ranges
    data_domains_ranges = [
        (SMARTPHONE.hasBrandName, SMARTPHONE.Manufacturer, XSD.string),
        (SMARTPHONE.hasModelName, SMARTPHONE.Smartphone, XSD.string),
        (SMARTPHONE.hasReleaseDate, SMARTPHONE.Smartphone, XSD.date),
        (SMARTPHONE.hasScreenSize, SMARTPHONE.Display, XSD.decimal),
        (SMARTPHONE.hasResolution, SMARTPHONE.Display, XSD.string),
        (SMARTPHONE.hasDisplayType, SMARTPHONE.Display, XSD.string),
        (SMARTPHONE.hasChipsetModel, SMARTPHONE.Processor, XSD.string),
        (SMARTPHONE.hasCoreCount, SMARTPHONE.Processor, XSD.integer),
        (SMARTPHONE.hasClockSpeed, SMARTPHONE.Processor, XSD.decimal),
        (SMARTPHONE.hasBatteryCapacity, SMARTPHONE.Battery, XSD.integer),
        (SMARTPHONE.hasResolutionMP, SMARTPHONE.Camera, XSD.decimal),
        (SMARTPHONE.hasAperture, SMARTPHONE.Camera, XSD.string),
        (SMARTPHONE.hasRAMSize, SMARTPHONE.Memory, XSD.integer),
        (SMARTPHONE.hasStorageSize, SMARTPHONE.Memory, XSD.integer),
        (SMARTPHONE.hasWeight, SMARTPHONE.Smartphone, XSD.decimal),
        (SMARTPHONE.hasOperatingSystem, SMARTPHONE.Smartphone, XSD.string)
    ]
    
    for prop, domain, range_class in data_domains_ranges:
        g.add((prop, RDFS.domain, domain))
        g.add((prop, RDFS.range, range_class))
    
    # 4. Define additional semantics using OWL
    
    # Define inverse properties
    g.add((SMARTPHONE.manufacturedBy, OWL.inverseOf, URIRef(SMARTPHONE + "manufactures")))
    g.add((URIRef(SMARTPHONE + "manufactures"), RDF.type, OWL.ObjectProperty))
    g.add((URIRef(SMARTPHONE + "manufactures"), RDFS.label, Literal("manufactures")))
    g.add((URIRef(SMARTPHONE + "manufactures"), RDFS.domain, SMARTPHONE.Manufacturer))
    g.add((URIRef(SMARTPHONE + "manufactures"), RDFS.range, SMARTPHONE.Smartphone))
    
    # Define functional properties (properties that can have only one value)
    functional_properties = [
        SMARTPHONE.manufacturedBy,
        SMARTPHONE.belongsToSeries,
        SMARTPHONE.hasModelName,
        SMARTPHONE.hasReleaseDate,
        SMARTPHONE.hasWeight,
        SMARTPHONE.hasOperatingSystem
    ]
    
    for prop in functional_properties:
        g.add((prop, RDF.type, OWL.FunctionalProperty))
    
    # Save the ontology to a file
    onto_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'onto')
    os.makedirs(onto_dir, exist_ok=True)
    
    output_file = os.path.join(onto_dir, "smartphone-ontology-aligned.owl")
    print(f"Saving aligned ontology to {output_file}")
    g.serialize(destination=output_file, format='xml')
    
    print(f"Ontology alignment complete. Generated {len(g)} triples.")
    return output_file

if __name__ == "__main__":
    output_file = create_aligned_ontology()
    print(f"Aligned ontology saved to {output_file}")
