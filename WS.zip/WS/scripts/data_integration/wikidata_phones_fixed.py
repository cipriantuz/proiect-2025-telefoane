"""
Wikidata Smartphone Data Extractor (Fixed Version)

This script fetches smartphone data from Wikidata using direct HTTP requests
to avoid timeout issues with SPARQLWrapper.
"""

import os
import time
import json
import requests
from rdflib import Graph, Namespace, Literal, URIRef, BNode
from rdflib.namespace import RDF, RDFS, XSD, OWL, FOAF

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")
WD = Namespace("http://www.wikidata.org/entity/")
WDT = Namespace("http://www.wikidata.org/prop/direct/")
WDP = Namespace("http://www.wikidata.org/prop/")
SCHEMA = Namespace("http://schema.org/")
GR = Namespace("http://purl.org/goodrelations/v1#")

def fetch_smartphones_from_wikidata(limit=200):
    """Fetch smartphone data from Wikidata's SPARQL endpoint using direct HTTP requests"""
    print("Fetching smartphone data from Wikidata...")
    
    # Wikidata SPARQL endpoint
    endpoint = "https://query.wikidata.org/sparql"
    
    # Simpler query that's less likely to time out
    query = """
    SELECT ?phone ?phoneLabel ?image ?manufactureDate ?manufacturer ?manufacturerLabel
    WHERE {
      # Get smartphones (Q22645)
      ?phone wdt:P31 wd:Q22645.
      
      # Get manufacturer
      OPTIONAL { ?phone wdt:P176 ?manufacturer. }
      
      # Get manufacture date
      OPTIONAL { ?phone wdt:P571 ?manufactureDate. }
      
      # Get image
      OPTIONAL { ?phone wdt:P18 ?image. }
      
      # Get labels
      SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
    }
    LIMIT """ + str(limit)
    
    # Set up HTTP request
    headers = {
        'Accept': 'application/sparql-results+json',
        'User-Agent': 'WS-Project-Smartphone-Ontology/1.0'
    }
    
    params = {
        'query': query,
        'format': 'json'
    }
    
    try:
        print("Sending request to Wikidata SPARQL endpoint...")
        response = requests.get(endpoint, headers=headers, params=params, timeout=30)
        
        if response.status_code == 200:
            print(f"Received successful response from Wikidata (HTTP {response.status_code})")
            data = response.json()
            results = data.get('results', {}).get('bindings', [])
            print(f"Found {len(results)} smartphone entries")
            return results
        else:
            print(f"Error: Wikidata returned HTTP {response.status_code}")
            print(f"Response: {response.text[:500]}...")
            return []
    except Exception as e:
        print(f"Error fetching data from Wikidata: {e}")
        return []

def fetch_phone_details(phone_uri):
    """Fetch additional details for a specific phone from Wikidata"""
    # Extract Q-number from URI
    q_number = phone_uri.split('/')[-1]
    
    endpoint = "https://query.wikidata.org/sparql"
    
    query = f"""
    SELECT ?cpuLabel ?weight ?memory ?screenSize ?cameraResolution ?operatingSystemLabel
    WHERE {{
      wd:{q_number} wdt:P880 ?cpu.
      OPTIONAL {{ wd:{q_number} wdt:P2910 ?weight. }}
      OPTIONAL {{ wd:{q_number} wdt:P2928 ?memory. }}
      OPTIONAL {{ wd:{q_number} wdt:P2910 ?screenSize. }}
      OPTIONAL {{ wd:{q_number} wdt:P2670 ?cameraResolution. }}
      OPTIONAL {{ wd:{q_number} wdt:P306 ?operatingSystem. }}
      
      SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
    }}
    LIMIT 1
    """
    
    headers = {
        'Accept': 'application/sparql-results+json',
        'User-Agent': 'WS-Project-Smartphone-Ontology/1.0'
    }
    
    params = {
        'query': query,
        'format': 'json'
    }
    
    try:
        response = requests.get(endpoint, headers=headers, params=params, timeout=15)
        if response.status_code == 200:
            data = response.json()
            if data.get('results', {}).get('bindings'):
                return data['results']['bindings'][0]
        return {}
    except Exception as e:
        print(f"Error fetching details for {phone_uri}: {e}")
        return {}

def clean_model_name(name):
    """Clean up model names to a standard format"""
    if not name:
        return "Unknown Model"
    
    # Remove common prefixes
    prefixes = [
        "Smartphone", "Mobile Phone", "Cellphone", "Phone", 
        "smartphone", "mobile phone", "cellphone", "phone"
    ]
    
    cleaned_name = name
    for prefix in prefixes:
        if cleaned_name.endswith(prefix):
            cleaned_name = cleaned_name[:-len(prefix)].strip()
        if cleaned_name.startswith(prefix):
            cleaned_name = cleaned_name[len(prefix):].strip()
    
    # Remove trailing whitespace and extra characters
    return cleaned_name.strip()

def wikidata_to_rdf():
    """Convert Wikidata smartphone data to our ontology format"""
    print("Starting Wikidata smartphone data conversion...")
    
    # Fetch data from Wikidata
    results = fetch_smartphones_from_wikidata()
    
    if not results:
        print("No results from Wikidata. Exiting.")
        return
    
    print(f"Retrieved {len(results)} smartphones from Wikidata.")
    
    # Create RDF graph
    g = Graph()
    
    # Bind namespaces
    g.bind("smartphone", SMARTPHONE)
    g.bind("wd", WD)
    g.bind("wdt", WDT)
    g.bind("schema", SCHEMA)
    g.bind("gr", GR)
    g.bind("owl", OWL)
    
    # Track manufacturers and series to avoid duplication
    manufacturers = {}
    series = {}
    
    # Process results
    for i, result in enumerate(results):
        try:
            if i % 20 == 0:
                print(f"Processing phone {i+1}/{len(results)}...")
                
            # Extract basic information
            phone_uri = result.get('phone', {}).get('value')
            if not phone_uri:
                continue
            
            phone_label = result.get('phoneLabel', {}).get('value') if 'phoneLabel' in result else None
            manufacturer_uri = result.get('manufacturer', {}).get('value') if 'manufacturer' in result else None
            manufacturer_label = result.get('manufacturerLabel', {}).get('value') if 'manufacturerLabel' in result else None
            
            if not phone_label:
                continue
            
            # Clean up model name
            model_name = clean_model_name(phone_label)
            manufacturer_name = manufacturer_label if manufacturer_label else "Unknown Manufacturer"
            
            # Get additional details for this phone
            details = fetch_phone_details(phone_uri)
            
            # Create or reuse manufacturer URI
            if manufacturer_name not in manufacturers:
                manf_uri = URIRef(SMARTPHONE + manufacturer_name.replace(' ', '_'))
                g.add((manf_uri, RDF.type, SMARTPHONE.Manufacturer))
                g.add((manf_uri, SMARTPHONE.hasBrandName, Literal(manufacturer_name)))
                # Link to Wikidata entity if available
                if manufacturer_uri:
                    g.add((manf_uri, OWL.sameAs, URIRef(manufacturer_uri)))
                manufacturers[manufacturer_name] = manf_uri
            else:
                manf_uri = manufacturers[manufacturer_name]
            
            # Determine series name (with basic heuristics)
            series_name = "Unknown Series"
            if "iPhone" in model_name:
                series_name = "iPhone"
            elif "Galaxy" in model_name:
                if "S" in model_name.split("Galaxy")[1][:2]:
                    series_name = "Galaxy S"
                elif "Note" in model_name.split("Galaxy")[1][:5]:
                    series_name = "Galaxy Note"
                elif "A" in model_name.split("Galaxy")[1][:2]:
                    series_name = "Galaxy A"
                else:
                    series_name = "Galaxy"
            elif "Pixel" in model_name:
                series_name = "Pixel"
            elif "OnePlus" in model_name:
                series_name = "OnePlus"
            
            # Create or reuse series URI
            series_key = f"{manufacturer_name}_{series_name}"
            if series_key not in series:
                series_uri = URIRef(SMARTPHONE + series_key.replace(' ', '_'))
                g.add((series_uri, RDF.type, SMARTPHONE.DeviceSeries))
                g.add((series_uri, RDFS.label, Literal(series_name)))
                g.add((series_uri, SMARTPHONE.manufacturedBy, manf_uri))
                series[series_key] = series_uri
            else:
                series_uri = series[series_key]
            
            # Create smartphone instance (generate a clean ID)
            phone_id = f"{manufacturer_name}_{model_name}".replace(' ', '_').replace('(', '').replace(')', '')
            smartphone_uri = URIRef(SMARTPHONE + phone_id)
            
            # Type information and basic properties
            g.add((smartphone_uri, RDF.type, SMARTPHONE.Smartphone))
            g.add((smartphone_uri, SMARTPHONE.hasModelName, Literal(model_name)))
            g.add((smartphone_uri, SMARTPHONE.manufacturedBy, manf_uri))
            g.add((smartphone_uri, SMARTPHONE.belongsToSeries, series_uri))
            g.add((smartphone_uri, OWL.sameAs, URIRef(phone_uri)))
            
            # Add release date if available
            if 'manufactureDate' in result:
                release_date = result['manufactureDate']['value']
                g.add((smartphone_uri, SMARTPHONE.hasReleaseDate, Literal(release_date)))
            
            # Process processor information
            if 'cpuLabel' in details and details['cpuLabel'].get('value'):
                processor_uri = URIRef(SMARTPHONE + f"Processor_{phone_id}")
                g.add((processor_uri, RDF.type, SMARTPHONE.Processor))
                g.add((smartphone_uri, SMARTPHONE.hasProcessor, processor_uri))
                g.add((processor_uri, SMARTPHONE.hasChipsetModel, Literal(details['cpuLabel']['value'])))
            
            # Process weight information
            if 'weight' in details and details['weight'].get('value'):
                try:
                    weight_value = float(details['weight']['value'])
                    g.add((smartphone_uri, SMARTPHONE.hasWeight, Literal(weight_value, datatype=XSD.decimal)))
                except (ValueError, TypeError):
                    pass
            
            # Process memory information
            if 'memory' in details and details['memory'].get('value'):
                memory_uri = URIRef(SMARTPHONE + f"Memory_{phone_id}")
                g.add((memory_uri, RDF.type, SMARTPHONE.Memory))
                g.add((smartphone_uri, SMARTPHONE.hasMemoryConfiguration, memory_uri))
                
                try:
                    # Wikidata often stores memory in bytes, convert to GB
                    memory_bytes = float(details['memory']['value'])
                    memory_gb = memory_bytes / (1024 * 1024 * 1024)
                    g.add((memory_uri, SMARTPHONE.hasRAMSize, Literal(int(memory_gb), datatype=XSD.integer)))
                except (ValueError, TypeError):
                    pass
            
            # Process screen size information (if available)
            if 'screenSize' in details and details['screenSize'].get('value'):
                display_uri = URIRef(SMARTPHONE + f"Display_{phone_id}")
                g.add((display_uri, RDF.type, SMARTPHONE.Display))
                g.add((smartphone_uri, SMARTPHONE.hasDisplay, display_uri))
                
                try:
                    screen_size = float(details['screenSize']['value'])
                    g.add((display_uri, SMARTPHONE.hasScreenSize, Literal(screen_size, datatype=XSD.decimal)))
                except (ValueError, TypeError):
                    pass
            
            # Process camera resolution
            if 'cameraResolution' in details and details['cameraResolution'].get('value'):
                camera_uri = URIRef(SMARTPHONE + f"Camera_{phone_id}")
                g.add((camera_uri, RDF.type, SMARTPHONE.Camera))
                g.add((smartphone_uri, SMARTPHONE.hasMainCamera, camera_uri))
                
                try:
                    # Wikidata often stores camera resolution in megapixels
                    camera_mp = float(details['cameraResolution']['value'])
                    g.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(camera_mp, datatype=XSD.decimal)))
                except (ValueError, TypeError):
                    pass
            
            # Process OS information
            if 'operatingSystemLabel' in details and details['operatingSystemLabel'].get('value'):
                os_value = details['operatingSystemLabel']['value']
                g.add((smartphone_uri, SMARTPHONE.hasOperatingSystem, Literal(os_value)))
        
        except Exception as e:
            print(f"Error processing result: {e}")
            continue
    
    # Create output directory
    processed_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'processed')
    os.makedirs(processed_dir, exist_ok=True)
    
    # Save the RDF graph
    output_file = os.path.join(processed_dir, "smartphone-data-wikidata.ttl")
    print(f"Saving Wikidata smartphone data to {output_file}")
    g.serialize(destination=output_file, format='turtle')
    
    print(f"Conversion complete. Generated {len(g)} triples for {len(results)} smartphones.")
    return output_file

if __name__ == "__main__":
    start_time = time.time()
    output_file = wikidata_to_rdf()
    end_time = time.time()
    print(f"Total processing time: {end_time - start_time:.2f} seconds")
