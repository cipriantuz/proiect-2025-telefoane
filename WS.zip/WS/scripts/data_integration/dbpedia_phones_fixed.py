"""
DBpedia Smartphone Data Extractor (Fixed Version)

This script fetches smartphone data from DBpedia's SPARQL endpoint with a simplified
and more robust query to avoid timeout issues.
"""

import os
import time
from rdflib import Graph, Namespace, Literal, URIRef, BNode
from rdflib.namespace import RDF, RDFS, XSD, OWL, FOAF
import requests
import json

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")
DBO = Namespace("http://dbpedia.org/ontology/")
DBR = Namespace("http://dbpedia.org/resource/")
DBP = Namespace("http://dbpedia.org/property/")
SCHEMA = Namespace("http://schema.org/")
GR = Namespace("http://purl.org/goodrelations/v1#")

def fetch_smartphones_from_dbpedia():
    """Fetch smartphone data from DBpedia's SPARQL endpoint using direct HTTP request"""
    print("Fetching smartphone data from DBpedia...")
    
    # DBpedia SPARQL endpoint
    endpoint = "https://dbpedia.org/sparql"
    
    # Simplified query to get smartphone models
    query = """
    PREFIX dbo: <http://dbpedia.org/ontology/>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT ?phone ?label ?manufacturer ?manfLabel ?abstract
    WHERE {
        # Get smartphones or mobile phones
        { ?phone a dbo:MobilePhone }
        UNION
        { ?phone a dbo:Smartphone }
        
        # Get English label
        OPTIONAL { 
            ?phone rdfs:label ?label .
            FILTER(LANG(?label) = 'en')
        }
        
        # Get manufacturer
        OPTIONAL { 
            ?phone dbo:manufacturer ?manufacturer .
            OPTIONAL { 
                ?manufacturer rdfs:label ?manfLabel .
                FILTER(LANG(?manfLabel) = 'en')
            }
        }
        
        # Get English abstract
        OPTIONAL { 
            ?phone dbo:abstract ?abstract .
            FILTER(LANG(?abstract) = 'en')
        }
    }
    LIMIT 500
    """
    
    # Set up HTTP request
    headers = {
        'Accept': 'application/sparql-results+json',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    
    params = {
        'query': query,
        'format': 'json'
    }
    
    try:
        print("Sending request to DBpedia SPARQL endpoint...")
        response = requests.get(endpoint, headers=headers, params=params, timeout=30)
        
        if response.status_code == 200:
            print(f"Received successful response from DBpedia (HTTP {response.status_code})")
            data = response.json()
            results = data.get('results', {}).get('bindings', [])
            print(f"Found {len(results)} smartphone entries")
            return results
        else:
            print(f"Error: DBpedia returned HTTP {response.status_code}")
            print(f"Response: {response.text[:500]}...")
            return []
    except Exception as e:
        print(f"Error fetching data from DBpedia: {e}")
        return []

def extract_model_name(uri, label=None):
    """Extract a clean model name from the DBpedia URI or label"""
    if label and isinstance(label, str):
        return label.strip()
    
    # Extract model name from URI
    uri_parts = uri.split('/')
    model_name = uri_parts[-1].replace('_', ' ')
    return model_name

def extract_manufacturer(manufacturer_uri, manufacturer_label=None):
    """Extract the manufacturer name from a DBpedia URI or label"""
    if manufacturer_label and isinstance(manufacturer_label, str):
        return manufacturer_label.strip()
    
    if not manufacturer_uri:
        return "Unknown"
    
    # Extract name from URI
    uri_parts = manufacturer_uri.split('/')
    manufacturer_name = uri_parts[-1].replace('_', ' ')
    
    # Handle common manufacturer names
    manufacturer_lookup = {
        "Samsung": "Samsung",
        "Samsung Electronics": "Samsung",
        "Samsung Group": "Samsung",
        "Apple Inc": "Apple",
        "Apple": "Apple",
        "Xiaomi": "Xiaomi",
        "Huawei": "Huawei",
        "Sony": "Sony",
        "Sony Corporation": "Sony",
        "Sony Mobile": "Sony",
        "Google": "Google",
        "OnePlus": "OnePlus",
        "HTC": "HTC",
        "HTC Corporation": "HTC",
        "LG": "LG",
        "LG Electronics": "LG",
        "Motorola": "Motorola",
        "Motorola Mobility": "Motorola",
        "Nokia": "Nokia",
        "Nokia Corporation": "Nokia",
        "Oppo": "Oppo"
    }
    
    return manufacturer_lookup.get(manufacturer_name, manufacturer_name)

def fetch_phone_details(phone_uri):
    """Fetch additional details for a specific phone"""
    endpoint = "https://dbpedia.org/sparql"
    
    query = f"""
    PREFIX dbo: <http://dbpedia.org/ontology/>
    PREFIX dbp: <http://dbpedia.org/property/>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT ?releaseDate ?cpu ?memory ?os ?weight ?display ?camera ?storage
    WHERE {{
        <{phone_uri}> ?p ?o .
        
        OPTIONAL {{ <{phone_uri}> dbp:releaseDate ?releaseDate }}
        OPTIONAL {{ <{phone_uri}> dbp:cpu ?cpu }}
        OPTIONAL {{ <{phone_uri}> dbp:memory ?memory }}
        OPTIONAL {{ <{phone_uri}> dbp:operatingSystem ?os }}
        OPTIONAL {{ <{phone_uri}> dbo:weight ?weight }}
        OPTIONAL {{ <{phone_uri}> dbp:display ?display }}
        OPTIONAL {{ <{phone_uri}> dbp:camera ?camera }}
        OPTIONAL {{ <{phone_uri}> dbp:storage ?storage }}
    }}
    """
    
    headers = {
        'Accept': 'application/sparql-results+json',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    
    params = {
        'query': query,
        'format': 'json'
    }
    
    try:
        response = requests.get(endpoint, headers=headers, params=params, timeout=15)
        if response.status_code == 200:
            data = response.json()
            if data.get('results', {}).get('bindings'):
                return data['results']['bindings'][0]  # Return the first result
        return {}
    except Exception as e:
        print(f"Error fetching details for {phone_uri}: {e}")
        return {}

def extract_numeric_value(value, unit=None):
    """Extract numeric values from string representations"""
    if not value:
        return None
    
    import re
    
    # Handle common units
    if unit == "GB" or unit == "gigabyte":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:GB|gigabytes?|G)'
    elif unit == "MP" or unit == "megapixel":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:MP|megapixels?)'
    elif unit == "inch":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:inches?|"|in)'
    elif unit == "mAh":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:mAh)'
    elif unit == "g" or unit == "gram":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:g|grams?)'
    else:
        # Generic number extraction
        pattern = r'(\d+(?:\.\d+)?)'
    
    match = re.search(pattern, str(value), re.IGNORECASE)
    return float(match.group(1)) if match else None

def dbpedia_to_rdf():
    """Convert DBpedia smartphone data to our ontology format"""
    print("Starting DBpedia smartphone data conversion...")
    
    # Fetch basic data for all smartphones
    results = fetch_smartphones_from_dbpedia()
    
    if not results:
        print("No results from DBpedia. Exiting.")
        return
    
    print(f"Retrieved basic data for {len(results)} smartphones from DBpedia.")
    
    # Create RDF graph
    g = Graph()
    
    # Bind namespaces
    g.bind("smartphone", SMARTPHONE)
    g.bind("dbo", DBO)
    g.bind("dbr", DBR)
    g.bind("dbp", DBP)
    g.bind("schema", SCHEMA)
    g.bind("gr", GR)
    g.bind("owl", OWL)
    
    # Track manufacturers and series to avoid duplication
    manufacturers = {}
    series = {}
    
    # Process results
    for i, result in enumerate(results):
        try:
            # Extract basic information
            if i % 50 == 0:
                print(f"Processing phone {i+1}/{len(results)}...")
                
            phone_uri = result.get('phone', {}).get('value')
            if not phone_uri:
                continue
            
            label = result.get('label', {}).get('value') if 'label' in result else None
            manufacturer_uri = result.get('manufacturer', {}).get('value') if 'manufacturer' in result else None
            manufacturer_label = result.get('manfLabel', {}).get('value') if 'manfLabel' in result else None
            
            model_name = extract_model_name(phone_uri, label)
            manufacturer_name = extract_manufacturer(manufacturer_uri, manufacturer_label)
            
            # Skip entries that don't look like real phones (too generic)
            if model_name in ["Smartphone", "Mobile phone", "Cellphone", "Phone"]:
                continue
                
            # Get additional details for this phone
            details = fetch_phone_details(phone_uri)
            
            # Create or reuse manufacturer URI
            if manufacturer_name not in manufacturers:
                manf_uri = URIRef(SMARTPHONE + manufacturer_name.replace(' ', '_'))
                g.add((manf_uri, RDF.type, SMARTPHONE.Manufacturer))
                g.add((manf_uri, SMARTPHONE.hasBrandName, Literal(manufacturer_name)))
                # Link to DBpedia resource if available
                if manufacturer_uri:
                    g.add((manf_uri, OWL.sameAs, URIRef(manufacturer_uri)))
                manufacturers[manufacturer_name] = manf_uri
            else:
                manf_uri = manufacturers[manufacturer_name]
            
            # Determine series name
            series_name = "Unknown Series"
            if "iPhone" in model_name:
                series_name = "iPhone"
            elif "Galaxy" in model_name:
                if "S" in model_name.split("Galaxy")[1][:2]:
                    series_name = "Galaxy S"
                elif "Note" in model_name.split("Galaxy")[1][:5]:
                    series_name = "Galaxy Note"
                elif "A" in model_name.split("Galaxy")[1][:2]:
                    series_name = "Galaxy A"
                else:
                    series_name = "Galaxy"
            
            # Create or reuse series URI
            series_key = f"{manufacturer_name}_{series_name}"
            if series_key not in series:
                series_uri = URIRef(SMARTPHONE + series_key.replace(' ', '_'))
                g.add((series_uri, RDF.type, SMARTPHONE.DeviceSeries))
                g.add((series_uri, RDFS.label, Literal(series_name)))
                g.add((series_uri, SMARTPHONE.manufacturedBy, manf_uri))
                series[series_key] = series_uri
            else:
                series_uri = series[series_key]
            
            # Create smartphone instance
            phone_id = model_name.replace(' ', '_')
            smartphone_uri = URIRef(SMARTPHONE + phone_id)
            
            # Type information and basic properties
            g.add((smartphone_uri, RDF.type, SMARTPHONE.Smartphone))
            g.add((smartphone_uri, SMARTPHONE.hasModelName, Literal(model_name)))
            g.add((smartphone_uri, SMARTPHONE.manufacturedBy, manf_uri))
            g.add((smartphone_uri, SMARTPHONE.belongsToSeries, series_uri))
            g.add((smartphone_uri, OWL.sameAs, URIRef(phone_uri)))
            
            # Add abstract if available
            abstract = result.get('abstract', {}).get('value') if 'abstract' in result else None
            if abstract:
                g.add((smartphone_uri, RDFS.comment, Literal(abstract)))
            
            # Add release date if available
            release_date = details.get('releaseDate', {}).get('value') if 'releaseDate' in details else None
            if release_date:
                g.add((smartphone_uri, SMARTPHONE.hasReleaseDate, Literal(release_date)))
            
            # Process display information
            display_info = details.get('display', {}).get('value') if 'display' in details else None
            if display_info:
                display_uri = URIRef(SMARTPHONE + f"Display_{phone_id}")
                g.add((display_uri, RDF.type, SMARTPHONE.Display))
                g.add((smartphone_uri, SMARTPHONE.hasDisplay, display_uri))
                
                # Try to extract screen size
                screen_size = extract_numeric_value(display_info, "inch")
                if screen_size:
                    g.add((display_uri, SMARTPHONE.hasScreenSize, Literal(screen_size, datatype=XSD.decimal)))
                
                # Add full display info as a comment
                g.add((display_uri, RDFS.comment, Literal(display_info)))
            
            # Process processor information
            cpu_info = details.get('cpu', {}).get('value') if 'cpu' in details else None
            if cpu_info:
                processor_uri = URIRef(SMARTPHONE + f"Processor_{phone_id}")
                g.add((processor_uri, RDF.type, SMARTPHONE.Processor))
                g.add((smartphone_uri, SMARTPHONE.hasProcessor, processor_uri))
                g.add((processor_uri, SMARTPHONE.hasChipsetModel, Literal(cpu_info)))
            
            # Process camera information
            camera_info = details.get('camera', {}).get('value') if 'camera' in details else None
            if camera_info:
                camera_uri = URIRef(SMARTPHONE + f"Camera_{phone_id}")
                g.add((camera_uri, RDF.type, SMARTPHONE.Camera))
                g.add((smartphone_uri, SMARTPHONE.hasMainCamera, camera_uri))
                
                # Try to extract megapixels
                mp_value = extract_numeric_value(camera_info, "MP")
                if mp_value:
                    g.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(mp_value, datatype=XSD.decimal)))
                
                # Add full camera info as a comment
                g.add((camera_uri, RDFS.comment, Literal(camera_info)))
            
            # Process memory information
            memory_info = details.get('memory', {}).get('value') if 'memory' in details else None
            storage_info = details.get('storage', {}).get('value') if 'storage' in details else None
            
            if memory_info or storage_info:
                memory_uri = URIRef(SMARTPHONE + f"Memory_{phone_id}")
                g.add((memory_uri, RDF.type, SMARTPHONE.Memory))
                g.add((smartphone_uri, SMARTPHONE.hasMemoryConfiguration, memory_uri))
                
                # Try to extract RAM size
                if memory_info:
                    ram_size = extract_numeric_value(memory_info, "GB")
                    if ram_size:
                        g.add((memory_uri, SMARTPHONE.hasRAMSize, Literal(int(ram_size), datatype=XSD.integer)))
                
                # Try to extract storage size
                if storage_info:
                    storage_size = extract_numeric_value(storage_info, "GB")
                    if storage_size:
                        g.add((memory_uri, SMARTPHONE.hasStorageSize, Literal(int(storage_size), datatype=XSD.integer)))
            
            # Process weight information
            weight_info = details.get('weight', {}).get('value') if 'weight' in details else None
            if weight_info:
                try:
                    weight_value = float(weight_info)
                    g.add((smartphone_uri, SMARTPHONE.hasWeight, Literal(weight_value, datatype=XSD.decimal)))
                except (ValueError, TypeError):
                    # Try parsing as string
                    weight_value = extract_numeric_value(weight_info, "g")
                    if weight_value:
                        g.add((smartphone_uri, SMARTPHONE.hasWeight, Literal(weight_value, datatype=XSD.decimal)))
            
            # Process OS information
            os_info = details.get('os', {}).get('value') if 'os' in details else None
            if os_info:
                g.add((smartphone_uri, SMARTPHONE.hasOperatingSystem, Literal(os_info)))
            
        except Exception as e:
            print(f"Error processing result: {e}")
            continue
    
    # Create output directory
    processed_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'processed')
    os.makedirs(processed_dir, exist_ok=True)
    
    # Save the RDF graph
    output_file = os.path.join(processed_dir, "smartphone-data-dbpedia.ttl")
    print(f"Saving DBpedia smartphone data to {output_file}")
    g.serialize(destination=output_file, format='turtle')
    
    print(f"Conversion complete. Generated {len(g)} triples.")
    return output_file

if __name__ == "__main__":
    start_time = time.time()
    output_file = dbpedia_to_rdf()
    end_time = time.time()
    print(f"Total processing time: {end_time - start_time:.2f} seconds")
