"""
Official Smartphone Data Integration

This script integrates smartphone data from authoritative sources:
- DBpedia
- Wikidata
- PhoneArena

It applies entity resolution to merge duplicate smartphone instances
and creates a unified knowledge graph aligned with standard vocabularies.
"""

import os
import glob
import re
import time
from rdflib import Graph, Namespace, Literal, URIRef, BNode
from rdflib.namespace import RDF, RDFS, OWL, XSD
from difflib import SequenceMatcher

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")
DBO = Namespace("http://dbpedia.org/ontology/")
DBR = Namespace("http://dbpedia.org/resource/")
SCHEMA = Namespace("http://schema.org/")
GR = Namespace("http://purl.org/goodrelations/v1#")
WD = Namespace("http://www.wikidata.org/entity/")

def similarity(a, b):
    """Calculate string similarity between two strings"""
    if not a or not b:
        return 0
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()

def normalize_model_name(name):
    """Normalize smartphone model names for better matching"""
    if not name:
        return ""
    
    # Convert to lowercase
    normalized = name.lower()
    
    # Remove common prefixes and suffixes
    prefixes = ["smartphone", "phone", "mobile"]
    for prefix in prefixes:
        if normalized.startswith(prefix):
            normalized = normalized[len(prefix):].strip()
    
    # Replace special characters with spaces
    normalized = re.sub(r'[^\w\s]', ' ', normalized)
    
    # Remove extra whitespace
    normalized = re.sub(r'\s+', ' ', normalized).strip()
    
    return normalized

def get_model_identifier(manufacturer, model_name):
    """Create a normalized identifier for a smartphone model"""
    if not manufacturer or not model_name:
        return None
    
    norm_manufacturer = normalize_model_name(manufacturer)
    norm_model = normalize_model_name(model_name)
    
    return f"{norm_manufacturer}_{norm_model}"

def find_canonical_uri(entities_by_id, entity_id, uri, similarity_threshold=0.85):
    """Find the canonical URI for a smartphone entity"""
    # If we already have an exact match, use it
    if entity_id in entities_by_id:
        existing_entities = entities_by_id[entity_id]
        
        # Prioritize URIs from our own namespace over external ones
        for existing_uri in existing_entities:
            if str(existing_uri).startswith(str(SMARTPHONE)):
                return existing_uri
        
        # If no internal URI, use the first one
        return existing_entities[0]
    
    # Look for similar entities
    for existing_id, existing_entities in entities_by_id.items():
        # Calculate similarity between IDs
        sim = similarity(entity_id, existing_id)
        if sim >= similarity_threshold:
            # Found a similar enough match
            for existing_uri in existing_entities:
                if str(existing_uri).startswith(str(SMARTPHONE)):
                    return existing_uri
            
            # If no internal URI, use the first one
            return existing_entities[0]
    
    # No match found, use the provided URI
    return uri

def integrate_official_smartphone_data():
    """Integrate smartphone data from official sources"""
    print("Starting official smartphone data integration...")
    start_time = time.time()
    
    # Output directory
    processed_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'processed')
    os.makedirs(processed_dir, exist_ok=True)
    
    # Find all processed TTL files
    ttl_files = []
    
    # Look for DBpedia data
    dbpedia_file = os.path.join(processed_dir, "smartphone-data-dbpedia.ttl")
    if os.path.exists(dbpedia_file):
        ttl_files.append(dbpedia_file)
    
    # Look for Wikidata data
    wikidata_file = os.path.join(processed_dir, "smartphone-data-wikidata.ttl")
    if os.path.exists(wikidata_file):
        ttl_files.append(wikidata_file)
    
    # Look for PhoneArena data
    phonearena_file = os.path.join(processed_dir, "smartphone-data-phonearena.ttl")
    if os.path.exists(phonearena_file):
        ttl_files.append(phonearena_file)
    
    # If no files found, return
    if not ttl_files:
        print("No official data files found to integrate.")
        return
    
    print(f"Found {len(ttl_files)} official data files to integrate:")
    for file in ttl_files:
        print(f"  - {os.path.basename(file)}")
    
    # Load all graphs
    source_graphs = []
    for ttl_file in ttl_files:
        print(f"Loading {os.path.basename(ttl_file)}...")
        g = Graph()
        g.parse(ttl_file, format='turtle')
        source_graphs.append(g)
        print(f"  - Loaded {len(g)} triples")
    
    # Create integrated graph
    integrated_graph = Graph()
    
    # Bind namespaces
    integrated_graph.bind("smartphone", SMARTPHONE)
    integrated_graph.bind("dbo", DBO)
    integrated_graph.bind("dbr", DBR)
    integrated_graph.bind("schema", SCHEMA)
    integrated_graph.bind("gr", GR)
    integrated_graph.bind("wd", WD)
    integrated_graph.bind("owl", OWL)
    
    # Step 1: Find all smartphone entities and their manufacturer/model info
    print("Identifying smartphone entities across all sources...")
    
    entities_by_uri = {}  # URI -> (manufacturer, model)
    entities_by_id = {}   # normalized_id -> [URIs]
    
    for graph in source_graphs:
        for s, p, o in graph.triples((None, RDF.type, SMARTPHONE.Smartphone)):
            # Get manufacturer
            manufacturer = None
            for _, _, manf in graph.triples((s, SMARTPHONE.manufacturedBy, None)):
                for _, _, name in graph.triples((manf, SMARTPHONE.hasBrandName, None)):
                    manufacturer = str(name)
                    break
            
            # Get model name
            model_name = None
            for _, _, name in graph.triples((s, SMARTPHONE.hasModelName, None)):
                model_name = str(name)
                break
            
            if manufacturer and model_name:
                entities_by_uri[s] = (manufacturer, model_name)
                
                # Create normalized ID
                entity_id = get_model_identifier(manufacturer, model_name)
                if entity_id:
                    if entity_id not in entities_by_id:
                        entities_by_id[entity_id] = []
                    entities_by_id[entity_id].append(s)
    
    print(f"Found {len(entities_by_uri)} smartphone entities across all sources")
    print(f"Identified {len(entities_by_id)} unique smartphone models")
    
    # Step 2: Create canonical URIs for each unique smartphone
    print("Creating canonical URIs for each unique smartphone model...")
    
    canonical_uris = {}  # source_uri -> canonical_uri
    
    for uri, (manufacturer, model_name) in entities_by_uri.items():
        entity_id = get_model_identifier(manufacturer, model_name)
        canonical_uri = find_canonical_uri(entities_by_id, entity_id, uri)
        canonical_uris[uri] = canonical_uri
    
    # Step 3: Copy all triples to the integrated graph, replacing URIs
    print("Copying triples to the integrated graph...")
    
    for graph in source_graphs:
        for s, p, o in graph:
            # Replace subject URI if it's a known smartphone
            new_s = canonical_uris.get(s, s)
            
            # Replace object URI if it's a known smartphone
            new_o = o
            if isinstance(o, URIRef) and o in canonical_uris:
                new_o = canonical_uris[o]
            
            # Replace URIs in component links (display, camera, etc.)
            new_p = p
            if s in canonical_uris and p in [SMARTPHONE.hasDisplay, SMARTPHONE.hasProcessor,
                                           SMARTPHONE.hasBattery, SMARTPHONE.hasMainCamera,
                                           SMARTPHONE.hasMemoryConfiguration]:
                # Don't add component links for non-canonical URIs
                if s != canonical_uris[s]:
                    continue
            
            # Add the triple to the integrated graph
            integrated_graph.add((new_s, new_p, new_o))
    
    # Step 4: Add owl:sameAs links for equivalent URIs
    print("Adding owl:sameAs links for equivalent entities...")
    
    for original_uri, canonical_uri in canonical_uris.items():
        if original_uri != canonical_uri:
            integrated_graph.add((canonical_uri, OWL.sameAs, original_uri))
    
    # Step 5: Add provenance information
    print("Adding data source information...")
    
    # Add source information for each dataset
    for i, ttl_file in enumerate(ttl_files):
        source_name = os.path.basename(ttl_file).replace("smartphone-data-", "").replace(".ttl", "")
        source_uri = URIRef(SMARTPHONE + f"DataSource_{source_name}")
        
        integrated_graph.add((source_uri, RDF.type, SMARTPHONE.DataSource))
        integrated_graph.add((source_uri, RDFS.label, Literal(f"Smartphone Data from {source_name.capitalize()}")))
        integrated_graph.add((source_uri, RDFS.comment, Literal(f"Data extracted from {source_name} on {time.strftime('%Y-%m-%d')}")))
    
    # Step 6: Save the integrated graph
    output_file = os.path.join(processed_dir, "smartphone-data-official.ttl")
    print(f"Saving integrated graph to {output_file}")
    integrated_graph.serialize(destination=output_file, format='turtle')
    
    end_time = time.time()
    duration = end_time - start_time
    
    print(f"Integration complete!")
    print(f"Integrated graph contains {len(integrated_graph)} triples")
    print(f"Processing time: {duration:.2f} seconds ({duration/60:.2f} minutes)")
    print(f"Output saved to {output_file}")
    
    return output_file

if __name__ == "__main__":
    output_file = integrate_official_smartphone_data()
    print(f"Official dataset saved to {output_file}")
