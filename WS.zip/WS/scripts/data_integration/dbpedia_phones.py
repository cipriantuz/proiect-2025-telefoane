"""
DBpedia Smartphone Data Extractor

This script fetches smartphone data from DBpedia's SPARQL endpoint and 
converts it into a standardized RDF format aligned with our smartphone ontology.
"""

import os
import time
from SPARQLWrapper import SPARQLWrapper, JSON
from rdflib import Graph, Namespace, Literal, URIRef, BNode
from rdflib.namespace import RDF, RDFS, XSD, OWL, FOAF

# Define namespaces
SMARTPHONE = Namespace("http://www.semanticweb.org/smartphone-ontology#")
DBO = Namespace("http://dbpedia.org/ontology/")
DBR = Namespace("http://dbpedia.org/resource/")
DBP = Namespace("http://dbpedia.org/property/")
SCHEMA = Namespace("http://schema.org/")
GR = Namespace("http://purl.org/goodrelations/v1#")

def fetch_smartphones_from_dbpedia(limit=1000):
    """Fetch smartphone data from DBpedia's SPARQL endpoint"""
    print("Fetching smartphone data from DBpedia...")
    
    # Initialize SPARQLWrapper
    sparql = SPARQLWrapper("http://dbpedia.org/sparql")
    sparql.setReturnFormat(JSON)
    
    # Construct SPARQL query
    query = """
    PREFIX dbo: <http://dbpedia.org/ontology/>
    PREFIX dbp: <http://dbpedia.org/property/>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT DISTINCT ?phone ?label ?abstract ?manufacturer ?releaseDate ?cpu ?memory ?os ?weight ?display ?camera ?storage
    WHERE {
        ?phone a dbo:MobilePhone .
        OPTIONAL { ?phone rdfs:label ?label . FILTER(LANG(?label) = 'en') }
        OPTIONAL { ?phone dbo:abstract ?abstract . FILTER(LANG(?abstract) = 'en') }
        OPTIONAL { ?phone dbo:manufacturer ?manufacturer }
        OPTIONAL { ?phone dbp:releaseDate ?releaseDate }
        OPTIONAL { ?phone dbp:cpu ?cpu }
        OPTIONAL { ?phone dbp:memory ?memory }
        OPTIONAL { ?phone dbp:operatingSystem ?os }
        OPTIONAL { ?phone dbo:weight ?weight }
        OPTIONAL { ?phone dbp:display ?display }
        OPTIONAL { ?phone dbp:camera ?camera }
        OPTIONAL { ?phone dbp:storage ?storage }
    }
    LIMIT """ + str(limit)
    
    # Execute query
    sparql.setQuery(query)
    try:
        results = sparql.query().convert()
        return results["results"]["bindings"]
    except Exception as e:
        print(f"Error fetching data from DBpedia: {e}")
        return []

def extract_model_name(uri, label=None):
    """Extract a clean model name from the DBpedia URI or label"""
    if label and isinstance(label, str):
        return label.strip()
    
    # Extract model name from URI
    uri_parts = uri.split('/')
    model_name = uri_parts[-1].replace('_', ' ')
    return model_name

def extract_manufacturer(manufacturer_uri):
    """Extract the manufacturer name from a DBpedia URI"""
    if not manufacturer_uri:
        return "Unknown"
    
    # Extract name from URI
    uri_parts = manufacturer_uri.split('/')
    manufacturer_name = uri_parts[-1].replace('_', ' ')
    
    # Handle common manufacturer formatting
    manufacturer_lookup = {
        "Samsung": "Samsung",
        "Samsung Electronics": "Samsung",
        "Samsung Group": "Samsung",
        "Apple Inc": "Apple",
        "Apple": "Apple",
        "Xiaomi": "Xiaomi",
        "Huawei": "Huawei",
        "Sony": "Sony",
        "Sony Corporation": "Sony",
        "Sony Mobile": "Sony",
        "Google": "Google",
        "OnePlus": "OnePlus",
        "HTC": "HTC",
        "HTC Corporation": "HTC",
        "LG": "LG",
        "LG Electronics": "LG",
        "Motorola": "Motorola",
        "Motorola Mobility": "Motorola",
        "Nokia": "Nokia",
        "Nokia Corporation": "Nokia",
        "Oppo": "Oppo"
    }
    
    return manufacturer_lookup.get(manufacturer_name, manufacturer_name)

def extract_numeric_value(value, unit=None):
    """Extract numeric values from string representations"""
    if not value:
        return None
    
    import re
    
    # Handle common units
    if unit == "GB" or unit == "gigabyte":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:GB|gigabytes?|G)'
    elif unit == "MP" or unit == "megapixel":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:MP|megapixels?)'
    elif unit == "inch":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:inches?|"|in)'
    elif unit == "mAh":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:mAh)'
    elif unit == "g" or unit == "gram":
        pattern = r'(\d+(?:\.\d+)?)\s*(?:g|grams?)'
    else:
        # Generic number extraction
        pattern = r'(\d+(?:\.\d+)?)'
    
    match = re.search(pattern, str(value), re.IGNORECASE)
    return float(match.group(1)) if match else None

def dbpedia_to_rdf():
    """Convert DBpedia smartphone data to our ontology format"""
    print("Starting DBpedia smartphone data conversion...")
    
    # Fetch data from DBpedia
    results = fetch_smartphones_from_dbpedia()
    
    if not results:
        print("No results from DBpedia. Exiting.")
        return
    
    print(f"Retrieved {len(results)} smartphones from DBpedia.")
    
    # Create RDF graph
    g = Graph()
    
    # Bind namespaces
    g.bind("smartphone", SMARTPHONE)
    g.bind("dbo", DBO)
    g.bind("dbr", DBR)
    g.bind("dbp", DBP)
    g.bind("schema", SCHEMA)
    g.bind("gr", GR)
    g.bind("owl", OWL)
    
    # Track manufacturers and series to avoid duplication
    manufacturers = {}
    series = {}
    
    # Process results
    for result in results:
        try:
            # Extract basic information
            phone_uri = result.get('phone', {}).get('value')
            if not phone_uri:
                continue
            
            label = result.get('label', {}).get('value') if 'label' in result else None
            manufacturer_uri = result.get('manufacturer', {}).get('value') if 'manufacturer' in result else None
            
            model_name = extract_model_name(phone_uri, label)
            manufacturer_name = extract_manufacturer(manufacturer_uri)
            
            # Create or reuse manufacturer URI
            if manufacturer_name not in manufacturers:
                manf_uri = URIRef(SMARTPHONE + manufacturer_name.replace(' ', '_'))
                g.add((manf_uri, RDF.type, SMARTPHONE.Manufacturer))
                g.add((manf_uri, SMARTPHONE.hasBrandName, Literal(manufacturer_name)))
                # Link to DBpedia resource if available
                if manufacturer_uri:
                    g.add((manf_uri, OWL.sameAs, URIRef(manufacturer_uri)))
                manufacturers[manufacturer_name] = manf_uri
            else:
                manf_uri = manufacturers[manufacturer_name]
            
            # Determine series name
            series_name = "Unknown Series"
            if "iPhone" in model_name:
                series_name = "iPhone"
            elif "Galaxy" in model_name:
                if "S" in model_name.split("Galaxy")[1][:2]:
                    series_name = "Galaxy S"
                elif "Note" in model_name.split("Galaxy")[1][:5]:
                    series_name = "Galaxy Note"
                elif "A" in model_name.split("Galaxy")[1][:2]:
                    series_name = "Galaxy A"
                else:
                    series_name = "Galaxy"
            
            # Create or reuse series URI
            series_key = f"{manufacturer_name}_{series_name}"
            if series_key not in series:
                series_uri = URIRef(SMARTPHONE + series_key.replace(' ', '_'))
                g.add((series_uri, RDF.type, SMARTPHONE.DeviceSeries))
                g.add((series_uri, RDFS.label, Literal(series_name)))
                g.add((series_uri, SMARTPHONE.manufacturedBy, manf_uri))
                series[series_key] = series_uri
            else:
                series_uri = series[series_key]
            
            # Create smartphone instance
            phone_id = model_name.replace(' ', '_')
            smartphone_uri = URIRef(SMARTPHONE + phone_id)
            
            # Type information and basic properties
            g.add((smartphone_uri, RDF.type, SMARTPHONE.Smartphone))
            g.add((smartphone_uri, SMARTPHONE.hasModelName, Literal(model_name)))
            g.add((smartphone_uri, SMARTPHONE.manufacturedBy, manf_uri))
            g.add((smartphone_uri, SMARTPHONE.belongsToSeries, series_uri))
            g.add((smartphone_uri, OWL.sameAs, URIRef(phone_uri)))
            
            # Add release date if available
            release_date = result.get('releaseDate', {}).get('value') if 'releaseDate' in result else None
            if release_date:
                g.add((smartphone_uri, SMARTPHONE.hasReleaseDate, Literal(release_date)))
            
            # Process display information
            display_info = result.get('display', {}).get('value') if 'display' in result else None
            if display_info:
                display_uri = URIRef(SMARTPHONE + f"Display_{phone_id}")
                g.add((display_uri, RDF.type, SMARTPHONE.Display))
                g.add((smartphone_uri, SMARTPHONE.hasDisplay, display_uri))
                
                # Try to extract screen size
                screen_size = extract_numeric_value(display_info, "inch")
                if screen_size:
                    g.add((display_uri, SMARTPHONE.hasScreenSize, Literal(screen_size, datatype=XSD.decimal)))
                
                # Add full display info as a comment
                g.add((display_uri, RDFS.comment, Literal(display_info)))
            
            # Process processor information
            cpu_info = result.get('cpu', {}).get('value') if 'cpu' in result else None
            if cpu_info:
                processor_uri = URIRef(SMARTPHONE + f"Processor_{phone_id}")
                g.add((processor_uri, RDF.type, SMARTPHONE.Processor))
                g.add((smartphone_uri, SMARTPHONE.hasProcessor, processor_uri))
                g.add((processor_uri, SMARTPHONE.hasChipsetModel, Literal(cpu_info)))
            
            # Process camera information
            camera_info = result.get('camera', {}).get('value') if 'camera' in result else None
            if camera_info:
                camera_uri = URIRef(SMARTPHONE + f"Camera_{phone_id}")
                g.add((camera_uri, RDF.type, SMARTPHONE.Camera))
                g.add((smartphone_uri, SMARTPHONE.hasMainCamera, camera_uri))
                
                # Try to extract megapixels
                mp_value = extract_numeric_value(camera_info, "MP")
                if mp_value:
                    g.add((camera_uri, SMARTPHONE.hasResolutionMP, Literal(mp_value, datatype=XSD.decimal)))
                
                # Add full camera info as a comment
                g.add((camera_uri, RDFS.comment, Literal(camera_info)))
            
            # Process memory information
            memory_info = result.get('memory', {}).get('value') if 'memory' in result else None
            storage_info = result.get('storage', {}).get('value') if 'storage' in result else None
            
            if memory_info or storage_info:
                memory_uri = URIRef(SMARTPHONE + f"Memory_{phone_id}")
                g.add((memory_uri, RDF.type, SMARTPHONE.Memory))
                g.add((smartphone_uri, SMARTPHONE.hasMemoryConfiguration, memory_uri))
                
                # Try to extract RAM size
                if memory_info:
                    ram_size = extract_numeric_value(memory_info, "GB")
                    if ram_size:
                        g.add((memory_uri, SMARTPHONE.hasRAMSize, Literal(int(ram_size), datatype=XSD.integer)))
                
                # Try to extract storage size
                if storage_info:
                    storage_size = extract_numeric_value(storage_info, "GB")
                    if storage_size:
                        g.add((memory_uri, SMARTPHONE.hasStorageSize, Literal(int(storage_size), datatype=XSD.integer)))
            
            # Process weight information
            weight_info = result.get('weight', {}).get('value') if 'weight' in result else None
            if weight_info:
                try:
                    weight_value = float(weight_info)
                    g.add((smartphone_uri, SMARTPHONE.hasWeight, Literal(weight_value, datatype=XSD.decimal)))
                except (ValueError, TypeError):
                    # Try parsing as string
                    weight_value = extract_numeric_value(weight_info, "g")
                    if weight_value:
                        g.add((smartphone_uri, SMARTPHONE.hasWeight, Literal(weight_value, datatype=XSD.decimal)))
            
            # Process OS information
            os_info = result.get('os', {}).get('value') if 'os' in result else None
            if os_info:
                g.add((smartphone_uri, SMARTPHONE.hasOperatingSystem, Literal(os_info)))
            
            # Process abstract information
            abstract = result.get('abstract', {}).get('value') if 'abstract' in result else None
            if abstract:
                g.add((smartphone_uri, RDFS.comment, Literal(abstract)))
        
        except Exception as e:
            print(f"Error processing result: {e}")
            continue
    
    # Create output directory
    processed_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data', 'processed')
    os.makedirs(processed_dir, exist_ok=True)
    
    # Save the RDF graph
    output_file = os.path.join(processed_dir, "smartphone-data-dbpedia.ttl")
    print(f"Saving DBpedia smartphone data to {output_file}")
    g.serialize(destination=output_file, format='turtle')
    
    print(f"Conversion complete. Generated {len(g)} triples for {len(results)} smartphones.")
    return output_file

if __name__ == "__main__":
    start_time = time.time()
    output_file = dbpedia_to_rdf()
    end_time = time.time()
    print(f"Total processing time: {end_time - start_time:.2f} seconds")
