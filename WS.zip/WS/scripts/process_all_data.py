import os
import subprocess
import sys
import time

def run_command(command, description):
    """Run a command and print its output"""
    print(f"\n{'='*80}")
    print(f"RUNNING: {description}")
    print(f"{'='*80}\n")
    
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        universal_newlines=True,
        shell=True
    )
    
    # Print output in real-time
    for line in process.stdout:
        print(line.strip())
    
    process.wait()
    
    if process.returncode != 0:
        print(f"ERROR: {description} failed with return code {process.returncode}")
        return False
    
    print(f"\nSUCCESS: {description} completed successfully")
    return True

def main():
    """Run all data processing steps in sequence"""
    start_time = time.time()
    
    # Get the path to the processing scripts
    scripts_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'processing')
    
    # Step 1: Process sample files
    if not run_command(
        f"python {os.path.join(scripts_dir, 'json_to_rdf.py')}",
        "Processing sample smartphone data"
    ):
        return

    # Step 2: Process GitHub dataset (if available)
    github_data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'raw', 'github')
    if os.path.exists(github_data_dir):
        if not run_command(
            f"python {os.path.join(scripts_dir, 'process_github_data.py')}",
            "Processing GitHub smartphone dataset"
        ):
            return
    
    # Step 3: Process GSMArena dataset (if available)
    gsmarena_data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'raw', 'gsmarena')
    if os.path.exists(gsmarena_data_dir) and len(os.listdir(gsmarena_data_dir)) > 0:
        if not run_command(
            f"python {os.path.join(scripts_dir, 'process_gsmarena_data.py')}",
            "Processing GSMArena smartphone dataset"
        ):
            return
    
    # Step 4: Deduplicate all data
    if not run_command(
        f"python {os.path.join(scripts_dir, 'deduplicate_phones.py')}",
        "Deduplicating smartphone data"
    ):
        return
    
    # Print completion message
    end_time = time.time()
    print(f"\n{'='*80}")
    print(f"ALL PROCESSING COMPLETED SUCCESSFULLY in {end_time - start_time:.2f} seconds")
    print(f"{'='*80}\n")
    print("The deduplicated dataset is available at: data/processed/smartphone-data-deduplicated.ttl")
    print("You can load this file into Apache Jena Fuseki for querying.")

if __name__ == "__main__":
    main()
