"""
CSV Inspection Script

This script inspects the structure of the smartphone dataset CSV file
to help understand its format and content.

Usage:
    python inspect_csv.py

Author: Claude
Date: May 2025
"""

import os
import pandas as pd
import csv
import sys

def inspect_csv():
    """Inspect the structure of the CSV file"""
    print("Inspecting the smartphone dataset CSV file...")
    
    # Get project base directory
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    csv_path = os.path.join(base_dir, 'data', 'raw', 'github', 'smartphones.csv')
    
    # Check if file exists
    if not os.path.exists(csv_path):
        print(f"Error: {csv_path} not found.")
        return
    
    # First, try to detect the CSV format
    print("\nAttempting to detect CSV format...")
    try:
        with open(csv_path, 'r', newline='', encoding='utf-8') as f:
            # Read the first few lines to determine the dialect
            sample = f.read(2048)
            dialect = csv.Sniffer().sniff(sample)
            print(f"Detected delimiter: '{dialect.delimiter}'")
            print(f"Detected quote character: '{dialect.quotechar}'")
            print(f"Detected line terminator: {repr(dialect.lineterminator)}")
    except Exception as e:
        print(f"Could not detect CSV format: {e}")
    
    # Now, try to read the first few rows directly to see the content
    print("\nExamining file content directly...")
    try:
        with open(csv_path, 'r', encoding='utf-8') as f:
            for i, line in enumerate(f):
                if i < 5:  # Show first 5 lines
                    print(f"Line {i+1}: {line.strip()}")
                else:
                    break
    except UnicodeDecodeError:
        print("Unicode decode error. Trying with latin1 encoding...")
        try:
            with open(csv_path, 'r', encoding='latin1') as f:
                for i, line in enumerate(f):
                    if i < 5:  # Show first 5 lines
                        print(f"Line {i+1}: {line.strip()}")
                    else:
                        break
        except Exception as e:
            print(f"Error reading file with latin1 encoding: {e}")
    except Exception as e:
        print(f"Error reading file: {e}")
    
    # Try to read with pandas to see the structure
    print("\nAttempting to read with pandas...")
    
    # Try different combinations of parameters
    encodings = ['utf-8', 'latin1']
    separators = [',', ';', '\t', '|']
    
    for encoding in encodings:
        for sep in separators:
            try:
                print(f"\nTrying with encoding='{encoding}', sep='{sep}'")
                df = pd.read_csv(csv_path, encoding=encoding, sep=sep, nrows=5)
                print(f"Success! Found {len(df.columns)} columns:")
                for col in df.columns:
                    print(f"  - {col}")
                print("\nSample data (first 3 rows):")
                print(df.head(3))
                
                # If successful, provide recommendation
                print("\nRecommended pandas read_csv parameters:")
                print(f"df = pd.read_csv('{csv_path}', encoding='{encoding}', sep='{sep}')")
                
                # Exit after the first successful attempt
                return
            except Exception as e:
                print(f"Failed: {e}")
    
    print("\nCould not successfully parse the CSV file with any of the attempted parameters.")
    print("The file may be corrupted or in a non-standard format.")

if __name__ == "__main__":
    inspect_csv()
