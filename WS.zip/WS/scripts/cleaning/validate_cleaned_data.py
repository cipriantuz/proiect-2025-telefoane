"""
Smartphone Dataset Validation Script

This script validates the cleaned smartphone data to ensure quality
and completeness before processing into RDF format.

Usage:
    python validate_cleaned_data.py

Author: Claude
Date: May 2025
"""

import os
import json
import glob
import pandas as pd
from collections import defaultdict

# Try to import matplotlib, but continue if not available
try:
    import matplotlib.pyplot as plt
    import numpy as np
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    print("Warning: matplotlib not installed. Visualization will be skipped.")
    MATPLOTLIB_AVAILABLE = False

def validate_cleaned_data():
    """Main function to validate cleaned smartphone data"""
    print("Validating cleaned smartphone data...")
    
    # Get project base directory
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    json_dir = os.path.join(base_dir, 'data', 'raw', 'github', 'json')
    
    # Check if directory exists
    if not os.path.exists(json_dir):
        print(f"Error: {json_dir} not found. Run clean_github_dataset.py first.")
        return
    
    # Get all JSON files
    json_files = glob.glob(os.path.join(json_dir, '*.json'))
    
    if not json_files:
        print(f"Error: No JSON files found in {json_dir}.")
        return
    
    print(f"Found {len(json_files)} smartphone JSON files to validate.")
    
    # Initialize data structures
    all_data = []
    field_completion = defaultdict(int)
    brand_counts = defaultdict(int)
    model_counts = defaultdict(lambda: defaultdict(int))
    series_counts = defaultdict(int)
    
    # Required fields for a complete record
    required_fields = [
        'manufacturer', 'model_name', 'series', 'display_size', 
        'processor_chipset', 'main_camera', 'battery_capacity', 'memory'
    ]
    
    # Validate each JSON file
    for json_file in json_files:
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Track field completion
            for field in required_fields:
                if field in data and data[field] and data[field] != "":
                    field_completion[field] += 1
            
            # Track brand distribution
            brand = data.get('manufacturer', 'Unknown')
            brand_counts[brand] += 1
            
            # Track series distribution
            series = data.get('series', 'Unknown')
            series_counts[series] += 1
            
            # Track model distribution within brands
            model = data.get('model_name', 'Unknown')
            model_counts[brand][model] += 1
            
            # Save data for later analysis
            all_data.append(data)
        
        except Exception as e:
            print(f"Error processing {json_file}: {e}")
    
    # Convert to DataFrame for easier analysis
    df = pd.DataFrame(all_data)
    
    # Calculate data completeness
    total_phones = len(all_data)
    print(f"\nData Completeness:")
    for field in required_fields:
        completion_percent = (field_completion[field] / total_phones) * 100
        print(f"  {field}: {field_completion[field]}/{total_phones} ({completion_percent:.1f}%)")
    
    # Check for potential duplicates (phones with same brand and model)
    if 'manufacturer' in df.columns and 'model_name' in df.columns:
        df['brand_model'] = df['manufacturer'] + "_" + df['model_name']
        brand_model_counts = df['brand_model'].value_counts()
        duplicates = brand_model_counts[brand_model_counts > 1]
        
        if not duplicates.empty:
            print(f"\nPotential Duplicates:")
            for brand_model, count in duplicates.items():
                print(f"  {brand_model.replace('_', ' ')}: {count} entries")
    
    # Print brand distribution
    print(f"\nBrand Distribution (top 10):")
    for brand, count in sorted(brand_counts.items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"  {brand}: {count} phones")
    
    # Print series distribution
    print(f"\nSeries Distribution (top 10):")
    for series, count in sorted(series_counts.items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"  {series}: {count} phones")
    
    # Generate validation report
    report_dir = os.path.join(base_dir, 'data', 'reports')
    os.makedirs(report_dir, exist_ok=True)
    report_path = os.path.join(report_dir, 'data_validation_report.txt')
    
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("Smartphone Dataset Validation Report\n")
        f.write("===================================\n\n")
        
        f.write(f"Total Phones: {total_phones}\n\n")
        
        f.write("Data Completeness:\n")
        for field in required_fields:
            completion_percent = (field_completion[field] / total_phones) * 100
            f.write(f"  {field}: {field_completion[field]}/{total_phones} ({completion_percent:.1f}%)\n")
        
        f.write("\nBrand Distribution (top 10):\n")
        for brand, count in sorted(brand_counts.items(), key=lambda x: x[1], reverse=True)[:10]:
            f.write(f"  {brand}: {count} phones\n")
        
        f.write("\nSeries Distribution (top 10):\n")
        for series, count in sorted(series_counts.items(), key=lambda x: x[1], reverse=True)[:10]:
            f.write(f"  {series}: {count} phones\n")
        
        if 'brand_model' in df.columns:
            duplicates = brand_model_counts[brand_model_counts > 1]
            if not duplicates.empty:
                f.write("\nPotential Duplicates:\n")
                for brand_model, count in duplicates.items():
                    f.write(f"  {brand_model.replace('_', ' ')}: {count} entries\n")
        
        # Add data quality checks
        if 'battery_capacity' in df.columns:
            # Extract numeric values from battery capacity strings
            df['battery_numeric'] = df['battery_capacity'].str.extract(r'(\d+)').astype(float)
            battery_min = df['battery_numeric'].min()
            battery_max = df['battery_numeric'].max()
            battery_avg = df['battery_numeric'].mean()
            
            f.write("\nBattery Capacity Statistics:\n")
            f.write(f"  Min: {battery_min} mAh\n")
            f.write(f"  Max: {battery_max} mAh\n")
            f.write(f"  Avg: {battery_avg:.1f} mAh\n")
        
        if 'main_camera' in df.columns:
            # Extract numeric values from camera strings
            df['camera_mp'] = df['main_camera'].str.extract(r'(\d+)').astype(float)
            camera_min = df['camera_mp'].min()
            camera_max = df['camera_mp'].max()
            camera_avg = df['camera_mp'].mean()
            
            f.write("\nMain Camera Statistics:\n")
            f.write(f"  Min: {camera_min} MP\n")
            f.write(f"  Max: {camera_max} MP\n")
            f.write(f"  Avg: {camera_avg:.1f} MP\n")
    
    print(f"\nValidation complete! Report saved to: {report_path}")
    
    # Generate some visualizations if matplotlib is available
    if MATPLOTLIB_AVAILABLE:
        try:
            # Create charts directory
            charts_dir = os.path.join(report_dir, 'charts')
            os.makedirs(charts_dir, exist_ok=True)
            
            # Brand distribution pie chart
            plt.figure(figsize=(12, 8))
            brands = sorted(brand_counts.items(), key=lambda x: x[1], reverse=True)
            top_brands = brands[:8]  # Top 8 brands
            other_count = sum(count for _, count in brands[8:])
            if other_count > 0:
                top_brands.append(('Others', other_count))
            
            labels = [f"{brand} ({count})" for brand, count in top_brands]
            values = [count for _, count in top_brands]
            
            plt.pie(values, labels=labels, autopct='%1.1f%%', startangle=90)
            plt.axis('equal')
            plt.title('Smartphone Brand Distribution')
            plt.savefig(os.path.join(charts_dir, 'brand_distribution.png'))
            
            # Series distribution bar chart
            plt.figure(figsize=(14, 8))
            series_data = sorted(series_counts.items(), key=lambda x: x[1], reverse=True)[:15]  # Top 15 series
            series_names = [name for name, _ in series_data]
            series_values = [count for _, count in series_data]
            
            plt.barh(series_names, series_values)
            plt.xlabel('Number of Phones')
            plt.ylabel('Series')
            plt.title('Top 15 Smartphone Series')
            plt.tight_layout()
            plt.savefig(os.path.join(charts_dir, 'series_distribution.png'))
            
            # Data completeness bar chart
            plt.figure(figsize=(12, 6))
            completion_labels = required_fields
            completion_values = [(field_completion[field] / total_phones) * 100 for field in required_fields]
            
            plt.bar(completion_labels, completion_values)
            plt.axhline(y=90, color='r', linestyle='--', label='90% Threshold')
            plt.xlabel('Field')
            plt.ylabel('Completion Rate (%)')
            plt.title('Data Completeness by Field')
            plt.xticks(rotation=45)
            plt.legend()
            plt.tight_layout()
            plt.savefig(os.path.join(charts_dir, 'data_completeness.png'))
            
            print(f"Visualizations saved to: {charts_dir}")
        except Exception as e:
            print(f"Warning: Could not generate visualizations: {e}")
            print("Continue with data validation without charts.")
    else:
        print("Skipping visualization generation as matplotlib is not installed.")
        print("To enable visualizations, install matplotlib: pip install matplotlib")
    
    # Return validation summary
    validation_summary = {
        'total_phones': total_phones,
        'field_completion': field_completion,
        'brand_counts': brand_counts,
        'series_counts': series_counts,
        'potential_duplicates': len(duplicates) if 'duplicates' in locals() else 0
    }
    
    return validation_summary


if __name__ == "__main__":
    validate_cleaned_data()
