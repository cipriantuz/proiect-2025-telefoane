# Smartphone Ontology - Enhanced Data Integration

This document explains the enhanced data integration pipeline that leverages established knowledge bases and vocabularies to create a comprehensive smartphone ontology.

## Overview

The enhanced data integration pipeline collects smartphone data from multiple authoritative sources and aligns it with standard semantic web vocabularies:

1. **Data Sources**:
   - DBpedia (`dbo:MobilePhone` instances)
   - Wikidata (smartphone instances)
   - GSMArena (scraped specifications)
   - GitHub dataset
   - Sample files

2. **Ontology Alignment**:
   - DBpedia Ontology (`dbo:MobilePhone`)
   - Schema.org (`schema:Product`)
   - GoodRelations (`gr:ProductOrService`)

3. **Entity Resolution**:
   - Normalized model identifiers
   - String similarity matching
   - Canonical URI selection
   - `owl:sameAs` linking

## Running the Integration Pipeline

### Option 1: Using the Batch File (Recommended)

Simply run the batch file:

```
run_data_integration.bat
```

This will execute the complete pipeline and generate:
- Aligned ontology: `onto/smartphone-ontology-aligned.owl`
- Integrated dataset: `data/processed/smartphone-data-integrated.ttl`

### Option 2: Running Individual Components

If you want more control or need to troubleshoot:

1. **Fetch DBpedia data**:
   ```
   python scripts/data_integration/dbpedia_phones.py
   ```

2. **Fetch Wikidata data**:
   ```
   python scripts/data_integration/wikidata_phones.py
   ```

3. **Create aligned ontology**:
   ```
   python scripts/data_integration/align_ontology.py
   ```

4. **Process existing data sources**:
   ```
   python scripts/process_all_data.py
   ```

5. **Integrate all datasets**:
   ```
   python scripts/data_integration/integrate_datasets.py
   ```

## Data Sources Details

### 1. DBpedia

DBpedia provides structured information extracted from Wikipedia, including a comprehensive collection of smartphone models with their specifications.

**Benefits**:
- High-quality curated data
- Rich semantic relationships
- Links to other DBpedia resources
- Multilingual support

The script fetches smartphone data using the DBpedia SPARQL endpoint and converts it to our ontology format.

### 2. Wikidata

Wikidata is a collaboratively edited knowledge base that serves as a central storage for structured data used by Wikipedia and other Wikimedia projects.

**Benefits**:
- Continuously updated by the community
- Standardized property structure
- Linked to other external identifiers
- Fine-grained data typing

The script queries smartphone instances from Wikidata and maps the properties to our ontology.

### 3. GSMArena Data

GSMArena provides detailed specifications for thousands of smartphone models. The data is scraped and structured according to our ontology.

**Benefits**:
- Comprehensive technical specifications
- Recent and historical models
- Consistent data structure
- Detailed component information

### 4. GitHub Dataset

The GitHub dataset provides additional smartphone data from various sources, collected and normalized by the community.

## Ontology Alignment

The aligned ontology establishes equivalence and subclass relationships with standard vocabularies:

1. **DBpedia Ontology**:
   - `Smartphone` is a subclass of `dbo:MobilePhone`
   - Properties are mapped to DBpedia properties where applicable

2. **Schema.org**:
   - `Smartphone` is a subclass of `schema:Product`
   - Uses Schema.org properties like `schema:manufacturer`, `schema:model`, etc.

3. **GoodRelations**:
   - `Smartphone` is a subclass of `gr:ProductOrService`
   - Enables e-commerce semantics (price, availability, etc.)

This alignment allows our data to be interoperable with other systems that use these standard vocabularies.

## Entity Resolution

The integration process identifies and merges duplicate smartphone entities across different data sources:

1. **Normalization**:
   - Model names are normalized (lowercase, special characters removed)
   - Manufacturer names are standardized

2. **Matching**:
   - Uses a combination of exact matching and string similarity
   - Configurable similarity threshold (default: 0.85)

3. **Canonical URI Selection**:
   - Prioritizes URIs from our namespace
   - Falls back to most informative external URI

4. **Semantic Linking**:
   - Creates `owl:sameAs` links between equivalent entities
   - Preserves provenance information

## SPARQL Query Examples

After loading the integrated dataset into your SPARQL endpoint, you can run queries like:

```sparql
# Find all Samsung phones with AMOLED displays released after 2020
PREFIX smartphone: <http://www.semanticweb.org/smartphone-ontology#>
PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>

SELECT ?phone ?model ?releaseDate ?screenSize
WHERE {
  ?phone a smartphone:Smartphone ;
         smartphone:hasModelName ?model ;
         smartphone:manufacturedBy ?manufacturer ;
         smartphone:hasReleaseDate ?releaseDate ;
         smartphone:hasDisplay ?display .
  
  ?manufacturer smartphone:hasBrandName "Samsung" .
  ?display smartphone:hasDisplayType ?displayType .
  
  FILTER(CONTAINS(LCASE(?displayType), "amoled"))
  FILTER(xsd:date(?releaseDate) > "2020-01-01"^^xsd:date)
  
  OPTIONAL { ?display smartphone:hasScreenSize ?screenSize }
}
ORDER BY DESC(?releaseDate)
```

```sparql
# Compare average battery capacity by manufacturer
PREFIX smartphone: <http://www.semanticweb.org/smartphone-ontology#>

SELECT ?brandName (AVG(?capacity) AS ?avgCapacity) (COUNT(?phone) AS ?phoneCount)
WHERE {
  ?phone a smartphone:Smartphone ;
         smartphone:manufacturedBy ?manufacturer ;
         smartphone:hasBattery ?battery .
  
  ?manufacturer smartphone:hasBrandName ?brandName .
  ?battery smartphone:hasBatteryCapacity ?capacity .
}
GROUP BY ?brandName
HAVING (?phoneCount > 5)
ORDER BY DESC(?avgCapacity)
```

## Extending the Integration

To add new data sources to the integration pipeline:

1. Create a new script in `scripts/data_integration/` that:
   - Fetches data from the source
   - Converts it to our ontology format
   - Saves it as a Turtle file in `data/processed/`

2. Update `run_data_integration.py` to include your new script

3. Run the integration pipeline to merge the new data with existing sources

## Troubleshooting

If you encounter issues during the integration process:

1. **SPARQL Endpoint Connectivity**:
   - Ensure you have internet access
   - Check if the DBpedia or Wikidata endpoints are available

2. **Duplicate or Missing Entities**:
   - Adjust the similarity threshold in `integrate_datasets.py`
   - Check the normalization functions for manufacturer and model names

3. **Memory Issues**:
   - For large datasets, increase your Python memory allocation
   - Process sources in smaller batches

4. **Ontology Misalignments**:
   - Check mapping rules in `align_ontology.py`
   - Verify property domains and ranges

## Future Enhancements

1. **Additional Data Sources**:
   - PhoneArena
   - Gadgets360
   - Manufacturer official specs

2. **Temporal Dimension**:
   - Track specification changes over time
   - Model smartphone generation relationships

3. **Enhanced Entity Resolution**:
   - Machine learning-based similarity metrics
   - Context-aware disambiguation

4. **Inference Rules**:
   - Derive smartphone categories (high-end, mid-range, entry-level)
   - Compatibility inferences between models and accessories

5. **User Feedback Loop**:
   - Allow user corrections to entity matching
   - Confidence scores for uncertain matches