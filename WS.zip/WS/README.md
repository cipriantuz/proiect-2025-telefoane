# Smartphone Ontology Project

## Overview

This project creates a comprehensive ontology for smartphones, focusing on their technical specifications and relationships. The ontology allows for complex queries and comparisons between devices, enabling users to find smartphones based on specific criteria and make informed decisions.

## Project Structure

```
WS/
├── onto/               # Ontology files
│   └── smartphone-ontology.owl  # Main ontology definition
│
├── scripts/            # Python scripts
│   ├── crawling/       # Web scraping scripts
│   │   └── gsmarena_spider.py  # GSMArena data crawler
│   │
│   ├── processing/     # Data processing scripts
│   │   └── json_to_rdf.py  # Converts JSON data to RDF
│   │
│   └── sparql_test.py  # Script to test SPARQL queries
│
├── data/               # Data files
│   ├── raw/            # Raw extracted data
│   │   ├── Samsung_Galaxy_S21.json
│   │   ├── Samsung_Galaxy_S22.json
│   │   ├── Apple_iPhone_13.json
│   │   ├── Apple_iPhone_14.json
│   │   └── Xiaomi_Redmi_Note_10.json
│   │
│   └── processed/      # Processed RDF data (generated)
│
├── sparql/             # SPARQL queries
│   ├── high_end_smartphones.sparql
│   ├── manufacturer_series_comparison.sparql
│   └── compatible_accessories.sparql
│
└── README.md           # Project documentation
```

## Ontology Structure

The smartphone ontology models the domain with the following key components:

### Classes
- **Manufacturer**: Represents smartphone brands (Samsung, Apple, etc.)
- **DeviceSeries**: Represents product lines (Galaxy S, iPhone, etc.)
- **Smartphone**: The central class representing individual phone models
- **Component hierarchy**:
  - Display
  - Processor
  - Camera
  - Battery
  - Memory
  - Connectivity
- **Software**: Represents the operating system and software features

### Key Relationships
- **manufacturedBy**: Links phones to their manufacturers
- **belongsToSeries**: Organizes phones into product lines
- **hasComponent relationships**: Connect phones to their specifications

## Implementation Steps

### 1. Ontology Design

The ontology is designed using the OWL (Web Ontology Language) format. It defines classes, object properties (relationships between entities), and data properties (attributes of entities).

The OWL file can be viewed and edited using Protégé, an open-source ontology editor.

### 2. Data Extraction

Data is extracted from GSMArena.com using a Scrapy spider that:
1. Crawls manufacturer listings
2. Extracts phone listings for each manufacturer
3. Scrapes detailed specifications for each phone model
4. Stores raw data in JSON format

For demonstration purposes, we've included sample JSON files representing real smartphone data.

### 3. Data Processing

The JSON data is processed and converted to RDF (Resource Description Framework) using the `json_to_rdf.py` script. This script:

1. Creates instances of ontology classes (Manufacturer, DeviceSeries, Smartphone, etc.)
2. Establishes relationships between these instances
3. Extracts and normalizes attributes (screen size, battery capacity, etc.)
4. Generates RDF triples representing the knowledge graph
5. Outputs the data in multiple RDF formats (Turtle, RDF/XML, JSON-LD)

### 4. SPARQL Queries

Several example SPARQL queries are provided to demonstrate the power of the ontology:

1. **high_end_smartphones.sparql**: Finds premium smartphones with AMOLED displays, large batteries, and high-resolution cameras
2. **manufacturer_series_comparison.sparql**: Compares different series from Samsung, analyzing average battery capacity and screen size
3. **compatible_accessories.sparql**: Identifies smartphones compatible with fast charging technology

### 5. Deployment with Apache Jena Fuseki

The processed RDF data can be loaded into Apache Jena Fuseki, a SPARQL server that provides:
- A SPARQL endpoint for querying the data
- A web interface for executing queries and visualizing results
- Data management capabilities

## Usage Instructions

### Setting Up the Environment

1. Install required Python packages:
   ```
   pip install rdflib scrapy beautifulsoup4 pandas requests tqdm SPARQLWrapper
   ```

2. Download and install:
   - Protégé for ontology development: https://protege.stanford.edu/
   - Apache Jena Fuseki for the SPARQL endpoint: https://jena.apache.org/download/

### Extracting Data

To extract data from GSMArena (note: this might be subject to website terms of use):
```
cd scripts/crawling
scrapy runspider gsmarena_spider.py
```

### Processing Data

To convert the JSON files to RDF:
```
cd scripts/processing
python json_to_rdf.py
```

### Setting Up the SPARQL Endpoint

1. Start the Fuseki server:
   ```
   cd /path/to/apache-jena-fuseki
   ./fuseki-server
   ```

2. Access the Fuseki web interface at http://localhost:3030/
3. Create a new dataset named "smartphones"
4. Upload the processed RDF data from the `data/processed` directory

### Running Queries

You can run the example queries in several ways:

1. Through the Fuseki web interface
2. Using the `sparql_test.py` script to display the queries:
   ```
   cd scripts
   python sparql_test.py
   ```
3. Using any SPARQL client that can connect to the endpoint

## Future Enhancements

1. Expand the ontology to include more features and relationships
2. Integrate with other datasets and ontologies (e.g., DBpedia)
3. Develop a web interface for interactive querying and visualization
4. Implement inferencing rules for advanced knowledge discovery
5. Add temporal analysis to track the evolution of smartphone specifications

## Resources

- [Semantic Web Fundamentals](https://www.w3.org/standards/semanticweb/)
- [OWL 2 Web Ontology Language](https://www.w3.org/TR/owl2-overview/)
- [SPARQL 1.1 Query Language](https://www.w3.org/TR/sparql11-query/)
- [RDF 1.1 Concepts and Abstract Syntax](https://www.w3.org/TR/rdf11-concepts/)
