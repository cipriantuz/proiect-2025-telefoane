# Smartphone Ontology with Real Data

This document provides instructions for using the real smartphone dataset from GitHub instead of synthetic data.

## Overview

Instead of using synthetic data, this project can use a real smartphone dataset from GitHub that contains actual specifications for various smartphone models. This approach has several advantages:

1. Real-world accuracy
2. Actual market-available devices
3. Realistic distribution of features and specifications

## Dataset Source

The dataset comes from:
- GitHub Repository: [koyarqasm/SmartPhone-dataset](https://github.com/koyarqasm/SmartPhone-dataset/)
- Direct file: [smartphones.csv](https://raw.githubusercontent.com/koyarqasm/SmartPhone-dataset/main/smartphones.csv)

This dataset contains detailed specifications for hundreds of smartphones including:
- Brand and model names
- Screen sizes and types
- Processor information
- Camera specifications
- Battery capacity
- Memory and storage configurations
- and much more

## Using the Real Dataset

### Automated Approach

The simplest way to use the real dataset is to run the provided batch script:

```
use_github_dataset.bat
```

This script will:
1. Download the dataset from GitHub
2. Convert it to the format required by our processing script
3. Generate RDF triples based on our smartphone ontology

### Manual Steps

If you prefer to do the process step by step:

1. **Download the dataset**:
   ```
   cd scripts\download
   python download_github_dataset.py
   ```

2. **Process the data into RDF**:
   ```
   cd scripts\processing
   python process_github_data.py
   ```

3. **Load the data into Fuseki**:
   - Start Apache Jena Fuseki
   - Create a dataset (e.g., "smartphones")
   - Upload the generated file: `data\processed\smartphone-data-github.ttl`

## Extending the Dataset

If you need a larger dataset with more devices, you can consider:

1. **Combining multiple data sources**:
   - [Teoalida's Phone Database](https://www.teoalida.com/database/phones/) - 13,000+ models
   - [Back4App Cell Phone Dataset](https://www.back4app.com/database/paul-datasets/cell-phone-dataset)

2. **Web scraping additional data** (with proper respect for terms of service):
   - Use the modified GSMArena scraper with increased delays
   - Target specific manufacturers not included in the GitHub dataset

3. **Incorporating DBpedia data**:
   - Link phones to their DBpedia entries
   - Add additional data from Wikipedia via DBpedia's SPARQL endpoint

## Sample SPARQL Queries

The queries in the `sparql` directory can be used with this dataset. Here are some additional queries specific to the real dataset:

### Find Phones by Brand and Screen Size

```sparql
PREFIX smartphone: <http://www.semanticweb.org/smartphone-ontology#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>

SELECT ?model ?screenSize ?batteryCapacity
WHERE {
  ?manufacturer rdf:type smartphone:Manufacturer ;
                smartphone:hasBrandName "Samsung" .
  
  ?phone rdf:type smartphone:Smartphone ;
         smartphone:hasModelName ?model ;
         smartphone:manufacturedBy ?manufacturer ;
         smartphone:hasDisplay ?display ;
         smartphone:hasBattery ?battery .
  
  ?display smartphone:hasScreenSize ?screenSize .
  FILTER(?screenSize > 6.0)
  
  ?battery smartphone:hasBatteryCapacity ?batteryCapacity .
}
ORDER BY DESC(?screenSize)
LIMIT 10
```

### Compare Average Camera Resolution by Brand

```sparql
PREFIX smartphone: <http://www.semanticweb.org/smartphone-ontology#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>

SELECT ?brandName (AVG(?cameraMP) as ?avgCameraMP) (COUNT(?phone) as ?phoneCount)
WHERE {
  ?manufacturer rdf:type smartphone:Manufacturer ;
                smartphone:hasBrandName ?brandName .
  
  ?phone rdf:type smartphone:Smartphone ;
         smartphone:manufacturedBy ?manufacturer ;
         smartphone:hasMainCamera ?camera .
  
  ?camera smartphone:hasResolutionMP ?cameraMP .
}
GROUP BY ?brandName
HAVING (COUNT(?phone) > 3)
ORDER BY DESC(?avgCameraMP)
```

## Distribution of Triples

The GitHub dataset will typically generate:
- Approximately 20-30 triples per smartphone
- Total number of triples depends on the number of phones in the dataset
- Connection to manufacturers, series, and components creates a rich knowledge graph

## Maintenance and Updates

To keep the dataset current:
1. The GitHub repository may be updated periodically. You can re-run the download script to get the latest data.
2. You may want to schedule regular downloads and processing to maintain freshness.
3. Consider contributing back to the original GitHub repository if you enhance the dataset.
